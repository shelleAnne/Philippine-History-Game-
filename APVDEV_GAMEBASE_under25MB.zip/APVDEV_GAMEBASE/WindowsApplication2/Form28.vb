﻿Public Class Form28
    Private Property vbClean As Object
    Private Sub Button28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button28.Click
        Button28.BackColor = vbClean
        Button28.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button37_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button37.Click
        Button37.BackColor = vbClean
        Button37.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button46_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button46.Click
        Button46.BackColor = vbClean
        Button46.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button95_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button95.Click
        Button95.BackColor = vbClean
        Button95.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button84_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button84.Click
        Button84.BackColor = vbClean
        Button84.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Button6.BackColor = vbClean
        Button6.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Button12.BackColor = vbClean
        Button12.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button23.Click
        Button23.BackColor = vbClean
        Button23.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button34_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button34.Click
        Button34.BackColor = vbClean
        Button34.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button45_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button45.Click
        Button45.BackColor = vbClean
        Button45.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Button11.BackColor = vbClean
        Button11.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button21.Click
        Button21.BackColor = vbClean
        Button21.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button31_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button31.Click
        Button31.BackColor = vbClean
        Button31.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button41_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button41.Click
        Button41.BackColor = vbClean
        Button41.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button91_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button91.Click
        Button91.BackColor = vbClean
        Button91.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button47_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button47.Click
        Button47.BackColor = vbClean
        Button47.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button97_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button97.Click
        Button97.BackColor = vbClean
        Button97.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button87_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button87.Click
        Button87.BackColor = vbClean
        Button87.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button77_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button77.Click
        Button77.BackColor = vbClean
        Button77.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button67_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button67.Click
        Button67.BackColor = vbClean
        Button67.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button57_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button57.Click
        Button57.BackColor = vbClean
        Button57.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Button2.BackColor = vbClean
        Button2.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button20.Click
        Button20.BackColor = vbClean
        Button20.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub
    Private Sub Button30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button30.Click
        Button30.BackColor = vbClean
        Button30.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button40_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button40.Click
        Button40.BackColor = vbClean
        Button40.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button50_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button50.Click
        Button50.BackColor = vbClean
        Button50.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button100_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button100.Click
        Button100.BackColor = vbClean
        Button100.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button90_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button90.Click
        Button90.BackColor = vbClean
        Button90.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button80_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button80.Click
        Button80.BackColor = vbClean
        Button80.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button38_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button38.Click
        Button38.BackColor = vbClean
        Button38.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button48_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button48.Click
        Button48.BackColor = vbClean
        Button48.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button98_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button98.Click
        Button98.BackColor = vbClean
        Button98.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button88_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button88.Click
        Button88.BackColor = vbClean
        Button88.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button78_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button78.Click
        Button78.BackColor = vbClean
        Button78.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button68_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button68.Click
        Button68.BackColor = vbClean
        Button68.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button58_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button58.Click
        Button58.BackColor = vbClean
        Button58.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button96_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button96.Click
        Button96.BackColor = vbClean
        Button96.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 5 Then
            Label10.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button85_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button85.Click
        Button85.BackColor = vbClean
        Button85.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 5 Then
            Label10.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button74_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button74.Click
        Button74.BackColor = vbClean
        Button74.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 5 Then
            Label10.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button63_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button63.Click
        Button63.BackColor = vbClean
        Button63.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 5 Then
            Label10.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button52_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button52.Click
        Button52.BackColor = vbClean
        Button52.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 5 Then
            Label10.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Button3.BackColor = vbClean
        Button3.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 7 Then
            Label9.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Button4.BackColor = vbClean
        Button4.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 7 Then
            Label9.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Button5.BackColor = vbClean
        Button5.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 7 Then
            Label9.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Button10.BackColor = vbClean
        Button10.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 7 Then
            Label9.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Button9.BackColor = vbClean
        Button9.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 7 Then
            Label9.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Button8.BackColor = vbClean
        Button8.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 7 Then
            Label9.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Button7.BackColor = vbClean
        Button7.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 7 Then
            Label9.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        Button18.BackColor = vbClean
        Button18.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 5 Then
            Label8.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        Button17.BackColor = vbClean
        Button17.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 5 Then
            Label8.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        Button16.BackColor = vbClean
        Button16.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 5 Then
            Label8.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        Button15.BackColor = vbClean
        Button15.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 5 Then
            Label8.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        Button14.BackColor = vbClean
        Button14.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 5 Then
            Label8.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button39_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button39.Click
        Button39.BackColor = vbClean
        Button39.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button49_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button49.Click
        Button49.BackColor = vbClean
        Button49.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button99_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button99.Click
        Button99.BackColor = vbClean
        Button99.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button89_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button89.Click
        Button89.BackColor = vbClean
        Button89.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button79_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button79.Click
        Button79.BackColor = vbClean
        Button79.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button69_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button69.Click
        Button69.BackColor = vbClean
        Button69.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox12.Text = Val(TextBox12.Text) + 1
        End If
        If Val(TextBox12.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Button1.BackColor = Color.Red
        Button1.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        Button19.BackColor = Color.Red
        Button19.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button29.Click
        Button29.BackColor = Color.Red
        Button29.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button27.Click
        Button27.BackColor = Color.Red
        Button27.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        Button13.BackColor = Color.Red
        Button13.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button26.Click
        Button26.BackColor = Color.Red
        Button26.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button25.Click
        Button25.BackColor = Color.Red
        Button25.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button24.Click
        Button24.BackColor = Color.Red
        Button24.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button22.Click
        Button22.BackColor = Color.Red
        Button22.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button36_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button36.Click
        Button36.BackColor = Color.Red
        Button36.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button35.Click
        Button35.BackColor = Color.Red
        Button35.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button33.Click
        Button33.BackColor = Color.Red
        Button33.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button32.Click
        Button32.BackColor = Color.Red
        Button32.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button44_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button44.Click
        Button44.BackColor = Color.Red
        Button44.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button43.Click
        Button43.BackColor = Color.Red
        Button43.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button42_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button42.Click
        Button42.BackColor = Color.Red
        Button42.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button94_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button94.Click
        Button94.BackColor = Color.Red
        Button94.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button93_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button93.Click
        Button93.BackColor = Color.Red
        Button93.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button92_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button92.Click
        Button92.BackColor = Color.Red
        Button92.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button86_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button86.Click
        Button86.BackColor = Color.Red
        Button92.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button83_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button83.Click
        Button83.BackColor = Color.Red
        Button83.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button82_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button82.Click
        Button82.BackColor = Color.Red
        Button82.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button81_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button81.Click
        Button81.BackColor = Color.Red
        Button81.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button76_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button76.Click
        Button76.BackColor = Color.Red
        Button76.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button75_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button75.Click
        Button75.BackColor = Color.Red
        Button75.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button73_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button73.Click
        Button73.BackColor = Color.Red
        Button73.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button72_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button72.Click
        Button72.BackColor = Color.Red
        Button72.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button71_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button71.Click
        Button71.BackColor = Color.Red
        Button71.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button70_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button70.Click
        Button70.BackColor = Color.Red
        Button70.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button66_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button66.Click
        Button66.BackColor = Color.Red
        Button66.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button65_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button65.Click
        Button65.BackColor = Color.Red
        Button65.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button64_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button64.Click
        Button64.BackColor = Color.Red
        Button64.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button62_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button62.Click
        Button62.BackColor = Color.Red
        Button62.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button61_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button61.Click
        Button61.BackColor = Color.Red
        Button61.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button60_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button60.Click
        Button60.BackColor = Color.Red
        Button60.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button59_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button59.Click
        Button59.BackColor = Color.Red
        Button59.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button56_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button56.Click
        Button56.BackColor = Color.Red
        Button56.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button55_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button55.Click
        Button55.BackColor = Color.Red
        Button55.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button54_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button54.Click
        Button54.BackColor = Color.Red
        Button54.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button53_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button53.Click
        Button53.BackColor = Color.Red
        Button53.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button51_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button51.Click
        Button51.BackColor = Color.Red
        Button51.Enabled = False
        TextBox11.Text = Val(TextBox11.Text) + 1
        If Val(TextBox11.Text) = 5 Then
            Me.Hide()
            Form29.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Form28_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play("C:\Users\Sheryl\Documents\Visual Studio 2010\Projects\WindowsApplication2\Music\TV_Show_Intro.wav")
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.ProgressBar1.Value += 2
        If Me.ProgressBar1.Value <= 5 Then
        ElseIf Me.ProgressBar1.Value <= 10 Then
        ElseIf Me.ProgressBar1.Value <= 15 Then
        ElseIf Me.ProgressBar1.Value <= 20 Then
        ElseIf Me.ProgressBar1.Value <= 25 Then
        ElseIf Me.ProgressBar1.Value <= 30 Then
        ElseIf Me.ProgressBar1.Value <= 35 Then
        ElseIf Me.ProgressBar1.Value <= 40 Then
        ElseIf Me.ProgressBar1.Value <= 45 Then
        ElseIf Me.ProgressBar1.Value <= 50 Then
        ElseIf Me.ProgressBar1.Value <= 60 Then
        ElseIf Me.ProgressBar1.Value <= 70 Then
        ElseIf Me.ProgressBar1.Value <= 80 Then
        ElseIf Me.ProgressBar1.Value <= 90 Then
            If Val(TextBox6.Text) = Val(TextBox6.Text) = 5 Then
                ProgressBar1.Dispose()
                Me.Hide()
                Form25.Hide()
                Form27.Show()
            End If
            If Me.ProgressBar1.Value <= 100 Then
                Form29.Show()
                Me.Hide()
                Me.Timer1.Dispose()

            End If
        End If
    End Sub
End Class