﻿Public Class Form27
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.Hide()
        Form26.Show()
    End Sub

    Private Sub Form27_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play("C:\Users\Sheryl\Documents\Visual Studio 2010\Projects\WindowsApplication2\Music\Final_Fantasy_Victory_Fanfare_Sound_Effect_HQ_.wav")
    End Sub
End Class