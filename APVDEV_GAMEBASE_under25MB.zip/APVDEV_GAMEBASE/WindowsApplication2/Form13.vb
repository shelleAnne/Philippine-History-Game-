﻿Public Class Form13
    Public score As Integer
    Private Sub PictureBox1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PictureBox1.Click
         Application.Restart()
    End Sub

    Private Sub Label6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label6.Click
        MsgBox("Tamang ksagutan")
        Dim Form2 As New Form14
        Form14.Show()
        Me.Hide()
        score += 1
        Timer1.Stop()
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        MsgBox("Maling kasagutan")
        Dim Form2 As New Form14
        Form14.Show()
        Me.Hide()
        Timer1.Stop()
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MsgBox("Maling kasagutan")
        Dim Form2 As New Form14
        Form14.Show()
        Me.Hide()
        Timer1.Stop()
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click
        MsgBox("Maling kasagutan")
        Dim Form2 As New Form14
        Form14.Show()
        Me.Hide()
        Timer1.Stop()
    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        MsgBox("Maling kasagutan")
        Dim Form2 As New Form14
        Form14.Show()
        Me.Hide()
        Timer1.Stop()
    End Sub

    Private Sub Form13_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play("C:\Users\Sheryl\Documents\Visual Studio 2010\Projects\WindowsApplication2\Music\Game_KNB_Theme_2001_Extended_ (1).wav")
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.ProgressBar1.Value += 2
        If Me.ProgressBar1.Value <= 5 Then
        ElseIf Me.ProgressBar1.Value <= 10 Then
        ElseIf Me.ProgressBar1.Value <= 15 Then
        ElseIf Me.ProgressBar1.Value <= 20 Then
        ElseIf Me.ProgressBar1.Value <= 25 Then
        ElseIf Me.ProgressBar1.Value <= 30 Then
        ElseIf Me.ProgressBar1.Value <= 35 Then
        ElseIf Me.ProgressBar1.Value <= 40 Then
        ElseIf Me.ProgressBar1.Value <= 45 Then
        ElseIf Me.ProgressBar1.Value <= 50 Then
        ElseIf Me.ProgressBar1.Value <= 60 Then
        ElseIf Me.ProgressBar1.Value <= 70 Then
        ElseIf Me.ProgressBar1.Value <= 80 Then
        ElseIf Me.ProgressBar1.Value <= 90 Then
            Form14.Show()
            Me.Hide()
            Me.Timer1.Dispose()
        End If
    End Sub
End Class