﻿Public Class Form31
    Private Property vbClean As Object
    Private Sub Button94_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button94.Click
        Button94.BackColor = vbClean
        Button94.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button113_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button113.Click
        Button113.BackColor = vbClean
        Button113.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button132_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button132.Click
        Button132.BackColor = vbClean
        Button132.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button151_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button151.Click
        Button151.BackColor = vbClean
        Button151.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button170_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button170.Click
        Button170.BackColor = vbClean
        Button170.Enabled = False
        TextBox1.Text = Val(TextBox1.Text) + 1
        If Val(TextBox1.Text) = 5 Then
            Label2.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button31_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button31.Click
        Button31.BackColor = vbClean
        Button31.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button50_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button50.Click
        Button50.BackColor = vbClean
        Button50.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button69_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button69.Click
        Button69.BackColor = vbClean
        Button69.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button88_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button88.Click
        Button88.BackColor = vbClean
        Button88.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button107_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button107.Click
        Button107.BackColor = vbClean
        Button107.Enabled = False
        TextBox2.Text = Val(TextBox2.Text) + 1
        If Val(TextBox2.Text) = 5 Then
            Label3.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button51_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button51.Click
        Button51.BackColor = vbClean
        Button51.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button71_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button71.Click
        Button71.BackColor = vbClean
        Button71.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button91_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button91.Click
        Button91.BackColor = vbClean
        Button91.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button111_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button111.Click
        Button111.BackColor = vbClean
        Button111.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button131_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button131.Click
        Button131.BackColor = vbClean
        Button131.Enabled = False
        TextBox3.Text = Val(TextBox3.Text) + 1
        If Val(TextBox3.Text) = 5 Then
            Label4.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button46_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button46.Click
        Button46.BackColor = vbClean
        Button46.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button66_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button66.Click
        Button66.BackColor = vbClean
        Button66.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button86_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button86.Click
        Button86.BackColor = vbClean
        Button86.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button106_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button106.Click
        Button106.BackColor = vbClean
        Button106.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button126_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button126.Click
        Button126.BackColor = vbClean
        Button126.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button146_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button146.Click
        Button146.BackColor = vbClean
        Button146.Enabled = False
        TextBox4.Text = Val(TextBox4.Text) + 1
        If Val(TextBox4.Text) = 6 Then
            Label5.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button300_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button300.Click
        Button300.BackColor = vbClean
        Button300.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button279_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button279.Click
        Button279.BackColor = vbClean
        Button279.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button258_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button258.Click
        Button258.BackColor = vbClean
        Button258.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button237_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button237.Click
        Button237.BackColor = vbClean
        Button237.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button216_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button216.Click
        Button216.BackColor = vbClean
        Button216.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button195_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button195.Click
        Button195.BackColor = vbClean
        Button195.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button174_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button174.Click
        Button174.BackColor = vbClean
        Button174.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button153_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button153.Click
        Button153.BackColor = vbClean
        Button153.Enabled = False
        TextBox5.Text = Val(TextBox5.Text) + 1
        If Val(TextBox5.Text) = 8 Then
            Label6.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button43_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button43.Click
        Button43.BackColor = vbClean
        Button43.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button63_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button63.Click
        Button63.BackColor = vbClean
        Button63.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button83_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button83.Click
        Button83.BackColor = vbClean
        Button83.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button103_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button103.Click
        Button103.BackColor = vbClean
        Button103.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button123_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button123.Click
        Button123.BackColor = vbClean
        Button123.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button143_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button143.Click
        Button143.BackColor = vbClean
        Button143.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button163_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button163.Click
        Button163.BackColor = vbClean
        Button163.Enabled = False
        TextBox10.Text = Val(TextBox10.Text) + 1
        If Val(TextBox10.Text) = 7 Then
            Label11.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button186_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button186.Click
        Button186.BackColor = vbClean
        Button186.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 6 Then
            Label10.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button207_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button207.Click
        Button207.BackColor = vbClean
        Button207.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 6 Then
            Label10.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button228_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button228.Click
        Button228.BackColor = vbClean
        Button228.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 6 Then
            Label10.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button249_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button249.Click
        Button249.BackColor = vbClean
        Button249.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 6 Then
            Label10.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button270_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button270.Click
        Button270.BackColor = vbClean
        Button270.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 6 Then
            Label10.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button291_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button291.Click
        Button291.BackColor = vbClean
        Button291.Enabled = False
        TextBox9.Text = Val(TextBox9.Text) + 1
        If Val(TextBox9.Text) = 6 Then
            Label10.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button38_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button38.Click
        Button38.BackColor = vbClean
        Button38.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 6 Then
            Label9.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button58_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button58.Click
        Button58.BackColor = vbClean
        Button58.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 6 Then
            Label9.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button78_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button78.Click
        Button78.BackColor = vbClean
        Button78.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 6 Then
            Label9.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button98_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button98.Click
        Button98.BackColor = vbClean
        Button98.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 6 Then
            Label9.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button118_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button118.Click
        Button118.BackColor = vbClean
        Button118.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 6 Then
            Label9.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button138_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button138.Click
        Button138.BackColor = vbClean
        Button138.Enabled = False
        TextBox8.Text = Val(TextBox8.Text) + 1
        If Val(TextBox8.Text) = 6 Then
            Label9.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button286_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button286.Click
        Button286.BackColor = vbClean
        Button286.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 6 Then
            Label8.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button285_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button285.Click
        Button285.BackColor = vbClean
        Button285.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 6 Then
            Label8.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button284_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button284.Click
        Button284.BackColor = vbClean
        Button284.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 6 Then
            Label8.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button283_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button283.Click
        Button283.BackColor = vbClean
        Button283.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 6 Then
            Label8.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button282_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button282.Click
        Button282.BackColor = vbClean
        Button282.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 6 Then
            Label8.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button281_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button281.Click
        Button281.BackColor = vbClean
        Button281.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 6 Then
            Label8.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Button1.BackColor = vbClean
        Button1.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button40_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button40.Click
        Button40.BackColor = vbClean
        Button40.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button60_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button60.Click
        Button60.BackColor = vbClean
        Button60.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button80_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button80.Click
        Button80.BackColor = vbClean
        Button80.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button100_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button100.Click
        Button100.BackColor = vbClean
        Button100.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button120_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button120.Click
        Button120.BackColor = vbClean
        Button120.Enabled = False
        TextBox6.Text = Val(TextBox6.Text) + 1
        If Val(TextBox6.Text) = 6 Then
            Label7.Visible = False
            TextBox11.Text = Val(TextBox11.Text) + 1
        End If
        If Val(TextBox11.Text) = 10 Then
            Me.Hide()
            Form27.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Button2.BackColor = Color.Red
        Button2.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Button4.BackColor = Color.Red
        Button4.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Button3.BackColor = Color.Red
        Button3.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        Button8.BackColor = Color.Red
        Button8.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        Button7.BackColor = Color.Red
        Button7.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Button6.BackColor = Color.Red
        Button6.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        Button5.BackColor = Color.Red
        Button5.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        Button12.BackColor = Color.Red
        Button12.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        Button11.BackColor = Color.Red
        Button11.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        Button10.BackColor = Color.Red
        Button10.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        Button9.BackColor = Color.Red
        Button9.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button20.Click
        Button20.BackColor = Color.Red
        Button20.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        Button19.BackColor = Color.Red
        Button19.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        Button18.BackColor = Color.Red
        Button18.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        Button17.BackColor = Color.Red
        Button17.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button16.Click
        Button16.BackColor = Color.Red
        Button16.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        Button15.BackColor = Color.Red
        Button15.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        Button14.BackColor = Color.Red
        Button14.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        Button13.BackColor = Color.Red
        Button13.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button39_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button39.Click
        Button39.BackColor = Color.Red
        Button39.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button37_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button37.Click
        Button37.BackColor = Color.Red
        Button37.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button36_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button36.Click
        Button36.BackColor = Color.Red
        Button36.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button35_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button35.Click
        Button35.BackColor = Color.Red
        Button35.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button34_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button34.Click
        Button34.BackColor = Color.Red
        Button34.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button33_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button33.Click
        Button33.BackColor = Color.Red
        Button33.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button32_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button32.Click
        Button32.BackColor = Color.Red
        Button32.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button30_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button30.Click
        Button30.BackColor = Color.Red
        Button30.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button29_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button29.Click
        Button29.BackColor = Color.Red
        Button29.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button28_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button28.Click
        Button28.BackColor = Color.Red
        Button28.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button27_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button27.Click
        Button27.BackColor = Color.Red
        Button27.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button26_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button26.Click
        Button26.BackColor = Color.Red
        Button26.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button25_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button25.Click
        Button25.BackColor = Color.Red
        Button25.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button24_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button24.Click
        Button24.BackColor = Color.Red
        Button24.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button23.Click
        Button23.BackColor = Color.Red
        Button23.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button22.Click
        Button22.BackColor = Color.Red
        Button22.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button21.Click
        Button21.BackColor = Color.Red
        Button21.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button59_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button59.Click
        Button59.BackColor = Color.Red
        Button59.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button57_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button57.Click
        Button57.BackColor = Color.Red
        Button57.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button56_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button56.Click
        Button56.BackColor = Color.Red
        Button56.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button55_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button55.Click
        Button55.BackColor = Color.Red
        Button55.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button54_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button54.Click
        Button54.BackColor = Color.Red
        Button54.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button53_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button53.Click
        Button53.BackColor = Color.Red
        Button53.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button52_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button52.Click
        Button52.BackColor = Color.Red
        Button52.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button49_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button49.Click
        Button46.BackColor = Color.Red
        Button46.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()

        End If
    End Sub

    Private Sub Button48_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button48.Click
        Button48.BackColor = Color.Red
        Button48.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button47_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button47.Click
        Button47.BackColor = Color.Red
        Button47.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button45_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button45.Click
        Button45.BackColor = Color.Red
        Button45.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button44_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button44.Click
        Button44.BackColor = Color.Red
        Button44.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button42_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button42.Click
        Button42.BackColor = Color.Red
        Button42.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button41_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button41.Click
        Button41.BackColor = Color.Red
        Button41.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Start()
        End If
    End Sub

    Private Sub Button79_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button79.Click
        Button79.BackColor = Color.Red
        Button79.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button77_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button77.Click
        Button77.BackColor = Color.Red
        Button77.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button76_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button76.Click
        Button2.BackColor = Color.Red
        Button2.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button75_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button75.Click
        Button75.BackColor = Color.Red
        Button75.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button74_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button74.Click
        Button74.BackColor = Color.Red
        Button74.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button73_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button73.Click
        Button73.BackColor = Color.Red
        Button73.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button72_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button72.Click
        Button72.BackColor = Color.Red
        Button72.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button70_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button70.Click
        Button70.BackColor = Color.Red
        Button70.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button68_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button68.Click
        Button68.BackColor = Color.Red
        Button68.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button67_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button67.Click
        Button67.BackColor = Color.Red
        Button67.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button65_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button65.Click
        Button65.BackColor = Color.Red
        Button65.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button64_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button64.Click
        Button64.BackColor = Color.Red
        Button64.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button62_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button62.Click
        Button62.BackColor = Color.Red
        Button62.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button61_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button61.Click
        Button61.BackColor = Color.Red
        Button61.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button99_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button99.Click
        Button99.BackColor = Color.Red
        Button99.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button97_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button97.Click
        Button97.BackColor = Color.Red
        Button97.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button96_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button96.Click
        Button96.BackColor = Color.Red
        Button96.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button95_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button95.Click
        Button95.BackColor = Color.Red
        Button95.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button93_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button93.Click
        Button93.BackColor = Color.Red
        Button93.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button92_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button92.Click
        Button92.BackColor = Color.Red
        Button92.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button90_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button90.Click
        Button90.BackColor = Color.Red
        Button90.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button89_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button89.Click
        Button89.BackColor = Color.Red
        Button89.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Start()
        End If
    End Sub

    Private Sub Button87_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button87.Click
        Button87.BackColor = Color.Red
        Button87.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button85_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button85.Click
        Button85.BackColor = Color.Red
        Button85.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button84_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button84.Click
        Button84.BackColor = Color.Red
        Button84.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button82_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button82.Click
        Button82.BackColor = Color.Red
        Button82.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button81_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button81.Click
        Button81.BackColor = Color.Red
        Button81.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button119_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button119.Click
        Button119.BackColor = Color.Red
        Button119.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button117_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button117.Click
        Button117.BackColor = Color.Red
        Button117.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button116_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button116.Click
        Button116.BackColor = Color.Red
        Button116.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button115_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button115.Click
        Button115.BackColor = Color.Red
        Button155.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button114_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button114.Click
        Button114.BackColor = Color.Red
        Button144.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button112_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button112.Click
        Button112.BackColor = Color.Red
        Button112.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button110_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button110.Click
        Button110.BackColor = Color.Red
        Button110.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button109_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button109.Click
        Button109.BackColor = Color.Red
        Button109.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button108_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button108.Click
        Button108.BackColor = Color.Red
        Button108.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button105_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button105.Click
        Button105.BackColor = Color.Red
        Button105.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button104_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button104.Click
        Button104.BackColor = Color.Red
        Button104.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
        End If
    End Sub

    Private Sub Button102_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button102.Click
        Button102.BackColor = Color.Red
        Button102.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button101_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button101.Click
        Button101.BackColor = Color.Red
        Button101.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button140_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button140.Click
        Button140.BackColor = Color.Red
        Button140.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button139_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button139.Click
        Button139.BackColor = Color.Red
        Button139.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button137_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button137.Click
        Button137.BackColor = Color.Red
        Button137.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button136_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button136.Click
        Button136.BackColor = Color.Red
        Button136.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button135_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button135.Click
        Button135.BackColor = Color.Red
        Button135.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button134_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button134.Click
        Button134.BackColor = Color.Red
        Button134.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button133_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button133.Click
        Button133.BackColor = Color.Red
        Button133.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button130_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button130.Click
        Button130.BackColor = Color.Red
        Button130.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button129_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button129.Click
        Button129.BackColor = Color.Red
        Button129.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button128_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button128.Click
        Button128.BackColor = Color.Red
        Button128.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button127_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button127.Click
        Button127.BackColor = Color.Red
        Button127.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button125_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button125.Click
        Button125.BackColor = Color.Red
        Button125.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button124_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button124.Click
        Button124.BackColor = Color.Red
        Button124.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button122_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button122.Click
        Button122.BackColor = Color.Red
        Button122.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button121_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button121.Click
        Button121.BackColor = Color.Red
        Button121.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button160_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button160.Click
        Button160.BackColor = Color.Red
        Button160.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button159_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button159.Click
        Button159.BackColor = Color.Red
        Button159.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button158_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button158.Click
        Button158.BackColor = Color.Red
        Button158.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button157_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button157.Click
        Button157.BackColor = Color.Red
        Button157.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button156_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button156.Click
        Button156.BackColor = Color.Red
        Button156.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button155_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button155.Click
        Button155.BackColor = Color.Red
        Button155.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button154_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button154.Click
        Button154.BackColor = Color.Red
        Button154.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button152_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button152.Click
        Button152.BackColor = Color.Red
        Button152.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button150_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button150.Click
        Button150.BackColor = Color.Red
        Button150.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button149_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button149.Click
        Button149.BackColor = Color.Red
        Button149.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button148_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button148.Click
        Button148.BackColor = Color.Red
        Button148.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button147_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button147.Click
        Button147.BackColor = Color.Red
        Button147.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button145_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button145.Click
        Button145.BackColor = Color.Red
        Button145.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button144_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button144.Click
        Button144.BackColor = Color.Red
        Button144.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button142_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button142.Click
        Button142.BackColor = Color.Red
        Button142.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button141_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button141.Click
        Button141.BackColor = Color.Red
        Button141.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button180_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button180.Click
        Button140.BackColor = Color.Red
        Button140.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button179_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button179.Click
        Button179.BackColor = Color.Red
        Button179.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button178_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button178.Click
        Button178.BackColor = Color.Red
        Button178.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button177_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button177.Click
        Button178.BackColor = Color.Red
        Button178.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button176_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button176.Click
        Button176.BackColor = Color.Red
        Button176.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button175_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button175.Click
        Button175.BackColor = Color.Red
        Button175.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button173_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button173.Click
        Button173.BackColor = Color.Red
        Button173.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button172_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button172.Click
        Button172.BackColor = Color.Red
        Button172.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button171_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button171.Click
        Button171.BackColor = Color.Red
        Button171.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button169_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button169.Click
        Button169.BackColor = Color.Red
        Button169.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button168_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button168.Click
        Button168.BackColor = Color.Red
        Button168.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button167_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button167.Click
        Button167.BackColor = Color.Red
        Button167.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button166_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button166.Click
        Button166.BackColor = Color.Red
        Button166.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button165_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button165.Click
        Button165.BackColor = Color.Red
        Button165.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button164_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button164.Click
        Button164.BackColor = Color.Red
        Button164.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button162_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button162.Click
        Button162.BackColor = Color.Red
        Button162.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button161_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button161.Click
        Button161.BackColor = Color.Red
        Button161.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button200_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button200.Click
        Button160.BackColor = Color.Red
        Button160.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button199_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button199.Click
        Button199.BackColor = Color.Red
        Button199.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button198_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button198.Click
        Button198.BackColor = Color.Red
        Button198.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button197_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button197.Click
        Button197.BackColor = Color.Red
        Button197.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button196_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button196.Click
        Button196.BackColor = Color.Red
        Button196.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button194_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button194.Click
        Button194.BackColor = Color.Red
        Button194.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button193_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button193.Click
        Button193.BackColor = Color.Red
        Button193.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button192_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button192.Click
        Button192.BackColor = Color.Red
        Button192.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button191_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button191.Click
        Button191.BackColor = Color.Red
        Button191.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button190_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button190.Click
        Button190.BackColor = Color.Red
        Button190.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button189_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button189.Click
        Button189.BackColor = Color.Red
        Button189.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button188_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button188.Click
        Button188.BackColor = Color.Red
        Button188.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button187_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button187.Click
        Button187.BackColor = Color.Red
        Button187.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button185_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button185.Click
        Button185.BackColor = Color.Red
        Button185.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button184_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button184.Click
        Button184.BackColor = Color.Red
        Button184.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button183_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button183.Click
        Button183.BackColor = Color.Red
        Button183.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button182_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button182.Click
        Button182.BackColor = Color.Red
        Button182.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button181_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button181.Click
        Button181.BackColor = Color.Red
        Button181.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button220_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button220.Click
        Button220.BackColor = Color.Red
        Button220.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button219_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button219.Click
        Button219.BackColor = Color.Red
        Button219.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button218_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button218.Click
        Button218.BackColor = Color.Red
        Button218.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
        End If
    End Sub

    Private Sub Button217_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button217.Click
        Button217.BackColor = Color.Red
        Button217.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button215_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button215.Click
        Button215.BackColor = Color.Red
        Button215.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button214_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button214.Click
        Button214.BackColor = Color.Red
        Button214.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button213_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button213.Click
        Button213.BackColor = Color.Red
        Button213.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button212_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button212.Click
        Button212.BackColor = Color.Red
        Button212.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button211_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button211.Click
        Button211.BackColor = Color.Red
        Button211.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button210_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button210.Click
        Button210.BackColor = Color.Red
        Button210.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button209_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button209.Click
        Button209.BackColor = Color.Red
        Button209.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button208_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button208.Click
        Button208.BackColor = Color.Red
        Button208.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button206_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button206.Click
        Button206.BackColor = Color.Red
        Button206.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button205_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button205.Click
        Button205.BackColor = Color.Red
        Button205.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button204_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button204.Click
        Button204.BackColor = Color.Red
        Button204.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button203_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button203.Click
        Button203.BackColor = Color.Red
        Button203.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button202_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button202.Click
        Button202.BackColor = Color.Red
        Button202.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button201_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button201.Click
        Button201.BackColor = Color.Red
        Button201.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button240_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button240.Click
        Button240.BackColor = Color.Red
        Button240.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button239_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button239.Click
        Button239.BackColor = Color.Red
        Button239.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button238_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button238.Click
        Button238.BackColor = Color.Red
        Button238.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button236_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button236.Click
        Button236.BackColor = Color.Red
        Button236.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button235_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button235.Click
        Button235.BackColor = Color.Red
        Button235.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button234_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button234.Click
        Button234.BackColor = Color.Red
        Button234.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button233_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button233.Click
        Button233.BackColor = Color.Red
        Button233.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button232_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button232.Click
        Button232.BackColor = Color.Red
        Button232.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button231_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button231.Click
        Button231.BackColor = Color.Red
        Button231.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button230_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button230.Click
        Button230.BackColor = Color.Red
        Button230.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button229_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button229.Click
        Button229.BackColor = Color.Red
        Button229.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub
    Private Sub Button227_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button227.Click
        Button227.BackColor = Color.Red
        Button227.Enabled = False
        TextBox7.Text = Val(TextBox7.Text) + 1
        If Val(TextBox7.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button226_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button226.Click
        Button226.BackColor = Color.Red
        Button226.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button225_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button225.Click
        Button225.BackColor = Color.Red
        Button225.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button224_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button224.Click
        Button224.BackColor = Color.Red
        Button224.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button223_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button223.Click
        Button223.BackColor = Color.Red
        Button223.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button222_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button222.Click
        Button222.BackColor = Color.Red
        Button222.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button221_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button221.Click
        Button221.BackColor = Color.Red
        Button221.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button260_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button260.Click
        Button260.BackColor = Color.Red
        Button260.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button259_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button259.Click
        Button259.BackColor = Color.Red
        Button259.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button257_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button257.Click
        Button257.BackColor = Color.Red
        Button257.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button256_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button256.Click
        Button256.BackColor = Color.Red
        Button256.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button255_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button255.Click
        Button255.BackColor = Color.Red
        Button255.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button254_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button254.Click
        Button254.BackColor = Color.Red
        Button254.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button253_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button253.Click
        Button253.BackColor = Color.Red
        Button253.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button252_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button252.Click
        Button252.BackColor = Color.Red
        Button252.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button251_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button251.Click
        Button251.BackColor = Color.Red
        Button251.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button250_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button250.Click
        Button250.BackColor = Color.Red
        Button250.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button248_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button248.Click
        Button248.BackColor = Color.Red
        Button248.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button247_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button247.Click
        Button247.BackColor = Color.Red
        Button247.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button246_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button246.Click
        Button246.BackColor = Color.Red
        Button246.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button245_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button245.Click
        Button245.BackColor = Color.Red
        Button245.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button243_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button243.Click
        Button243.BackColor = Color.Red
        Button243.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button242_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button242.Click
        Button242.BackColor = Color.Red
        Button242.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button241_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button241.Click
        Button241.BackColor = Color.Red
        Button241.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button280_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button280.Click
        Button280.BackColor = Color.Red
        Button280.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button278_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button278.Click
        Button278.BackColor = Color.Red
        Button278.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button277_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button277.Click
        Button277.BackColor = Color.Red
        Button277.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button276_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button276.Click
        Button276.BackColor = Color.Red
        Button276.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button275_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button275.Click
        Button275.BackColor = Color.Red
        Button275.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button274_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button274.Click
        Button274.BackColor = Color.Red
        Button274.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button273_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button273.Click
        Button273.BackColor = Color.Red
        Button273.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button272_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button272.Click
        Button272.BackColor = Color.Red
        Button272.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button271_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button271.Click
        Button271.BackColor = Color.Red
        Button271.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button269_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button269.Click
        Button269.BackColor = Color.Red
        Button269.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button268_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button268.Click
        Button268.BackColor = Color.Red
        Button268.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button267_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button267.Click
        Button267.BackColor = Color.Red
        Button267.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button266_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button266.Click
        Button266.BackColor = Color.Red
        Button266.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button265_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button265.Click
        Button265.BackColor = Color.Red
        Button265.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button264_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button264.Click
        Button264.BackColor = Color.Red
        Button264.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button263_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button263.Click
        Button263.BackColor = Color.Red
        Button263.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button262_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button262.Click
        Button262.BackColor = Color.Red
        Button262.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button261_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button261.Click
        Button261.BackColor = Color.Red
        Button261.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button299_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button299.Click
        Button299.BackColor = Color.Red
        Button299.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button298_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button298.Click
        Button298.BackColor = Color.Red
        Button298.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button297_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button297.Click
        Button297.BackColor = Color.Red
        Button297.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button296_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button296.Click
        Button296.BackColor = Color.Red
        Button296.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button295_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button295.Click
        Button295.BackColor = Color.Red
        Button295.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button294_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button294.Click
        Button294.BackColor = Color.Red
        Button294.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button293_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button293.Click
        Button293.BackColor = Color.Red
        Button293.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button292_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button292.Click
        Button292.BackColor = Color.Red
        Button292.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button290_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button290.Click
        Button290.BackColor = Color.Red
        Button290.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button289_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button289.Click
        Button289.BackColor = Color.Red
        Button289.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button288_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button288.Click
        Button288.BackColor = Color.Red
        Button288.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button287_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button287.Click
        Button287.BackColor = Color.Red
        Button287.Enabled = False
        TextBox12.Text = Val(TextBox12.Text) + 1
        If Val(TextBox12.Text) = 5 Then
            Me.Hide()
            Form30.Show()
            Timer1.Stop()
        End If
    End Sub

    Private Sub Button244_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button244.Click

    End Sub

    Private Sub Form31_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play("C:\Users\Sheryl\Documents\Visual Studio 2010\Projects\WindowsApplication2\Music\TV_Show_Intro.wav")
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.ProgressBar1.Value += 2
        If Me.ProgressBar1.Value <= 5 Then
        ElseIf Me.ProgressBar1.Value <= 10 Then
        ElseIf Me.ProgressBar1.Value <= 15 Then
        ElseIf Me.ProgressBar1.Value <= 20 Then
        ElseIf Me.ProgressBar1.Value <= 25 Then
        ElseIf Me.ProgressBar1.Value <= 30 Then
        ElseIf Me.ProgressBar1.Value <= 35 Then
        ElseIf Me.ProgressBar1.Value <= 40 Then
        ElseIf Me.ProgressBar1.Value <= 45 Then
        ElseIf Me.ProgressBar1.Value <= 50 Then
        ElseIf Me.ProgressBar1.Value <= 60 Then
        ElseIf Me.ProgressBar1.Value <= 70 Then
        ElseIf Me.ProgressBar1.Value <= 80 Then
        ElseIf Me.ProgressBar1.Value <= 90 Then
            If Val(TextBox6.Text) = Val(TextBox6.Text) = 5 Then
                ProgressBar1.Dispose()
                Me.Hide()
                Form25.Hide()
                Form27.Show()
            End If
            If Me.ProgressBar1.Value <= 100 Then
                Form30.Show()
                Me.Hide()
                Me.Timer1.Dispose()

            End If
        End If
    End Sub
End Class