﻿Public Class Form25

    Private Property starterForm As Object

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim Form24 As New Form24
        Me.Dispose()
        Form24.Show()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Hide()
        Application.Restart()
    End Sub


    Private Sub Form25_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play("C:\Users\Sheryl\Documents\Visual Studio 2010\Projects\WindowsApplication2\Music\Game_Over_Sound_Effects_High_Quality.wav")
    End Sub
End Class