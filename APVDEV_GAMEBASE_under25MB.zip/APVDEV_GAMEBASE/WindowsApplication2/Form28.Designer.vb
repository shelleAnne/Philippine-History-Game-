﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form28
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form28))
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Button57 = New System.Windows.Forms.Button()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.Button61 = New System.Windows.Forms.Button()
        Me.Button62 = New System.Windows.Forms.Button()
        Me.Button63 = New System.Windows.Forms.Button()
        Me.Button64 = New System.Windows.Forms.Button()
        Me.Button65 = New System.Windows.Forms.Button()
        Me.Button66 = New System.Windows.Forms.Button()
        Me.Button67 = New System.Windows.Forms.Button()
        Me.Button68 = New System.Windows.Forms.Button()
        Me.Button69 = New System.Windows.Forms.Button()
        Me.Button70 = New System.Windows.Forms.Button()
        Me.Button71 = New System.Windows.Forms.Button()
        Me.Button72 = New System.Windows.Forms.Button()
        Me.Button73 = New System.Windows.Forms.Button()
        Me.Button74 = New System.Windows.Forms.Button()
        Me.Button75 = New System.Windows.Forms.Button()
        Me.Button76 = New System.Windows.Forms.Button()
        Me.Button77 = New System.Windows.Forms.Button()
        Me.Button78 = New System.Windows.Forms.Button()
        Me.Button79 = New System.Windows.Forms.Button()
        Me.Button80 = New System.Windows.Forms.Button()
        Me.Button81 = New System.Windows.Forms.Button()
        Me.Button82 = New System.Windows.Forms.Button()
        Me.Button83 = New System.Windows.Forms.Button()
        Me.Button84 = New System.Windows.Forms.Button()
        Me.Button85 = New System.Windows.Forms.Button()
        Me.Button86 = New System.Windows.Forms.Button()
        Me.Button87 = New System.Windows.Forms.Button()
        Me.Button88 = New System.Windows.Forms.Button()
        Me.Button89 = New System.Windows.Forms.Button()
        Me.Button90 = New System.Windows.Forms.Button()
        Me.Button91 = New System.Windows.Forms.Button()
        Me.Button92 = New System.Windows.Forms.Button()
        Me.Button93 = New System.Windows.Forms.Button()
        Me.Button94 = New System.Windows.Forms.Button()
        Me.Button95 = New System.Windows.Forms.Button()
        Me.Button96 = New System.Windows.Forms.Button()
        Me.Button97 = New System.Windows.Forms.Button()
        Me.Button98 = New System.Windows.Forms.Button()
        Me.Button99 = New System.Windows.Forms.Button()
        Me.Button100 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button2.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(218, 13)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(45, 45)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "B"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(260, 13)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(45, 45)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "A"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button3.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(303, 13)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(45, 45)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "M"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button4.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(345, 13)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(45, 45)
        Me.Button4.TabIndex = 5
        Me.Button4.Text = "A"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button5.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(387, 13)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(45, 45)
        Me.Button5.TabIndex = 6
        Me.Button5.Text = "S"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button6.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(599, 13)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(45, 45)
        Me.Button6.TabIndex = 11
        Me.Button6.Text = "L"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button7.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.White
        Me.Button7.Location = New System.Drawing.Point(557, 13)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(45, 45)
        Me.Button7.TabIndex = 10
        Me.Button7.Text = "G"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button8.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Location = New System.Drawing.Point(515, 13)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(45, 45)
        Me.Button8.TabIndex = 9
        Me.Button8.Text = "A"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button9.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.White
        Me.Button9.Location = New System.Drawing.Point(472, 13)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(45, 45)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "P"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button10.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.White
        Me.Button10.Location = New System.Drawing.Point(430, 13)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(45, 45)
        Me.Button10.TabIndex = 7
        Me.Button10.Text = "I"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button11.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.White
        Me.Button11.Location = New System.Drawing.Point(599, 53)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(45, 45)
        Me.Button11.TabIndex = 21
        Me.Button11.Text = "B"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button12.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.ForeColor = System.Drawing.Color.White
        Me.Button12.Location = New System.Drawing.Point(557, 53)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(45, 45)
        Me.Button12.TabIndex = 20
        Me.Button12.Text = "I"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button13.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = System.Drawing.Color.White
        Me.Button13.Location = New System.Drawing.Point(515, 53)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(45, 45)
        Me.Button13.TabIndex = 19
        Me.Button13.Text = "A"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button14.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.ForeColor = System.Drawing.Color.White
        Me.Button14.Location = New System.Drawing.Point(472, 53)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(45, 45)
        Me.Button14.TabIndex = 18
        Me.Button14.Text = "D"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button15.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.ForeColor = System.Drawing.Color.White
        Me.Button15.Location = New System.Drawing.Point(430, 53)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(45, 45)
        Me.Button15.TabIndex = 17
        Me.Button15.Text = "A"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button16.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.ForeColor = System.Drawing.Color.White
        Me.Button16.Location = New System.Drawing.Point(387, 53)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(45, 45)
        Me.Button16.TabIndex = 16
        Me.Button16.Text = "M"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button17.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.ForeColor = System.Drawing.Color.White
        Me.Button17.Location = New System.Drawing.Point(345, 53)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(45, 45)
        Me.Button17.TabIndex = 15
        Me.Button17.Text = "A"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button18.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.ForeColor = System.Drawing.Color.White
        Me.Button18.Location = New System.Drawing.Point(303, 53)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(45, 45)
        Me.Button18.TabIndex = 14
        Me.Button18.Text = "T"
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button19.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.ForeColor = System.Drawing.Color.White
        Me.Button19.Location = New System.Drawing.Point(260, 53)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(45, 45)
        Me.Button19.TabIndex = 13
        Me.Button19.Text = "A"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button20.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.ForeColor = System.Drawing.Color.White
        Me.Button20.Location = New System.Drawing.Point(218, 53)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(45, 45)
        Me.Button20.TabIndex = 12
        Me.Button20.Text = "I"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button21.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.ForeColor = System.Drawing.Color.White
        Me.Button21.Location = New System.Drawing.Point(599, 94)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(45, 45)
        Me.Button21.TabIndex = 31
        Me.Button21.Text = "A"
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button22.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.ForeColor = System.Drawing.Color.White
        Me.Button22.Location = New System.Drawing.Point(557, 94)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(45, 45)
        Me.Button22.TabIndex = 30
        Me.Button22.Text = "A"
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button23
        '
        Me.Button23.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button23.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.ForeColor = System.Drawing.Color.White
        Me.Button23.Location = New System.Drawing.Point(515, 94)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(45, 45)
        Me.Button23.TabIndex = 29
        Me.Button23.Text = "B"
        Me.Button23.UseVisualStyleBackColor = False
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button24.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.ForeColor = System.Drawing.Color.White
        Me.Button24.Location = New System.Drawing.Point(472, 94)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(45, 45)
        Me.Button24.TabIndex = 28
        Me.Button24.Text = "A"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button25.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.ForeColor = System.Drawing.Color.White
        Me.Button25.Location = New System.Drawing.Point(430, 94)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(45, 45)
        Me.Button25.TabIndex = 27
        Me.Button25.Text = "A"
        Me.Button25.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button26.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.ForeColor = System.Drawing.Color.White
        Me.Button26.Location = New System.Drawing.Point(387, 94)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(45, 45)
        Me.Button26.TabIndex = 26
        Me.Button26.Text = "A"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Button27
        '
        Me.Button27.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button27.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.ForeColor = System.Drawing.Color.White
        Me.Button27.Location = New System.Drawing.Point(345, 94)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(45, 45)
        Me.Button27.TabIndex = 25
        Me.Button27.Text = "A"
        Me.Button27.UseVisualStyleBackColor = False
        '
        'Button28
        '
        Me.Button28.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button28.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.ForeColor = System.Drawing.Color.White
        Me.Button28.Location = New System.Drawing.Point(303, 94)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(45, 45)
        Me.Button28.TabIndex = 24
        Me.Button28.Text = "S"
        Me.Button28.UseVisualStyleBackColor = False
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button29.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.ForeColor = System.Drawing.Color.White
        Me.Button29.Location = New System.Drawing.Point(260, 94)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(45, 45)
        Me.Button29.TabIndex = 23
        Me.Button29.Text = "A"
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button30.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button30.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.ForeColor = System.Drawing.Color.White
        Me.Button30.Location = New System.Drawing.Point(218, 94)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(45, 45)
        Me.Button30.TabIndex = 22
        Me.Button30.Text = "N"
        Me.Button30.UseVisualStyleBackColor = False
        '
        'Button31
        '
        Me.Button31.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button31.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.ForeColor = System.Drawing.Color.White
        Me.Button31.Location = New System.Drawing.Point(599, 136)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(45, 45)
        Me.Button31.TabIndex = 41
        Me.Button31.Text = "B"
        Me.Button31.UseVisualStyleBackColor = False
        '
        'Button32
        '
        Me.Button32.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button32.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button32.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button32.ForeColor = System.Drawing.Color.White
        Me.Button32.Location = New System.Drawing.Point(557, 136)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(45, 45)
        Me.Button32.TabIndex = 40
        Me.Button32.Text = "A"
        Me.Button32.UseVisualStyleBackColor = False
        '
        'Button33
        '
        Me.Button33.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button33.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button33.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button33.ForeColor = System.Drawing.Color.White
        Me.Button33.Location = New System.Drawing.Point(515, 136)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(45, 45)
        Me.Button33.TabIndex = 39
        Me.Button33.Text = "A"
        Me.Button33.UseVisualStyleBackColor = False
        '
        'Button34
        '
        Me.Button34.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button34.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button34.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button34.ForeColor = System.Drawing.Color.White
        Me.Button34.Location = New System.Drawing.Point(472, 136)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(45, 45)
        Me.Button34.TabIndex = 38
        Me.Button34.Text = "R"
        Me.Button34.UseVisualStyleBackColor = False
        '
        'Button35
        '
        Me.Button35.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button35.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button35.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button35.ForeColor = System.Drawing.Color.White
        Me.Button35.Location = New System.Drawing.Point(430, 136)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(45, 45)
        Me.Button35.TabIndex = 37
        Me.Button35.Text = "A"
        Me.Button35.UseVisualStyleBackColor = False
        '
        'Button36
        '
        Me.Button36.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button36.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button36.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button36.ForeColor = System.Drawing.Color.White
        Me.Button36.Location = New System.Drawing.Point(387, 136)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(45, 45)
        Me.Button36.TabIndex = 36
        Me.Button36.Text = "A"
        Me.Button36.UseVisualStyleBackColor = False
        '
        'Button37
        '
        Me.Button37.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button37.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button37.ForeColor = System.Drawing.Color.White
        Me.Button37.Location = New System.Drawing.Point(345, 136)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(45, 45)
        Me.Button37.TabIndex = 35
        Me.Button37.Text = "I"
        Me.Button37.UseVisualStyleBackColor = False
        '
        'Button38
        '
        Me.Button38.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button38.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button38.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button38.ForeColor = System.Drawing.Color.White
        Me.Button38.Location = New System.Drawing.Point(303, 136)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(45, 45)
        Me.Button38.TabIndex = 34
        Me.Button38.Text = "M"
        Me.Button38.UseVisualStyleBackColor = False
        '
        'Button39
        '
        Me.Button39.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button39.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button39.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button39.ForeColor = System.Drawing.Color.White
        Me.Button39.Location = New System.Drawing.Point(260, 136)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(45, 45)
        Me.Button39.TabIndex = 33
        Me.Button39.Text = "S"
        Me.Button39.UseVisualStyleBackColor = False
        '
        'Button40
        '
        Me.Button40.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button40.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button40.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button40.ForeColor = System.Drawing.Color.White
        Me.Button40.Location = New System.Drawing.Point(218, 136)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(45, 45)
        Me.Button40.TabIndex = 32
        Me.Button40.Text = "I"
        Me.Button40.UseVisualStyleBackColor = False
        '
        'Button41
        '
        Me.Button41.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button41.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button41.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button41.ForeColor = System.Drawing.Color.White
        Me.Button41.Location = New System.Drawing.Point(599, 177)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(45, 45)
        Me.Button41.TabIndex = 51
        Me.Button41.Text = "A"
        Me.Button41.UseVisualStyleBackColor = False
        '
        'Button42
        '
        Me.Button42.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button42.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button42.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button42.ForeColor = System.Drawing.Color.White
        Me.Button42.Location = New System.Drawing.Point(557, 177)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(45, 45)
        Me.Button42.TabIndex = 50
        Me.Button42.Text = "S"
        Me.Button42.UseVisualStyleBackColor = False
        '
        'Button43
        '
        Me.Button43.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button43.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button43.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button43.ForeColor = System.Drawing.Color.White
        Me.Button43.Location = New System.Drawing.Point(515, 177)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(45, 45)
        Me.Button43.TabIndex = 49
        Me.Button43.Text = "A"
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button44.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button44.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button44.ForeColor = System.Drawing.Color.White
        Me.Button44.Location = New System.Drawing.Point(472, 177)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(45, 45)
        Me.Button44.TabIndex = 48
        Me.Button44.Text = "A"
        Me.Button44.UseVisualStyleBackColor = False
        '
        'Button45
        '
        Me.Button45.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button45.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button45.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button45.ForeColor = System.Drawing.Color.White
        Me.Button45.Location = New System.Drawing.Point(430, 177)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(45, 45)
        Me.Button45.TabIndex = 47
        Me.Button45.Text = "O"
        Me.Button45.UseVisualStyleBackColor = False
        '
        'Button46
        '
        Me.Button46.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button46.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button46.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button46.ForeColor = System.Drawing.Color.White
        Me.Button46.Location = New System.Drawing.Point(387, 177)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(45, 45)
        Me.Button46.TabIndex = 46
        Me.Button46.Text = "L"
        Me.Button46.UseVisualStyleBackColor = False
        '
        'Button47
        '
        Me.Button47.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button47.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button47.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button47.ForeColor = System.Drawing.Color.White
        Me.Button47.Location = New System.Drawing.Point(345, 177)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(45, 45)
        Me.Button47.TabIndex = 45
        Me.Button47.Text = "L"
        Me.Button47.UseVisualStyleBackColor = False
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button48.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button48.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button48.ForeColor = System.Drawing.Color.White
        Me.Button48.Location = New System.Drawing.Point(303, 177)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(45, 45)
        Me.Button48.TabIndex = 44
        Me.Button48.Text = "A"
        Me.Button48.UseVisualStyleBackColor = False
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button49.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button49.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button49.ForeColor = System.Drawing.Color.White
        Me.Button49.Location = New System.Drawing.Point(260, 177)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(45, 45)
        Me.Button49.TabIndex = 43
        Me.Button49.Text = "W"
        Me.Button49.UseVisualStyleBackColor = False
        '
        'Button50
        '
        Me.Button50.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button50.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button50.ForeColor = System.Drawing.Color.White
        Me.Button50.Location = New System.Drawing.Point(218, 177)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(45, 45)
        Me.Button50.TabIndex = 42
        Me.Button50.Text = "B"
        Me.Button50.UseVisualStyleBackColor = False
        '
        'Button51
        '
        Me.Button51.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button51.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button51.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button51.ForeColor = System.Drawing.Color.White
        Me.Button51.Location = New System.Drawing.Point(599, 383)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(45, 45)
        Me.Button51.TabIndex = 101
        Me.Button51.Text = "A"
        Me.Button51.UseVisualStyleBackColor = False
        '
        'Button52
        '
        Me.Button52.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button52.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button52.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button52.ForeColor = System.Drawing.Color.White
        Me.Button52.Location = New System.Drawing.Point(557, 383)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(45, 45)
        Me.Button52.TabIndex = 100
        Me.Button52.Text = "L"
        Me.Button52.UseVisualStyleBackColor = False
        '
        'Button53
        '
        Me.Button53.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button53.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button53.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button53.ForeColor = System.Drawing.Color.White
        Me.Button53.Location = New System.Drawing.Point(515, 383)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(45, 45)
        Me.Button53.TabIndex = 99
        Me.Button53.Text = "A"
        Me.Button53.UseVisualStyleBackColor = False
        '
        'Button54
        '
        Me.Button54.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button54.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button54.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button54.ForeColor = System.Drawing.Color.White
        Me.Button54.Location = New System.Drawing.Point(472, 383)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(45, 45)
        Me.Button54.TabIndex = 98
        Me.Button54.Text = "A"
        Me.Button54.UseVisualStyleBackColor = False
        '
        'Button55
        '
        Me.Button55.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button55.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button55.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button55.ForeColor = System.Drawing.Color.White
        Me.Button55.Location = New System.Drawing.Point(430, 383)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(45, 45)
        Me.Button55.TabIndex = 97
        Me.Button55.Text = "A"
        Me.Button55.UseVisualStyleBackColor = False
        '
        'Button56
        '
        Me.Button56.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button56.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button56.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button56.ForeColor = System.Drawing.Color.White
        Me.Button56.Location = New System.Drawing.Point(387, 383)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(45, 45)
        Me.Button56.TabIndex = 96
        Me.Button56.Text = "P"
        Me.Button56.UseVisualStyleBackColor = False
        '
        'Button57
        '
        Me.Button57.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button57.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button57.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button57.ForeColor = System.Drawing.Color.White
        Me.Button57.Location = New System.Drawing.Point(345, 383)
        Me.Button57.Name = "Button57"
        Me.Button57.Size = New System.Drawing.Size(45, 45)
        Me.Button57.TabIndex = 95
        Me.Button57.Text = "I"
        Me.Button57.UseVisualStyleBackColor = False
        '
        'Button58
        '
        Me.Button58.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button58.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button58.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button58.ForeColor = System.Drawing.Color.White
        Me.Button58.Location = New System.Drawing.Point(303, 383)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(45, 45)
        Me.Button58.TabIndex = 94
        Me.Button58.Text = "A"
        Me.Button58.UseVisualStyleBackColor = False
        '
        'Button59
        '
        Me.Button59.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button59.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button59.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button59.ForeColor = System.Drawing.Color.White
        Me.Button59.Location = New System.Drawing.Point(260, 383)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(45, 45)
        Me.Button59.TabIndex = 93
        Me.Button59.Text = "A"
        Me.Button59.UseVisualStyleBackColor = False
        '
        'Button60
        '
        Me.Button60.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button60.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button60.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button60.ForeColor = System.Drawing.Color.White
        Me.Button60.Location = New System.Drawing.Point(218, 383)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(45, 45)
        Me.Button60.TabIndex = 92
        Me.Button60.Text = "X"
        Me.Button60.UseVisualStyleBackColor = False
        '
        'Button61
        '
        Me.Button61.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button61.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button61.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button61.ForeColor = System.Drawing.Color.White
        Me.Button61.Location = New System.Drawing.Point(599, 342)
        Me.Button61.Name = "Button61"
        Me.Button61.Size = New System.Drawing.Size(45, 45)
        Me.Button61.TabIndex = 91
        Me.Button61.Text = "A"
        Me.Button61.UseVisualStyleBackColor = False
        '
        'Button62
        '
        Me.Button62.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button62.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button62.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button62.ForeColor = System.Drawing.Color.White
        Me.Button62.Location = New System.Drawing.Point(557, 342)
        Me.Button62.Name = "Button62"
        Me.Button62.Size = New System.Drawing.Size(45, 45)
        Me.Button62.TabIndex = 90
        Me.Button62.Text = "A"
        Me.Button62.UseVisualStyleBackColor = False
        '
        'Button63
        '
        Me.Button63.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button63.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button63.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button63.ForeColor = System.Drawing.Color.White
        Me.Button63.Location = New System.Drawing.Point(515, 342)
        Me.Button63.Name = "Button63"
        Me.Button63.Size = New System.Drawing.Size(45, 45)
        Me.Button63.TabIndex = 89
        Me.Button63.Text = "A"
        Me.Button63.UseVisualStyleBackColor = False
        '
        'Button64
        '
        Me.Button64.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button64.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button64.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button64.ForeColor = System.Drawing.Color.White
        Me.Button64.Location = New System.Drawing.Point(472, 342)
        Me.Button64.Name = "Button64"
        Me.Button64.Size = New System.Drawing.Size(45, 45)
        Me.Button64.TabIndex = 88
        Me.Button64.Text = "A"
        Me.Button64.UseVisualStyleBackColor = False
        '
        'Button65
        '
        Me.Button65.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button65.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button65.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button65.ForeColor = System.Drawing.Color.White
        Me.Button65.Location = New System.Drawing.Point(430, 342)
        Me.Button65.Name = "Button65"
        Me.Button65.Size = New System.Drawing.Size(45, 45)
        Me.Button65.TabIndex = 87
        Me.Button65.Text = "A"
        Me.Button65.UseVisualStyleBackColor = False
        '
        'Button66
        '
        Me.Button66.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button66.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button66.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button66.ForeColor = System.Drawing.Color.White
        Me.Button66.Location = New System.Drawing.Point(387, 342)
        Me.Button66.Name = "Button66"
        Me.Button66.Size = New System.Drawing.Size(45, 45)
        Me.Button66.TabIndex = 86
        Me.Button66.Text = "B"
        Me.Button66.UseVisualStyleBackColor = False
        '
        'Button67
        '
        Me.Button67.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button67.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button67.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button67.ForeColor = System.Drawing.Color.White
        Me.Button67.Location = New System.Drawing.Point(345, 342)
        Me.Button67.Name = "Button67"
        Me.Button67.Size = New System.Drawing.Size(45, 45)
        Me.Button67.TabIndex = 85
        Me.Button67.Text = "K"
        Me.Button67.UseVisualStyleBackColor = False
        '
        'Button68
        '
        Me.Button68.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button68.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button68.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button68.ForeColor = System.Drawing.Color.White
        Me.Button68.Location = New System.Drawing.Point(303, 342)
        Me.Button68.Name = "Button68"
        Me.Button68.Size = New System.Drawing.Size(45, 45)
        Me.Button68.TabIndex = 84
        Me.Button68.Text = "D"
        Me.Button68.UseVisualStyleBackColor = False
        '
        'Button69
        '
        Me.Button69.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button69.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button69.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button69.ForeColor = System.Drawing.Color.White
        Me.Button69.Location = New System.Drawing.Point(260, 342)
        Me.Button69.Name = "Button69"
        Me.Button69.Size = New System.Drawing.Size(45, 45)
        Me.Button69.TabIndex = 83
        Me.Button69.Text = "E"
        Me.Button69.UseVisualStyleBackColor = False
        '
        'Button70
        '
        Me.Button70.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button70.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button70.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button70.ForeColor = System.Drawing.Color.White
        Me.Button70.Location = New System.Drawing.Point(218, 342)
        Me.Button70.Name = "Button70"
        Me.Button70.Size = New System.Drawing.Size(45, 45)
        Me.Button70.TabIndex = 82
        Me.Button70.Text = "A"
        Me.Button70.UseVisualStyleBackColor = False
        '
        'Button71
        '
        Me.Button71.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button71.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button71.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button71.ForeColor = System.Drawing.Color.White
        Me.Button71.Location = New System.Drawing.Point(599, 300)
        Me.Button71.Name = "Button71"
        Me.Button71.Size = New System.Drawing.Size(45, 45)
        Me.Button71.TabIndex = 81
        Me.Button71.Text = "A"
        Me.Button71.UseVisualStyleBackColor = False
        '
        'Button72
        '
        Me.Button72.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button72.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button72.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button72.ForeColor = System.Drawing.Color.White
        Me.Button72.Location = New System.Drawing.Point(557, 300)
        Me.Button72.Name = "Button72"
        Me.Button72.Size = New System.Drawing.Size(45, 45)
        Me.Button72.TabIndex = 80
        Me.Button72.Text = "A"
        Me.Button72.UseVisualStyleBackColor = False
        '
        'Button73
        '
        Me.Button73.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button73.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button73.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button73.ForeColor = System.Drawing.Color.White
        Me.Button73.Location = New System.Drawing.Point(515, 300)
        Me.Button73.Name = "Button73"
        Me.Button73.Size = New System.Drawing.Size(45, 45)
        Me.Button73.TabIndex = 79
        Me.Button73.Text = "A"
        Me.Button73.UseVisualStyleBackColor = False
        '
        'Button74
        '
        Me.Button74.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button74.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button74.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button74.ForeColor = System.Drawing.Color.White
        Me.Button74.Location = New System.Drawing.Point(472, 300)
        Me.Button74.Name = "Button74"
        Me.Button74.Size = New System.Drawing.Size(45, 45)
        Me.Button74.TabIndex = 78
        Me.Button74.Text = "H"
        Me.Button74.UseVisualStyleBackColor = False
        '
        'Button75
        '
        Me.Button75.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button75.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button75.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button75.ForeColor = System.Drawing.Color.White
        Me.Button75.Location = New System.Drawing.Point(430, 300)
        Me.Button75.Name = "Button75"
        Me.Button75.Size = New System.Drawing.Size(45, 45)
        Me.Button75.TabIndex = 77
        Me.Button75.Text = "A"
        Me.Button75.UseVisualStyleBackColor = False
        '
        'Button76
        '
        Me.Button76.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button76.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button76.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button76.ForeColor = System.Drawing.Color.White
        Me.Button76.Location = New System.Drawing.Point(387, 300)
        Me.Button76.Name = "Button76"
        Me.Button76.Size = New System.Drawing.Size(45, 45)
        Me.Button76.TabIndex = 76
        Me.Button76.Text = "K"
        Me.Button76.UseVisualStyleBackColor = False
        '
        'Button77
        '
        Me.Button77.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button77.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button77.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button77.ForeColor = System.Drawing.Color.White
        Me.Button77.Location = New System.Drawing.Point(345, 300)
        Me.Button77.Name = "Button77"
        Me.Button77.Size = New System.Drawing.Size(45, 45)
        Me.Button77.TabIndex = 75
        Me.Button77.Text = "A"
        Me.Button77.UseVisualStyleBackColor = False
        '
        'Button78
        '
        Me.Button78.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button78.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button78.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button78.ForeColor = System.Drawing.Color.White
        Me.Button78.Location = New System.Drawing.Point(303, 300)
        Me.Button78.Name = "Button78"
        Me.Button78.Size = New System.Drawing.Size(45, 45)
        Me.Button78.TabIndex = 74
        Me.Button78.Text = "N"
        Me.Button78.UseVisualStyleBackColor = False
        '
        'Button79
        '
        Me.Button79.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button79.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button79.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button79.ForeColor = System.Drawing.Color.White
        Me.Button79.Location = New System.Drawing.Point(260, 300)
        Me.Button79.Name = "Button79"
        Me.Button79.Size = New System.Drawing.Size(45, 45)
        Me.Button79.TabIndex = 73
        Me.Button79.Text = "T"
        Me.Button79.UseVisualStyleBackColor = False
        '
        'Button80
        '
        Me.Button80.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button80.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button80.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button80.ForeColor = System.Drawing.Color.White
        Me.Button80.Location = New System.Drawing.Point(218, 300)
        Me.Button80.Name = "Button80"
        Me.Button80.Size = New System.Drawing.Size(45, 45)
        Me.Button80.TabIndex = 72
        Me.Button80.Text = "I"
        Me.Button80.UseVisualStyleBackColor = False
        '
        'Button81
        '
        Me.Button81.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button81.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button81.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button81.ForeColor = System.Drawing.Color.White
        Me.Button81.Location = New System.Drawing.Point(599, 259)
        Me.Button81.Name = "Button81"
        Me.Button81.Size = New System.Drawing.Size(45, 45)
        Me.Button81.TabIndex = 71
        Me.Button81.Text = "A"
        Me.Button81.UseVisualStyleBackColor = False
        '
        'Button82
        '
        Me.Button82.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button82.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button82.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button82.ForeColor = System.Drawing.Color.White
        Me.Button82.Location = New System.Drawing.Point(557, 259)
        Me.Button82.Name = "Button82"
        Me.Button82.Size = New System.Drawing.Size(45, 45)
        Me.Button82.TabIndex = 70
        Me.Button82.Text = "E"
        Me.Button82.UseVisualStyleBackColor = False
        '
        'Button83
        '
        Me.Button83.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button83.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button83.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button83.ForeColor = System.Drawing.Color.White
        Me.Button83.Location = New System.Drawing.Point(515, 259)
        Me.Button83.Name = "Button83"
        Me.Button83.Size = New System.Drawing.Size(45, 45)
        Me.Button83.TabIndex = 69
        Me.Button83.Text = "A"
        Me.Button83.UseVisualStyleBackColor = False
        '
        'Button84
        '
        Me.Button84.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button84.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button84.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button84.ForeColor = System.Drawing.Color.White
        Me.Button84.Location = New System.Drawing.Point(472, 259)
        Me.Button84.Name = "Button84"
        Me.Button84.Size = New System.Drawing.Size(45, 45)
        Me.Button84.TabIndex = 68
        Me.Button84.Text = "D"
        Me.Button84.UseVisualStyleBackColor = False
        '
        'Button85
        '
        Me.Button85.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button85.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button85.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button85.ForeColor = System.Drawing.Color.White
        Me.Button85.Location = New System.Drawing.Point(430, 259)
        Me.Button85.Name = "Button85"
        Me.Button85.Size = New System.Drawing.Size(45, 45)
        Me.Button85.TabIndex = 67
        Me.Button85.Text = "A"
        Me.Button85.UseVisualStyleBackColor = False
        '
        'Button86
        '
        Me.Button86.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button86.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button86.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button86.ForeColor = System.Drawing.Color.White
        Me.Button86.Location = New System.Drawing.Point(387, 259)
        Me.Button86.Name = "Button86"
        Me.Button86.Size = New System.Drawing.Size(45, 45)
        Me.Button86.TabIndex = 66
        Me.Button86.Text = "S"
        Me.Button86.UseVisualStyleBackColor = False
        '
        'Button87
        '
        Me.Button87.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button87.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button87.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button87.ForeColor = System.Drawing.Color.White
        Me.Button87.Location = New System.Drawing.Point(345, 259)
        Me.Button87.Name = "Button87"
        Me.Button87.Size = New System.Drawing.Size(45, 45)
        Me.Button87.TabIndex = 65
        Me.Button87.Text = "L"
        Me.Button87.UseVisualStyleBackColor = False
        '
        'Button88
        '
        Me.Button88.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button88.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button88.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button88.ForeColor = System.Drawing.Color.White
        Me.Button88.Location = New System.Drawing.Point(303, 259)
        Me.Button88.Name = "Button88"
        Me.Button88.Size = New System.Drawing.Size(45, 45)
        Me.Button88.TabIndex = 64
        Me.Button88.Text = "A"
        Me.Button88.UseVisualStyleBackColor = False
        '
        'Button89
        '
        Me.Button89.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button89.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button89.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button89.ForeColor = System.Drawing.Color.White
        Me.Button89.Location = New System.Drawing.Point(260, 259)
        Me.Button89.Name = "Button89"
        Me.Button89.Size = New System.Drawing.Size(45, 45)
        Me.Button89.TabIndex = 63
        Me.Button89.Text = "R"
        Me.Button89.UseVisualStyleBackColor = False
        '
        'Button90
        '
        Me.Button90.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button90.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button90.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button90.ForeColor = System.Drawing.Color.White
        Me.Button90.Location = New System.Drawing.Point(218, 259)
        Me.Button90.Name = "Button90"
        Me.Button90.Size = New System.Drawing.Size(45, 45)
        Me.Button90.TabIndex = 62
        Me.Button90.Text = "N"
        Me.Button90.UseVisualStyleBackColor = False
        '
        'Button91
        '
        Me.Button91.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button91.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button91.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button91.ForeColor = System.Drawing.Color.White
        Me.Button91.Location = New System.Drawing.Point(599, 219)
        Me.Button91.Name = "Button91"
        Me.Button91.Size = New System.Drawing.Size(45, 45)
        Me.Button91.TabIndex = 61
        Me.Button91.Text = "E"
        Me.Button91.UseVisualStyleBackColor = False
        '
        'Button92
        '
        Me.Button92.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button92.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button92.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button92.ForeColor = System.Drawing.Color.White
        Me.Button92.Location = New System.Drawing.Point(557, 219)
        Me.Button92.Name = "Button92"
        Me.Button92.Size = New System.Drawing.Size(45, 45)
        Me.Button92.TabIndex = 60
        Me.Button92.Text = "W"
        Me.Button92.UseVisualStyleBackColor = False
        '
        'Button93
        '
        Me.Button93.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button93.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button93.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button93.ForeColor = System.Drawing.Color.White
        Me.Button93.Location = New System.Drawing.Point(515, 219)
        Me.Button93.Name = "Button93"
        Me.Button93.Size = New System.Drawing.Size(45, 45)
        Me.Button93.TabIndex = 59
        Me.Button93.Text = "A"
        Me.Button93.UseVisualStyleBackColor = False
        '
        'Button94
        '
        Me.Button94.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button94.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button94.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button94.ForeColor = System.Drawing.Color.White
        Me.Button94.Location = New System.Drawing.Point(472, 219)
        Me.Button94.Name = "Button94"
        Me.Button94.Size = New System.Drawing.Size(45, 45)
        Me.Button94.TabIndex = 58
        Me.Button94.Text = "A"
        Me.Button94.UseVisualStyleBackColor = False
        '
        'Button95
        '
        Me.Button95.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button95.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button95.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button95.ForeColor = System.Drawing.Color.White
        Me.Button95.Location = New System.Drawing.Point(430, 219)
        Me.Button95.Name = "Button95"
        Me.Button95.Size = New System.Drawing.Size(45, 45)
        Me.Button95.TabIndex = 57
        Me.Button95.Text = "I"
        Me.Button95.UseVisualStyleBackColor = False
        '
        'Button96
        '
        Me.Button96.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button96.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button96.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button96.ForeColor = System.Drawing.Color.White
        Me.Button96.Location = New System.Drawing.Point(387, 219)
        Me.Button96.Name = "Button96"
        Me.Button96.Size = New System.Drawing.Size(45, 45)
        Me.Button96.TabIndex = 56
        Me.Button96.Text = "M"
        Me.Button96.UseVisualStyleBackColor = False
        '
        'Button97
        '
        Me.Button97.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button97.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button97.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button97.ForeColor = System.Drawing.Color.White
        Me.Button97.Location = New System.Drawing.Point(345, 219)
        Me.Button97.Name = "Button97"
        Me.Button97.Size = New System.Drawing.Size(45, 45)
        Me.Button97.TabIndex = 55
        Me.Button97.Text = "A"
        Me.Button97.UseVisualStyleBackColor = False
        '
        'Button98
        '
        Me.Button98.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button98.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button98.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button98.ForeColor = System.Drawing.Color.White
        Me.Button98.Location = New System.Drawing.Point(303, 219)
        Me.Button98.Name = "Button98"
        Me.Button98.Size = New System.Drawing.Size(45, 45)
        Me.Button98.TabIndex = 54
        Me.Button98.Text = "G"
        Me.Button98.UseVisualStyleBackColor = False
        '
        'Button99
        '
        Me.Button99.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button99.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button99.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button99.ForeColor = System.Drawing.Color.White
        Me.Button99.Location = New System.Drawing.Point(260, 219)
        Me.Button99.Name = "Button99"
        Me.Button99.Size = New System.Drawing.Size(45, 45)
        Me.Button99.TabIndex = 53
        Me.Button99.Text = "E"
        Me.Button99.UseVisualStyleBackColor = False
        '
        'Button100
        '
        Me.Button100.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button100.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button100.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button100.ForeColor = System.Drawing.Color.White
        Me.Button100.Location = New System.Drawing.Point(218, 219)
        Me.Button100.Name = "Button100"
        Me.Button100.Size = New System.Drawing.Size(45, 45)
        Me.Button100.TabIndex = 52
        Me.Button100.Text = "I"
        Me.Button100.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(68, 45)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(99, 31)
        Me.Label2.TabIndex = 103
        Me.Label2.Text = "SILID"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label3.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(68, 94)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(110, 31)
        Me.Label3.TabIndex = 104
        Me.Label3.Text = "LIBRO"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label4.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(68, 138)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(121, 31)
        Me.Label4.TabIndex = 105
        Me.Label4.Text = "BABAE"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label5.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(68, 178)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(133, 31)
        Me.Label5.TabIndex = 106
        Me.Label5.Text = "LALAKI"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label6.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(68, 223)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(152, 31)
        Me.Label6.TabIndex = 107
        Me.Label6.Text = "BINIBINI"
        '
        'TextBox1
        '
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(26, 45)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(36, 29)
        Me.TextBox1.TabIndex = 108
        '
        'TextBox2
        '
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(26, 94)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(36, 29)
        Me.TextBox2.TabIndex = 109
        '
        'TextBox3
        '
        Me.TextBox3.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(26, 138)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(36, 29)
        Me.TextBox3.TabIndex = 110
        '
        'TextBox4
        '
        Me.TextBox4.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(26, 183)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(36, 29)
        Me.TextBox4.TabIndex = 111
        '
        'TextBox5
        '
        Me.TextBox5.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(26, 224)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(36, 29)
        Me.TextBox5.TabIndex = 112
        '
        'TextBox6
        '
        Me.TextBox6.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(817, 224)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(36, 29)
        Me.TextBox6.TabIndex = 122
        '
        'TextBox7
        '
        Me.TextBox7.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(817, 177)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(36, 29)
        Me.TextBox7.TabIndex = 121
        '
        'TextBox8
        '
        Me.TextBox8.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(817, 138)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(36, 29)
        Me.TextBox8.TabIndex = 120
        '
        'TextBox9
        '
        Me.TextBox9.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(817, 89)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(36, 29)
        Me.TextBox9.TabIndex = 119
        '
        'TextBox10
        '
        Me.TextBox10.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(817, 45)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(36, 29)
        Me.TextBox10.TabIndex = 118
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label7.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(669, 221)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(141, 31)
        Me.Label7.TabIndex = 117
        Me.Label7.Text = "SWERTE"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label8.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(676, 177)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(123, 31)
        Me.Label8.TabIndex = 116
        Me.Label8.Text = "TAMAD"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label9.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(662, 134)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(152, 31)
        Me.Label9.TabIndex = 115
        Me.Label9.Text = "MASIPAG"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label10.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(675, 87)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(128, 31)
        Me.Label10.TabIndex = 114
        Me.Label10.Text = "MAHAL"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label11.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.Location = New System.Drawing.Point(653, 45)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(167, 31)
        Me.Label11.TabIndex = 113
        Me.Label11.Text = "MAGANDA"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.White
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(763, 366)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(64, 55)
        Me.Label12.TabIndex = 128
        Me.Label12.Text = "/5"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.White
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(83, 376)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(70, 42)
        Me.Label13.TabIndex = 127
        Me.Label13.Text = "/10"
        '
        'TextBox11
        '
        Me.TextBox11.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.Location = New System.Drawing.Point(709, 363)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(121, 62)
        Me.TextBox11.TabIndex = 126
        Me.TextBox11.Text = " "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label14.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label14.Location = New System.Drawing.Point(725, 329)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(91, 31)
        Me.Label14.TabIndex = 125
        Me.Label14.Text = "Moves"
        '
        'TextBox12
        '
        Me.TextBox12.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(33, 366)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(122, 62)
        Me.TextBox12.TabIndex = 124
        Me.TextBox12.Text = " "
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.Transparent
        Me.Label15.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label15.Font = New System.Drawing.Font("Modern No. 20", 21.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label15.Location = New System.Drawing.Point(7, 331)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(193, 31)
        Me.Label15.TabIndex = 123
        Me.Label15.Text = "Words remain"
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(677, 276)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(165, 13)
        Me.ProgressBar1.TabIndex = 129
        '
        'Timer1
        '
        '
        'Form28
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightPink
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(864, 437)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button51)
        Me.Controls.Add(Me.Button52)
        Me.Controls.Add(Me.Button53)
        Me.Controls.Add(Me.Button54)
        Me.Controls.Add(Me.Button55)
        Me.Controls.Add(Me.Button56)
        Me.Controls.Add(Me.Button57)
        Me.Controls.Add(Me.Button58)
        Me.Controls.Add(Me.Button59)
        Me.Controls.Add(Me.Button60)
        Me.Controls.Add(Me.Button61)
        Me.Controls.Add(Me.Button62)
        Me.Controls.Add(Me.Button63)
        Me.Controls.Add(Me.Button64)
        Me.Controls.Add(Me.Button65)
        Me.Controls.Add(Me.Button66)
        Me.Controls.Add(Me.Button67)
        Me.Controls.Add(Me.Button68)
        Me.Controls.Add(Me.Button69)
        Me.Controls.Add(Me.Button70)
        Me.Controls.Add(Me.Button71)
        Me.Controls.Add(Me.Button72)
        Me.Controls.Add(Me.Button73)
        Me.Controls.Add(Me.Button74)
        Me.Controls.Add(Me.Button75)
        Me.Controls.Add(Me.Button76)
        Me.Controls.Add(Me.Button77)
        Me.Controls.Add(Me.Button78)
        Me.Controls.Add(Me.Button79)
        Me.Controls.Add(Me.Button80)
        Me.Controls.Add(Me.Button81)
        Me.Controls.Add(Me.Button82)
        Me.Controls.Add(Me.Button83)
        Me.Controls.Add(Me.Button84)
        Me.Controls.Add(Me.Button85)
        Me.Controls.Add(Me.Button86)
        Me.Controls.Add(Me.Button87)
        Me.Controls.Add(Me.Button88)
        Me.Controls.Add(Me.Button89)
        Me.Controls.Add(Me.Button90)
        Me.Controls.Add(Me.Button91)
        Me.Controls.Add(Me.Button92)
        Me.Controls.Add(Me.Button93)
        Me.Controls.Add(Me.Button94)
        Me.Controls.Add(Me.Button95)
        Me.Controls.Add(Me.Button96)
        Me.Controls.Add(Me.Button97)
        Me.Controls.Add(Me.Button98)
        Me.Controls.Add(Me.Button99)
        Me.Controls.Add(Me.Button100)
        Me.Controls.Add(Me.Button41)
        Me.Controls.Add(Me.Button42)
        Me.Controls.Add(Me.Button43)
        Me.Controls.Add(Me.Button44)
        Me.Controls.Add(Me.Button45)
        Me.Controls.Add(Me.Button46)
        Me.Controls.Add(Me.Button47)
        Me.Controls.Add(Me.Button48)
        Me.Controls.Add(Me.Button49)
        Me.Controls.Add(Me.Button50)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button35)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button38)
        Me.Controls.Add(Me.Button39)
        Me.Controls.Add(Me.Button40)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Name = "Form28"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form28"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Button46 As System.Windows.Forms.Button
    Friend WithEvents Button47 As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents Button51 As System.Windows.Forms.Button
    Friend WithEvents Button52 As System.Windows.Forms.Button
    Friend WithEvents Button53 As System.Windows.Forms.Button
    Friend WithEvents Button54 As System.Windows.Forms.Button
    Friend WithEvents Button55 As System.Windows.Forms.Button
    Friend WithEvents Button56 As System.Windows.Forms.Button
    Friend WithEvents Button57 As System.Windows.Forms.Button
    Friend WithEvents Button58 As System.Windows.Forms.Button
    Friend WithEvents Button59 As System.Windows.Forms.Button
    Friend WithEvents Button60 As System.Windows.Forms.Button
    Friend WithEvents Button61 As System.Windows.Forms.Button
    Friend WithEvents Button62 As System.Windows.Forms.Button
    Friend WithEvents Button63 As System.Windows.Forms.Button
    Friend WithEvents Button64 As System.Windows.Forms.Button
    Friend WithEvents Button65 As System.Windows.Forms.Button
    Friend WithEvents Button66 As System.Windows.Forms.Button
    Friend WithEvents Button67 As System.Windows.Forms.Button
    Friend WithEvents Button68 As System.Windows.Forms.Button
    Friend WithEvents Button69 As System.Windows.Forms.Button
    Friend WithEvents Button70 As System.Windows.Forms.Button
    Friend WithEvents Button71 As System.Windows.Forms.Button
    Friend WithEvents Button72 As System.Windows.Forms.Button
    Friend WithEvents Button73 As System.Windows.Forms.Button
    Friend WithEvents Button74 As System.Windows.Forms.Button
    Friend WithEvents Button75 As System.Windows.Forms.Button
    Friend WithEvents Button76 As System.Windows.Forms.Button
    Friend WithEvents Button77 As System.Windows.Forms.Button
    Friend WithEvents Button78 As System.Windows.Forms.Button
    Friend WithEvents Button79 As System.Windows.Forms.Button
    Friend WithEvents Button80 As System.Windows.Forms.Button
    Friend WithEvents Button81 As System.Windows.Forms.Button
    Friend WithEvents Button82 As System.Windows.Forms.Button
    Friend WithEvents Button83 As System.Windows.Forms.Button
    Friend WithEvents Button84 As System.Windows.Forms.Button
    Friend WithEvents Button85 As System.Windows.Forms.Button
    Friend WithEvents Button86 As System.Windows.Forms.Button
    Friend WithEvents Button87 As System.Windows.Forms.Button
    Friend WithEvents Button88 As System.Windows.Forms.Button
    Friend WithEvents Button89 As System.Windows.Forms.Button
    Friend WithEvents Button90 As System.Windows.Forms.Button
    Friend WithEvents Button91 As System.Windows.Forms.Button
    Friend WithEvents Button92 As System.Windows.Forms.Button
    Friend WithEvents Button93 As System.Windows.Forms.Button
    Friend WithEvents Button94 As System.Windows.Forms.Button
    Friend WithEvents Button95 As System.Windows.Forms.Button
    Friend WithEvents Button96 As System.Windows.Forms.Button
    Friend WithEvents Button97 As System.Windows.Forms.Button
    Friend WithEvents Button98 As System.Windows.Forms.Button
    Friend WithEvents Button99 As System.Windows.Forms.Button
    Friend WithEvents Button100 As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
