﻿Public Class Form12

    Property score As Integer
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Application.Restart()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If Form2.score = "10" Then
            Label1.Text = "Congratulation!! Your score is " & Form2.score & "out of 10"
        Else
            Label1.Text = "Your score is"
            Label2.Text = Form2.score + Form3.score + Form4.score + Form5.score + Form6.score + Form7.score + Form8.score + Form9.score + Form10.score
        End If
    End Sub


    Private Sub Form12_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play("C:\Users\Sheryl\Documents\Visual Studio 2010\Projects\WindowsApplication2\Music\Final_Fantasy_Victory_Fanfare_Sound_Effect_HQ_.wav")
    End Sub
End Class