﻿
Namespace Form24
    Class Show
        Inherits Exception

    End Class
End Namespace
