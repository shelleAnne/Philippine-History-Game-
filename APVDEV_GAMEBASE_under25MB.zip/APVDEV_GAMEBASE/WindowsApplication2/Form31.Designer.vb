﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form31
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form31))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.Button47 = New System.Windows.Forms.Button()
        Me.Button48 = New System.Windows.Forms.Button()
        Me.Button49 = New System.Windows.Forms.Button()
        Me.Button50 = New System.Windows.Forms.Button()
        Me.Button51 = New System.Windows.Forms.Button()
        Me.Button52 = New System.Windows.Forms.Button()
        Me.Button53 = New System.Windows.Forms.Button()
        Me.Button54 = New System.Windows.Forms.Button()
        Me.Button55 = New System.Windows.Forms.Button()
        Me.Button56 = New System.Windows.Forms.Button()
        Me.Button57 = New System.Windows.Forms.Button()
        Me.Button58 = New System.Windows.Forms.Button()
        Me.Button59 = New System.Windows.Forms.Button()
        Me.Button60 = New System.Windows.Forms.Button()
        Me.Button61 = New System.Windows.Forms.Button()
        Me.Button62 = New System.Windows.Forms.Button()
        Me.Button63 = New System.Windows.Forms.Button()
        Me.Button64 = New System.Windows.Forms.Button()
        Me.Button65 = New System.Windows.Forms.Button()
        Me.Button66 = New System.Windows.Forms.Button()
        Me.Button67 = New System.Windows.Forms.Button()
        Me.Button68 = New System.Windows.Forms.Button()
        Me.Button69 = New System.Windows.Forms.Button()
        Me.Button70 = New System.Windows.Forms.Button()
        Me.Button71 = New System.Windows.Forms.Button()
        Me.Button72 = New System.Windows.Forms.Button()
        Me.Button73 = New System.Windows.Forms.Button()
        Me.Button74 = New System.Windows.Forms.Button()
        Me.Button75 = New System.Windows.Forms.Button()
        Me.Button76 = New System.Windows.Forms.Button()
        Me.Button77 = New System.Windows.Forms.Button()
        Me.Button78 = New System.Windows.Forms.Button()
        Me.Button79 = New System.Windows.Forms.Button()
        Me.Button80 = New System.Windows.Forms.Button()
        Me.Button81 = New System.Windows.Forms.Button()
        Me.Button82 = New System.Windows.Forms.Button()
        Me.Button83 = New System.Windows.Forms.Button()
        Me.Button84 = New System.Windows.Forms.Button()
        Me.Button85 = New System.Windows.Forms.Button()
        Me.Button86 = New System.Windows.Forms.Button()
        Me.Button87 = New System.Windows.Forms.Button()
        Me.Button88 = New System.Windows.Forms.Button()
        Me.Button89 = New System.Windows.Forms.Button()
        Me.Button90 = New System.Windows.Forms.Button()
        Me.Button91 = New System.Windows.Forms.Button()
        Me.Button92 = New System.Windows.Forms.Button()
        Me.Button93 = New System.Windows.Forms.Button()
        Me.Button94 = New System.Windows.Forms.Button()
        Me.Button95 = New System.Windows.Forms.Button()
        Me.Button96 = New System.Windows.Forms.Button()
        Me.Button97 = New System.Windows.Forms.Button()
        Me.Button98 = New System.Windows.Forms.Button()
        Me.Button99 = New System.Windows.Forms.Button()
        Me.Button100 = New System.Windows.Forms.Button()
        Me.Button101 = New System.Windows.Forms.Button()
        Me.Button102 = New System.Windows.Forms.Button()
        Me.Button103 = New System.Windows.Forms.Button()
        Me.Button104 = New System.Windows.Forms.Button()
        Me.Button105 = New System.Windows.Forms.Button()
        Me.Button106 = New System.Windows.Forms.Button()
        Me.Button107 = New System.Windows.Forms.Button()
        Me.Button108 = New System.Windows.Forms.Button()
        Me.Button109 = New System.Windows.Forms.Button()
        Me.Button110 = New System.Windows.Forms.Button()
        Me.Button111 = New System.Windows.Forms.Button()
        Me.Button112 = New System.Windows.Forms.Button()
        Me.Button113 = New System.Windows.Forms.Button()
        Me.Button114 = New System.Windows.Forms.Button()
        Me.Button115 = New System.Windows.Forms.Button()
        Me.Button116 = New System.Windows.Forms.Button()
        Me.Button117 = New System.Windows.Forms.Button()
        Me.Button118 = New System.Windows.Forms.Button()
        Me.Button119 = New System.Windows.Forms.Button()
        Me.Button120 = New System.Windows.Forms.Button()
        Me.Button121 = New System.Windows.Forms.Button()
        Me.Button122 = New System.Windows.Forms.Button()
        Me.Button123 = New System.Windows.Forms.Button()
        Me.Button124 = New System.Windows.Forms.Button()
        Me.Button125 = New System.Windows.Forms.Button()
        Me.Button126 = New System.Windows.Forms.Button()
        Me.Button127 = New System.Windows.Forms.Button()
        Me.Button128 = New System.Windows.Forms.Button()
        Me.Button129 = New System.Windows.Forms.Button()
        Me.Button130 = New System.Windows.Forms.Button()
        Me.Button131 = New System.Windows.Forms.Button()
        Me.Button132 = New System.Windows.Forms.Button()
        Me.Button133 = New System.Windows.Forms.Button()
        Me.Button134 = New System.Windows.Forms.Button()
        Me.Button135 = New System.Windows.Forms.Button()
        Me.Button136 = New System.Windows.Forms.Button()
        Me.Button137 = New System.Windows.Forms.Button()
        Me.Button138 = New System.Windows.Forms.Button()
        Me.Button139 = New System.Windows.Forms.Button()
        Me.Button140 = New System.Windows.Forms.Button()
        Me.Button141 = New System.Windows.Forms.Button()
        Me.Button142 = New System.Windows.Forms.Button()
        Me.Button143 = New System.Windows.Forms.Button()
        Me.Button144 = New System.Windows.Forms.Button()
        Me.Button145 = New System.Windows.Forms.Button()
        Me.Button146 = New System.Windows.Forms.Button()
        Me.Button147 = New System.Windows.Forms.Button()
        Me.Button148 = New System.Windows.Forms.Button()
        Me.Button149 = New System.Windows.Forms.Button()
        Me.Button150 = New System.Windows.Forms.Button()
        Me.Button151 = New System.Windows.Forms.Button()
        Me.Button152 = New System.Windows.Forms.Button()
        Me.Button153 = New System.Windows.Forms.Button()
        Me.Button154 = New System.Windows.Forms.Button()
        Me.Button155 = New System.Windows.Forms.Button()
        Me.Button156 = New System.Windows.Forms.Button()
        Me.Button157 = New System.Windows.Forms.Button()
        Me.Button158 = New System.Windows.Forms.Button()
        Me.Button159 = New System.Windows.Forms.Button()
        Me.Button160 = New System.Windows.Forms.Button()
        Me.Button161 = New System.Windows.Forms.Button()
        Me.Button162 = New System.Windows.Forms.Button()
        Me.Button163 = New System.Windows.Forms.Button()
        Me.Button164 = New System.Windows.Forms.Button()
        Me.Button165 = New System.Windows.Forms.Button()
        Me.Button166 = New System.Windows.Forms.Button()
        Me.Button167 = New System.Windows.Forms.Button()
        Me.Button168 = New System.Windows.Forms.Button()
        Me.Button169 = New System.Windows.Forms.Button()
        Me.Button170 = New System.Windows.Forms.Button()
        Me.Button171 = New System.Windows.Forms.Button()
        Me.Button172 = New System.Windows.Forms.Button()
        Me.Button173 = New System.Windows.Forms.Button()
        Me.Button174 = New System.Windows.Forms.Button()
        Me.Button175 = New System.Windows.Forms.Button()
        Me.Button176 = New System.Windows.Forms.Button()
        Me.Button177 = New System.Windows.Forms.Button()
        Me.Button178 = New System.Windows.Forms.Button()
        Me.Button179 = New System.Windows.Forms.Button()
        Me.Button180 = New System.Windows.Forms.Button()
        Me.Button181 = New System.Windows.Forms.Button()
        Me.Button182 = New System.Windows.Forms.Button()
        Me.Button183 = New System.Windows.Forms.Button()
        Me.Button184 = New System.Windows.Forms.Button()
        Me.Button185 = New System.Windows.Forms.Button()
        Me.Button186 = New System.Windows.Forms.Button()
        Me.Button187 = New System.Windows.Forms.Button()
        Me.Button188 = New System.Windows.Forms.Button()
        Me.Button189 = New System.Windows.Forms.Button()
        Me.Button190 = New System.Windows.Forms.Button()
        Me.Button191 = New System.Windows.Forms.Button()
        Me.Button192 = New System.Windows.Forms.Button()
        Me.Button193 = New System.Windows.Forms.Button()
        Me.Button194 = New System.Windows.Forms.Button()
        Me.Button195 = New System.Windows.Forms.Button()
        Me.Button196 = New System.Windows.Forms.Button()
        Me.Button197 = New System.Windows.Forms.Button()
        Me.Button198 = New System.Windows.Forms.Button()
        Me.Button199 = New System.Windows.Forms.Button()
        Me.Button200 = New System.Windows.Forms.Button()
        Me.Button201 = New System.Windows.Forms.Button()
        Me.Button202 = New System.Windows.Forms.Button()
        Me.Button203 = New System.Windows.Forms.Button()
        Me.Button204 = New System.Windows.Forms.Button()
        Me.Button205 = New System.Windows.Forms.Button()
        Me.Button206 = New System.Windows.Forms.Button()
        Me.Button207 = New System.Windows.Forms.Button()
        Me.Button208 = New System.Windows.Forms.Button()
        Me.Button209 = New System.Windows.Forms.Button()
        Me.Button210 = New System.Windows.Forms.Button()
        Me.Button211 = New System.Windows.Forms.Button()
        Me.Button212 = New System.Windows.Forms.Button()
        Me.Button213 = New System.Windows.Forms.Button()
        Me.Button214 = New System.Windows.Forms.Button()
        Me.Button215 = New System.Windows.Forms.Button()
        Me.Button216 = New System.Windows.Forms.Button()
        Me.Button217 = New System.Windows.Forms.Button()
        Me.Button218 = New System.Windows.Forms.Button()
        Me.Button219 = New System.Windows.Forms.Button()
        Me.Button220 = New System.Windows.Forms.Button()
        Me.Button221 = New System.Windows.Forms.Button()
        Me.Button222 = New System.Windows.Forms.Button()
        Me.Button223 = New System.Windows.Forms.Button()
        Me.Button224 = New System.Windows.Forms.Button()
        Me.Button225 = New System.Windows.Forms.Button()
        Me.Button226 = New System.Windows.Forms.Button()
        Me.Button227 = New System.Windows.Forms.Button()
        Me.Button228 = New System.Windows.Forms.Button()
        Me.Button229 = New System.Windows.Forms.Button()
        Me.Button230 = New System.Windows.Forms.Button()
        Me.Button231 = New System.Windows.Forms.Button()
        Me.Button232 = New System.Windows.Forms.Button()
        Me.Button233 = New System.Windows.Forms.Button()
        Me.Button234 = New System.Windows.Forms.Button()
        Me.Button235 = New System.Windows.Forms.Button()
        Me.Button236 = New System.Windows.Forms.Button()
        Me.Button237 = New System.Windows.Forms.Button()
        Me.Button238 = New System.Windows.Forms.Button()
        Me.Button239 = New System.Windows.Forms.Button()
        Me.Button240 = New System.Windows.Forms.Button()
        Me.Button241 = New System.Windows.Forms.Button()
        Me.Button242 = New System.Windows.Forms.Button()
        Me.Button243 = New System.Windows.Forms.Button()
        Me.Button244 = New System.Windows.Forms.Button()
        Me.Button245 = New System.Windows.Forms.Button()
        Me.Button246 = New System.Windows.Forms.Button()
        Me.Button247 = New System.Windows.Forms.Button()
        Me.Button248 = New System.Windows.Forms.Button()
        Me.Button249 = New System.Windows.Forms.Button()
        Me.Button250 = New System.Windows.Forms.Button()
        Me.Button251 = New System.Windows.Forms.Button()
        Me.Button252 = New System.Windows.Forms.Button()
        Me.Button253 = New System.Windows.Forms.Button()
        Me.Button254 = New System.Windows.Forms.Button()
        Me.Button255 = New System.Windows.Forms.Button()
        Me.Button256 = New System.Windows.Forms.Button()
        Me.Button257 = New System.Windows.Forms.Button()
        Me.Button258 = New System.Windows.Forms.Button()
        Me.Button259 = New System.Windows.Forms.Button()
        Me.Button260 = New System.Windows.Forms.Button()
        Me.Button261 = New System.Windows.Forms.Button()
        Me.Button262 = New System.Windows.Forms.Button()
        Me.Button263 = New System.Windows.Forms.Button()
        Me.Button264 = New System.Windows.Forms.Button()
        Me.Button265 = New System.Windows.Forms.Button()
        Me.Button266 = New System.Windows.Forms.Button()
        Me.Button267 = New System.Windows.Forms.Button()
        Me.Button268 = New System.Windows.Forms.Button()
        Me.Button269 = New System.Windows.Forms.Button()
        Me.Button270 = New System.Windows.Forms.Button()
        Me.Button271 = New System.Windows.Forms.Button()
        Me.Button272 = New System.Windows.Forms.Button()
        Me.Button273 = New System.Windows.Forms.Button()
        Me.Button274 = New System.Windows.Forms.Button()
        Me.Button275 = New System.Windows.Forms.Button()
        Me.Button276 = New System.Windows.Forms.Button()
        Me.Button277 = New System.Windows.Forms.Button()
        Me.Button278 = New System.Windows.Forms.Button()
        Me.Button279 = New System.Windows.Forms.Button()
        Me.Button280 = New System.Windows.Forms.Button()
        Me.Button281 = New System.Windows.Forms.Button()
        Me.Button282 = New System.Windows.Forms.Button()
        Me.Button283 = New System.Windows.Forms.Button()
        Me.Button284 = New System.Windows.Forms.Button()
        Me.Button285 = New System.Windows.Forms.Button()
        Me.Button286 = New System.Windows.Forms.Button()
        Me.Button287 = New System.Windows.Forms.Button()
        Me.Button288 = New System.Windows.Forms.Button()
        Me.Button289 = New System.Windows.Forms.Button()
        Me.Button290 = New System.Windows.Forms.Button()
        Me.Button291 = New System.Windows.Forms.Button()
        Me.Button292 = New System.Windows.Forms.Button()
        Me.Button293 = New System.Windows.Forms.Button()
        Me.Button294 = New System.Windows.Forms.Button()
        Me.Button295 = New System.Windows.Forms.Button()
        Me.Button296 = New System.Windows.Forms.Button()
        Me.Button297 = New System.Windows.Forms.Button()
        Me.Button298 = New System.Windows.Forms.Button()
        Me.Button299 = New System.Windows.Forms.Button()
        Me.Button300 = New System.Windows.Forms.Button()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(137, 6)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(31, 32)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "D"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button2.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(163, 6)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(31, 32)
        Me.Button2.TabIndex = 2
        Me.Button2.Text = "A"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button3.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(219, 6)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(31, 32)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "D"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button4.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(191, 6)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(31, 32)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "S"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button5.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(330, 6)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(31, 32)
        Me.Button5.TabIndex = 8
        Me.Button5.Text = "Y"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button6.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(302, 6)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(31, 32)
        Me.Button6.TabIndex = 7
        Me.Button6.Text = "H"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button7.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.Color.White
        Me.Button7.Location = New System.Drawing.Point(274, 6)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(31, 32)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "G"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button8.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Location = New System.Drawing.Point(248, 6)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(31, 32)
        Me.Button8.TabIndex = 5
        Me.Button8.Text = "F"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button9.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.Color.White
        Me.Button9.Location = New System.Drawing.Point(441, 6)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(31, 32)
        Me.Button9.TabIndex = 12
        Me.Button9.Text = "L"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button10.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.Color.White
        Me.Button10.Location = New System.Drawing.Point(413, 6)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(31, 32)
        Me.Button10.TabIndex = 11
        Me.Button10.Text = "R"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button11.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button11.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.Color.White
        Me.Button11.Location = New System.Drawing.Point(385, 6)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(31, 32)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "J"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button12.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button12.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.ForeColor = System.Drawing.Color.White
        Me.Button12.Location = New System.Drawing.Point(359, 6)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(31, 32)
        Me.Button12.TabIndex = 9
        Me.Button12.Text = "A"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button13.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = System.Drawing.Color.White
        Me.Button13.Location = New System.Drawing.Point(660, 6)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(31, 32)
        Me.Button13.TabIndex = 20
        Me.Button13.Text = "A"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button14.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.ForeColor = System.Drawing.Color.White
        Me.Button14.Location = New System.Drawing.Point(632, 6)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(31, 32)
        Me.Button14.TabIndex = 19
        Me.Button14.Text = "M"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button15.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.ForeColor = System.Drawing.Color.White
        Me.Button15.Location = New System.Drawing.Point(604, 6)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(31, 32)
        Me.Button15.TabIndex = 18
        Me.Button15.Text = "T"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button16.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.ForeColor = System.Drawing.Color.White
        Me.Button16.Location = New System.Drawing.Point(578, 6)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(31, 32)
        Me.Button16.TabIndex = 17
        Me.Button16.Text = "A"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button17.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button17.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.ForeColor = System.Drawing.Color.White
        Me.Button17.Location = New System.Drawing.Point(549, 6)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(31, 32)
        Me.Button17.TabIndex = 16
        Me.Button17.Text = "T"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button18.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button18.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.ForeColor = System.Drawing.Color.White
        Me.Button18.Location = New System.Drawing.Point(521, 6)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(31, 32)
        Me.Button18.TabIndex = 15
        Me.Button18.Text = "L"
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button19.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button19.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.ForeColor = System.Drawing.Color.White
        Me.Button19.Location = New System.Drawing.Point(493, 6)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(31, 32)
        Me.Button19.TabIndex = 14
        Me.Button19.Text = "H"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button20.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button20.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.ForeColor = System.Drawing.Color.White
        Me.Button20.Location = New System.Drawing.Point(467, 6)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(31, 32)
        Me.Button20.TabIndex = 13
        Me.Button20.Text = "P"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button21.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button21.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.ForeColor = System.Drawing.Color.White
        Me.Button21.Location = New System.Drawing.Point(660, 35)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(31, 32)
        Me.Button21.TabIndex = 40
        Me.Button21.Text = "M"
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button22.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button22.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.ForeColor = System.Drawing.Color.White
        Me.Button22.Location = New System.Drawing.Point(632, 35)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(31, 32)
        Me.Button22.TabIndex = 39
        Me.Button22.Text = "A"
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button23
        '
        Me.Button23.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button23.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button23.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.ForeColor = System.Drawing.Color.White
        Me.Button23.Location = New System.Drawing.Point(604, 35)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(31, 32)
        Me.Button23.TabIndex = 38
        Me.Button23.Text = "L"
        Me.Button23.UseVisualStyleBackColor = False
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button24.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button24.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.ForeColor = System.Drawing.Color.White
        Me.Button24.Location = New System.Drawing.Point(578, 35)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(31, 32)
        Me.Button24.TabIndex = 37
        Me.Button24.Text = "A"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button25.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button25.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.ForeColor = System.Drawing.Color.White
        Me.Button25.Location = New System.Drawing.Point(549, 35)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(31, 32)
        Me.Button25.TabIndex = 36
        Me.Button25.Text = "H"
        Me.Button25.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button26.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button26.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.ForeColor = System.Drawing.Color.White
        Me.Button26.Location = New System.Drawing.Point(521, 35)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(31, 32)
        Me.Button26.TabIndex = 35
        Me.Button26.Text = "S"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Button27
        '
        Me.Button27.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button27.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button27.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.ForeColor = System.Drawing.Color.White
        Me.Button27.Location = New System.Drawing.Point(493, 35)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(31, 32)
        Me.Button27.TabIndex = 34
        Me.Button27.Text = "A"
        Me.Button27.UseVisualStyleBackColor = False
        '
        'Button28
        '
        Me.Button28.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button28.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button28.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.ForeColor = System.Drawing.Color.White
        Me.Button28.Location = New System.Drawing.Point(467, 35)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(31, 32)
        Me.Button28.TabIndex = 33
        Me.Button28.Text = "P"
        Me.Button28.UseVisualStyleBackColor = False
        '
        'Button29
        '
        Me.Button29.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button29.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button29.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.ForeColor = System.Drawing.Color.White
        Me.Button29.Location = New System.Drawing.Point(441, 35)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(31, 32)
        Me.Button29.TabIndex = 32
        Me.Button29.Text = "N"
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button30.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button30.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.ForeColor = System.Drawing.Color.White
        Me.Button30.Location = New System.Drawing.Point(413, 35)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(31, 32)
        Me.Button30.TabIndex = 31
        Me.Button30.Text = "U"
        Me.Button30.UseVisualStyleBackColor = False
        '
        'Button31
        '
        Me.Button31.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button31.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button31.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.ForeColor = System.Drawing.Color.White
        Me.Button31.Location = New System.Drawing.Point(385, 35)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(31, 32)
        Me.Button31.TabIndex = 30
        Me.Button31.Text = "L"
        Me.Button31.UseVisualStyleBackColor = False
        '
        'Button32
        '
        Me.Button32.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button32.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button32.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button32.ForeColor = System.Drawing.Color.White
        Me.Button32.Location = New System.Drawing.Point(359, 35)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(31, 32)
        Me.Button32.TabIndex = 29
        Me.Button32.Text = "G"
        Me.Button32.UseVisualStyleBackColor = False
        '
        'Button33
        '
        Me.Button33.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button33.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button33.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button33.ForeColor = System.Drawing.Color.White
        Me.Button33.Location = New System.Drawing.Point(330, 35)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(31, 32)
        Me.Button33.TabIndex = 28
        Me.Button33.Text = "M"
        Me.Button33.UseVisualStyleBackColor = False
        '
        'Button34
        '
        Me.Button34.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button34.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button34.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button34.ForeColor = System.Drawing.Color.White
        Me.Button34.Location = New System.Drawing.Point(302, 35)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(31, 32)
        Me.Button34.TabIndex = 27
        Me.Button34.Text = "B"
        Me.Button34.UseVisualStyleBackColor = False
        '
        'Button35
        '
        Me.Button35.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button35.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button35.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button35.ForeColor = System.Drawing.Color.White
        Me.Button35.Location = New System.Drawing.Point(274, 35)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(31, 32)
        Me.Button35.TabIndex = 26
        Me.Button35.Text = "A"
        Me.Button35.UseVisualStyleBackColor = False
        '
        'Button36
        '
        Me.Button36.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button36.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button36.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button36.ForeColor = System.Drawing.Color.White
        Me.Button36.Location = New System.Drawing.Point(248, 35)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(31, 32)
        Me.Button36.TabIndex = 25
        Me.Button36.Text = "Z"
        Me.Button36.UseVisualStyleBackColor = False
        '
        'Button37
        '
        Me.Button37.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button37.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button37.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button37.ForeColor = System.Drawing.Color.White
        Me.Button37.Location = New System.Drawing.Point(219, 35)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(31, 32)
        Me.Button37.TabIndex = 24
        Me.Button37.Text = "B"
        Me.Button37.UseVisualStyleBackColor = False
        '
        'Button38
        '
        Me.Button38.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button38.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button38.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button38.ForeColor = System.Drawing.Color.White
        Me.Button38.Location = New System.Drawing.Point(191, 35)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(31, 32)
        Me.Button38.TabIndex = 23
        Me.Button38.Text = "D"
        Me.Button38.UseVisualStyleBackColor = False
        '
        'Button39
        '
        Me.Button39.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button39.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button39.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button39.ForeColor = System.Drawing.Color.White
        Me.Button39.Location = New System.Drawing.Point(163, 35)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(31, 32)
        Me.Button39.TabIndex = 22
        Me.Button39.Text = "J"
        Me.Button39.UseVisualStyleBackColor = False
        '
        'Button40
        '
        Me.Button40.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button40.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button40.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button40.ForeColor = System.Drawing.Color.White
        Me.Button40.Location = New System.Drawing.Point(137, 35)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(31, 32)
        Me.Button40.TabIndex = 21
        Me.Button40.Text = "I"
        Me.Button40.UseVisualStyleBackColor = False
        '
        'Button41
        '
        Me.Button41.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button41.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button41.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button41.ForeColor = System.Drawing.Color.White
        Me.Button41.Location = New System.Drawing.Point(660, 62)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(31, 32)
        Me.Button41.TabIndex = 60
        Me.Button41.Text = "W"
        Me.Button41.UseVisualStyleBackColor = False
        '
        'Button42
        '
        Me.Button42.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button42.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button42.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button42.ForeColor = System.Drawing.Color.White
        Me.Button42.Location = New System.Drawing.Point(632, 62)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(31, 32)
        Me.Button42.TabIndex = 59
        Me.Button42.Text = "X"
        Me.Button42.UseVisualStyleBackColor = False
        '
        'Button43
        '
        Me.Button43.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button43.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button43.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button43.ForeColor = System.Drawing.Color.White
        Me.Button43.Location = New System.Drawing.Point(604, 62)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(31, 32)
        Me.Button43.TabIndex = 58
        Me.Button43.Text = "M"
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button44.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button44.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button44.ForeColor = System.Drawing.Color.White
        Me.Button44.Location = New System.Drawing.Point(578, 62)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(31, 32)
        Me.Button44.TabIndex = 57
        Me.Button44.Text = "B"
        Me.Button44.UseVisualStyleBackColor = False
        '
        'Button45
        '
        Me.Button45.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button45.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button45.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button45.ForeColor = System.Drawing.Color.White
        Me.Button45.Location = New System.Drawing.Point(549, 62)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(31, 32)
        Me.Button45.TabIndex = 56
        Me.Button45.Text = "K"
        Me.Button45.UseVisualStyleBackColor = False
        '
        'Button46
        '
        Me.Button46.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button46.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button46.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button46.ForeColor = System.Drawing.Color.White
        Me.Button46.Location = New System.Drawing.Point(521, 62)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(31, 32)
        Me.Button46.TabIndex = 55
        Me.Button46.Text = "L"
        Me.Button46.UseVisualStyleBackColor = False
        '
        'Button47
        '
        Me.Button47.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button47.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button47.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button47.ForeColor = System.Drawing.Color.White
        Me.Button47.Location = New System.Drawing.Point(493, 62)
        Me.Button47.Name = "Button47"
        Me.Button47.Size = New System.Drawing.Size(31, 32)
        Me.Button47.TabIndex = 54
        Me.Button47.Text = "U"
        Me.Button47.UseVisualStyleBackColor = False
        '
        'Button48
        '
        Me.Button48.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button48.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button48.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button48.ForeColor = System.Drawing.Color.White
        Me.Button48.Location = New System.Drawing.Point(467, 62)
        Me.Button48.Name = "Button48"
        Me.Button48.Size = New System.Drawing.Size(31, 32)
        Me.Button48.TabIndex = 53
        Me.Button48.Text = "A"
        Me.Button48.UseVisualStyleBackColor = False
        '
        'Button49
        '
        Me.Button49.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button49.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button49.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button49.ForeColor = System.Drawing.Color.White
        Me.Button49.Location = New System.Drawing.Point(441, 62)
        Me.Button49.Name = "Button49"
        Me.Button49.Size = New System.Drawing.Size(31, 32)
        Me.Button49.TabIndex = 52
        Me.Button49.Text = "H"
        Me.Button49.UseVisualStyleBackColor = False
        '
        'Button50
        '
        Me.Button50.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button50.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button50.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button50.ForeColor = System.Drawing.Color.White
        Me.Button50.Location = New System.Drawing.Point(413, 62)
        Me.Button50.Name = "Button50"
        Me.Button50.Size = New System.Drawing.Size(31, 32)
        Me.Button50.TabIndex = 51
        Me.Button50.Text = "I"
        Me.Button50.UseVisualStyleBackColor = False
        '
        'Button51
        '
        Me.Button51.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button51.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button51.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button51.ForeColor = System.Drawing.Color.White
        Me.Button51.Location = New System.Drawing.Point(385, 62)
        Me.Button51.Name = "Button51"
        Me.Button51.Size = New System.Drawing.Size(31, 32)
        Me.Button51.TabIndex = 50
        Me.Button51.Text = "B"
        Me.Button51.UseVisualStyleBackColor = False
        '
        'Button52
        '
        Me.Button52.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button52.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button52.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button52.ForeColor = System.Drawing.Color.White
        Me.Button52.Location = New System.Drawing.Point(359, 62)
        Me.Button52.Name = "Button52"
        Me.Button52.Size = New System.Drawing.Size(31, 32)
        Me.Button52.TabIndex = 49
        Me.Button52.Text = "M"
        Me.Button52.UseVisualStyleBackColor = False
        '
        'Button53
        '
        Me.Button53.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button53.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button53.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button53.ForeColor = System.Drawing.Color.White
        Me.Button53.Location = New System.Drawing.Point(330, 62)
        Me.Button53.Name = "Button53"
        Me.Button53.Size = New System.Drawing.Size(31, 32)
        Me.Button53.TabIndex = 48
        Me.Button53.Text = "A"
        Me.Button53.UseVisualStyleBackColor = False
        '
        'Button54
        '
        Me.Button54.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button54.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button54.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button54.ForeColor = System.Drawing.Color.White
        Me.Button54.Location = New System.Drawing.Point(302, 62)
        Me.Button54.Name = "Button54"
        Me.Button54.Size = New System.Drawing.Size(31, 32)
        Me.Button54.TabIndex = 47
        Me.Button54.Text = "I"
        Me.Button54.UseVisualStyleBackColor = False
        '
        'Button55
        '
        Me.Button55.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button55.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button55.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button55.ForeColor = System.Drawing.Color.White
        Me.Button55.Location = New System.Drawing.Point(274, 62)
        Me.Button55.Name = "Button55"
        Me.Button55.Size = New System.Drawing.Size(31, 32)
        Me.Button55.TabIndex = 46
        Me.Button55.Text = "S"
        Me.Button55.UseVisualStyleBackColor = False
        '
        'Button56
        '
        Me.Button56.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button56.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button56.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button56.ForeColor = System.Drawing.Color.White
        Me.Button56.Location = New System.Drawing.Point(248, 62)
        Me.Button56.Name = "Button56"
        Me.Button56.Size = New System.Drawing.Size(31, 32)
        Me.Button56.TabIndex = 45
        Me.Button56.Text = "U"
        Me.Button56.UseVisualStyleBackColor = False
        '
        'Button57
        '
        Me.Button57.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button57.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button57.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button57.ForeColor = System.Drawing.Color.White
        Me.Button57.Location = New System.Drawing.Point(219, 62)
        Me.Button57.Name = "Button57"
        Me.Button57.Size = New System.Drawing.Size(31, 32)
        Me.Button57.TabIndex = 44
        Me.Button57.Text = "M"
        Me.Button57.UseVisualStyleBackColor = False
        '
        'Button58
        '
        Me.Button58.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button58.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button58.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button58.ForeColor = System.Drawing.Color.White
        Me.Button58.Location = New System.Drawing.Point(191, 62)
        Me.Button58.Name = "Button58"
        Me.Button58.Size = New System.Drawing.Size(31, 32)
        Me.Button58.TabIndex = 43
        Me.Button58.Text = "A"
        Me.Button58.UseVisualStyleBackColor = False
        '
        'Button59
        '
        Me.Button59.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button59.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button59.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button59.ForeColor = System.Drawing.Color.White
        Me.Button59.Location = New System.Drawing.Point(163, 62)
        Me.Button59.Name = "Button59"
        Me.Button59.Size = New System.Drawing.Size(31, 32)
        Me.Button59.TabIndex = 42
        Me.Button59.Text = "W"
        Me.Button59.UseVisualStyleBackColor = False
        '
        'Button60
        '
        Me.Button60.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button60.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button60.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button60.ForeColor = System.Drawing.Color.White
        Me.Button60.Location = New System.Drawing.Point(137, 62)
        Me.Button60.Name = "Button60"
        Me.Button60.Size = New System.Drawing.Size(31, 32)
        Me.Button60.TabIndex = 41
        Me.Button60.Text = "W"
        Me.Button60.UseVisualStyleBackColor = False
        '
        'Button61
        '
        Me.Button61.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button61.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button61.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button61.ForeColor = System.Drawing.Color.White
        Me.Button61.Location = New System.Drawing.Point(660, 90)
        Me.Button61.Name = "Button61"
        Me.Button61.Size = New System.Drawing.Size(31, 32)
        Me.Button61.TabIndex = 80
        Me.Button61.Text = "C"
        Me.Button61.UseVisualStyleBackColor = False
        '
        'Button62
        '
        Me.Button62.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button62.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button62.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button62.ForeColor = System.Drawing.Color.White
        Me.Button62.Location = New System.Drawing.Point(632, 90)
        Me.Button62.Name = "Button62"
        Me.Button62.Size = New System.Drawing.Size(31, 32)
        Me.Button62.TabIndex = 79
        Me.Button62.Text = "M"
        Me.Button62.UseVisualStyleBackColor = False
        '
        'Button63
        '
        Me.Button63.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button63.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button63.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button63.ForeColor = System.Drawing.Color.White
        Me.Button63.Location = New System.Drawing.Point(604, 90)
        Me.Button63.Name = "Button63"
        Me.Button63.Size = New System.Drawing.Size(31, 32)
        Me.Button63.TabIndex = 78
        Me.Button63.Text = "A"
        Me.Button63.UseVisualStyleBackColor = False
        '
        'Button64
        '
        Me.Button64.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button64.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button64.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button64.ForeColor = System.Drawing.Color.White
        Me.Button64.Location = New System.Drawing.Point(578, 90)
        Me.Button64.Name = "Button64"
        Me.Button64.Size = New System.Drawing.Size(31, 32)
        Me.Button64.TabIndex = 77
        Me.Button64.Text = "I"
        Me.Button64.UseVisualStyleBackColor = False
        '
        'Button65
        '
        Me.Button65.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button65.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button65.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button65.ForeColor = System.Drawing.Color.White
        Me.Button65.Location = New System.Drawing.Point(549, 90)
        Me.Button65.Name = "Button65"
        Me.Button65.Size = New System.Drawing.Size(31, 32)
        Me.Button65.TabIndex = 76
        Me.Button65.Text = "F"
        Me.Button65.UseVisualStyleBackColor = False
        '
        'Button66
        '
        Me.Button66.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button66.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button66.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button66.ForeColor = System.Drawing.Color.White
        Me.Button66.Location = New System.Drawing.Point(521, 90)
        Me.Button66.Name = "Button66"
        Me.Button66.Size = New System.Drawing.Size(31, 32)
        Me.Button66.TabIndex = 75
        Me.Button66.Text = "A"
        Me.Button66.UseVisualStyleBackColor = False
        '
        'Button67
        '
        Me.Button67.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button67.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button67.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button67.ForeColor = System.Drawing.Color.White
        Me.Button67.Location = New System.Drawing.Point(493, 90)
        Me.Button67.Name = "Button67"
        Me.Button67.Size = New System.Drawing.Size(31, 32)
        Me.Button67.TabIndex = 74
        Me.Button67.Text = "W"
        Me.Button67.UseVisualStyleBackColor = False
        '
        'Button68
        '
        Me.Button68.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button68.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button68.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button68.ForeColor = System.Drawing.Color.White
        Me.Button68.Location = New System.Drawing.Point(467, 90)
        Me.Button68.Name = "Button68"
        Me.Button68.Size = New System.Drawing.Size(31, 32)
        Me.Button68.TabIndex = 73
        Me.Button68.Text = "T"
        Me.Button68.UseVisualStyleBackColor = False
        '
        'Button69
        '
        Me.Button69.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button69.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button69.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button69.ForeColor = System.Drawing.Color.White
        Me.Button69.Location = New System.Drawing.Point(441, 90)
        Me.Button69.Name = "Button69"
        Me.Button69.Size = New System.Drawing.Size(31, 32)
        Me.Button69.TabIndex = 72
        Me.Button69.Text = "B"
        Me.Button69.UseVisualStyleBackColor = False
        '
        'Button70
        '
        Me.Button70.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button70.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button70.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button70.ForeColor = System.Drawing.Color.White
        Me.Button70.Location = New System.Drawing.Point(413, 90)
        Me.Button70.Name = "Button70"
        Me.Button70.Size = New System.Drawing.Size(31, 32)
        Me.Button70.TabIndex = 71
        Me.Button70.Text = "H"
        Me.Button70.UseVisualStyleBackColor = False
        '
        'Button71
        '
        Me.Button71.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button71.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button71.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button71.ForeColor = System.Drawing.Color.White
        Me.Button71.Location = New System.Drawing.Point(385, 90)
        Me.Button71.Name = "Button71"
        Me.Button71.Size = New System.Drawing.Size(31, 32)
        Me.Button71.TabIndex = 70
        Me.Button71.Text = "A"
        Me.Button71.UseVisualStyleBackColor = False
        '
        'Button72
        '
        Me.Button72.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button72.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button72.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button72.ForeColor = System.Drawing.Color.White
        Me.Button72.Location = New System.Drawing.Point(359, 90)
        Me.Button72.Name = "Button72"
        Me.Button72.Size = New System.Drawing.Size(31, 32)
        Me.Button72.TabIndex = 69
        Me.Button72.Text = "A"
        Me.Button72.UseVisualStyleBackColor = False
        '
        'Button73
        '
        Me.Button73.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button73.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button73.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button73.ForeColor = System.Drawing.Color.White
        Me.Button73.Location = New System.Drawing.Point(330, 90)
        Me.Button73.Name = "Button73"
        Me.Button73.Size = New System.Drawing.Size(31, 32)
        Me.Button73.TabIndex = 68
        Me.Button73.Text = "T"
        Me.Button73.UseVisualStyleBackColor = False
        '
        'Button74
        '
        Me.Button74.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button74.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button74.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button74.ForeColor = System.Drawing.Color.White
        Me.Button74.Location = New System.Drawing.Point(302, 90)
        Me.Button74.Name = "Button74"
        Me.Button74.Size = New System.Drawing.Size(31, 32)
        Me.Button74.TabIndex = 67
        Me.Button74.Text = "Q"
        Me.Button74.UseVisualStyleBackColor = False
        '
        'Button75
        '
        Me.Button75.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button75.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button75.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button75.ForeColor = System.Drawing.Color.White
        Me.Button75.Location = New System.Drawing.Point(274, 90)
        Me.Button75.Name = "Button75"
        Me.Button75.Size = New System.Drawing.Size(31, 32)
        Me.Button75.TabIndex = 66
        Me.Button75.Text = "H"
        Me.Button75.UseVisualStyleBackColor = False
        '
        'Button76
        '
        Me.Button76.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button76.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button76.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button76.ForeColor = System.Drawing.Color.White
        Me.Button76.Location = New System.Drawing.Point(248, 90)
        Me.Button76.Name = "Button76"
        Me.Button76.Size = New System.Drawing.Size(31, 32)
        Me.Button76.TabIndex = 65
        Me.Button76.Text = "Y"
        Me.Button76.UseVisualStyleBackColor = False
        '
        'Button77
        '
        Me.Button77.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button77.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button77.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button77.ForeColor = System.Drawing.Color.White
        Me.Button77.Location = New System.Drawing.Point(219, 90)
        Me.Button77.Name = "Button77"
        Me.Button77.Size = New System.Drawing.Size(31, 32)
        Me.Button77.TabIndex = 64
        Me.Button77.Text = "V"
        Me.Button77.UseVisualStyleBackColor = False
        '
        'Button78
        '
        Me.Button78.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button78.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button78.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button78.ForeColor = System.Drawing.Color.White
        Me.Button78.Location = New System.Drawing.Point(191, 90)
        Me.Button78.Name = "Button78"
        Me.Button78.Size = New System.Drawing.Size(31, 32)
        Me.Button78.TabIndex = 63
        Me.Button78.Text = "K"
        Me.Button78.UseVisualStyleBackColor = False
        '
        'Button79
        '
        Me.Button79.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button79.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button79.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button79.ForeColor = System.Drawing.Color.White
        Me.Button79.Location = New System.Drawing.Point(163, 90)
        Me.Button79.Name = "Button79"
        Me.Button79.Size = New System.Drawing.Size(31, 32)
        Me.Button79.TabIndex = 62
        Me.Button79.Text = "H"
        Me.Button79.UseVisualStyleBackColor = False
        '
        'Button80
        '
        Me.Button80.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button80.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button80.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button80.ForeColor = System.Drawing.Color.White
        Me.Button80.Location = New System.Drawing.Point(137, 90)
        Me.Button80.Name = "Button80"
        Me.Button80.Size = New System.Drawing.Size(31, 32)
        Me.Button80.TabIndex = 61
        Me.Button80.Text = "A"
        Me.Button80.UseVisualStyleBackColor = False
        '
        'Button81
        '
        Me.Button81.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button81.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button81.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button81.ForeColor = System.Drawing.Color.White
        Me.Button81.Location = New System.Drawing.Point(660, 119)
        Me.Button81.Name = "Button81"
        Me.Button81.Size = New System.Drawing.Size(31, 32)
        Me.Button81.TabIndex = 100
        Me.Button81.Text = "H"
        Me.Button81.UseVisualStyleBackColor = False
        '
        'Button82
        '
        Me.Button82.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button82.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button82.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button82.ForeColor = System.Drawing.Color.White
        Me.Button82.Location = New System.Drawing.Point(632, 119)
        Me.Button82.Name = "Button82"
        Me.Button82.Size = New System.Drawing.Size(31, 32)
        Me.Button82.TabIndex = 99
        Me.Button82.Text = "W"
        Me.Button82.UseVisualStyleBackColor = False
        '
        'Button83
        '
        Me.Button83.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button83.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button83.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button83.ForeColor = System.Drawing.Color.White
        Me.Button83.Location = New System.Drawing.Point(604, 119)
        Me.Button83.Name = "Button83"
        Me.Button83.Size = New System.Drawing.Size(31, 32)
        Me.Button83.TabIndex = 98
        Me.Button83.Text = "R"
        Me.Button83.UseVisualStyleBackColor = False
        '
        'Button84
        '
        Me.Button84.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button84.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button84.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button84.ForeColor = System.Drawing.Color.White
        Me.Button84.Location = New System.Drawing.Point(578, 119)
        Me.Button84.Name = "Button84"
        Me.Button84.Size = New System.Drawing.Size(31, 32)
        Me.Button84.TabIndex = 97
        Me.Button84.Text = "A"
        Me.Button84.UseVisualStyleBackColor = False
        '
        'Button85
        '
        Me.Button85.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button85.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button85.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button85.ForeColor = System.Drawing.Color.White
        Me.Button85.Location = New System.Drawing.Point(549, 119)
        Me.Button85.Name = "Button85"
        Me.Button85.Size = New System.Drawing.Size(31, 32)
        Me.Button85.TabIndex = 96
        Me.Button85.Text = "F"
        Me.Button85.UseVisualStyleBackColor = False
        '
        'Button86
        '
        Me.Button86.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button86.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button86.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button86.ForeColor = System.Drawing.Color.White
        Me.Button86.Location = New System.Drawing.Point(521, 119)
        Me.Button86.Name = "Button86"
        Me.Button86.Size = New System.Drawing.Size(31, 32)
        Me.Button86.TabIndex = 95
        Me.Button86.Text = "L"
        Me.Button86.UseVisualStyleBackColor = False
        '
        'Button87
        '
        Me.Button87.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button87.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button87.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button87.ForeColor = System.Drawing.Color.White
        Me.Button87.Location = New System.Drawing.Point(493, 119)
        Me.Button87.Name = "Button87"
        Me.Button87.Size = New System.Drawing.Size(31, 32)
        Me.Button87.TabIndex = 94
        Me.Button87.Text = "H"
        Me.Button87.UseVisualStyleBackColor = False
        '
        'Button88
        '
        Me.Button88.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button88.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button88.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button88.ForeColor = System.Drawing.Color.White
        Me.Button88.Location = New System.Drawing.Point(467, 119)
        Me.Button88.Name = "Button88"
        Me.Button88.Size = New System.Drawing.Size(31, 32)
        Me.Button88.TabIndex = 93
        Me.Button88.Text = "R"
        Me.Button88.UseVisualStyleBackColor = False
        '
        'Button89
        '
        Me.Button89.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button89.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button89.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button89.ForeColor = System.Drawing.Color.White
        Me.Button89.Location = New System.Drawing.Point(441, 119)
        Me.Button89.Name = "Button89"
        Me.Button89.Size = New System.Drawing.Size(31, 32)
        Me.Button89.TabIndex = 92
        Me.Button89.Text = "O"
        Me.Button89.UseVisualStyleBackColor = False
        '
        'Button90
        '
        Me.Button90.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button90.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button90.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button90.ForeColor = System.Drawing.Color.White
        Me.Button90.Location = New System.Drawing.Point(413, 119)
        Me.Button90.Name = "Button90"
        Me.Button90.Size = New System.Drawing.Size(31, 32)
        Me.Button90.TabIndex = 91
        Me.Button90.Text = "K"
        Me.Button90.UseVisualStyleBackColor = False
        '
        'Button91
        '
        Me.Button91.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button91.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button91.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button91.ForeColor = System.Drawing.Color.White
        Me.Button91.Location = New System.Drawing.Point(385, 119)
        Me.Button91.Name = "Button91"
        Me.Button91.Size = New System.Drawing.Size(31, 32)
        Me.Button91.TabIndex = 90
        Me.Button91.Text = "B"
        Me.Button91.UseVisualStyleBackColor = False
        '
        'Button92
        '
        Me.Button92.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button92.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button92.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button92.ForeColor = System.Drawing.Color.White
        Me.Button92.Location = New System.Drawing.Point(359, 119)
        Me.Button92.Name = "Button92"
        Me.Button92.Size = New System.Drawing.Size(31, 32)
        Me.Button92.TabIndex = 89
        Me.Button92.Text = "M"
        Me.Button92.UseVisualStyleBackColor = False
        '
        'Button93
        '
        Me.Button93.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button93.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button93.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button93.ForeColor = System.Drawing.Color.White
        Me.Button93.Location = New System.Drawing.Point(330, 119)
        Me.Button93.Name = "Button93"
        Me.Button93.Size = New System.Drawing.Size(31, 32)
        Me.Button93.TabIndex = 88
        Me.Button93.Text = "E"
        Me.Button93.UseVisualStyleBackColor = False
        '
        'Button94
        '
        Me.Button94.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button94.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button94.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button94.ForeColor = System.Drawing.Color.White
        Me.Button94.Location = New System.Drawing.Point(302, 119)
        Me.Button94.Name = "Button94"
        Me.Button94.Size = New System.Drawing.Size(31, 32)
        Me.Button94.TabIndex = 87
        Me.Button94.Text = "S"
        Me.Button94.UseVisualStyleBackColor = False
        '
        'Button95
        '
        Me.Button95.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button95.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button95.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button95.ForeColor = System.Drawing.Color.White
        Me.Button95.Location = New System.Drawing.Point(274, 119)
        Me.Button95.Name = "Button95"
        Me.Button95.Size = New System.Drawing.Size(31, 32)
        Me.Button95.TabIndex = 86
        Me.Button95.Text = "I"
        Me.Button95.UseVisualStyleBackColor = False
        '
        'Button96
        '
        Me.Button96.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button96.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button96.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button96.ForeColor = System.Drawing.Color.White
        Me.Button96.Location = New System.Drawing.Point(248, 119)
        Me.Button96.Name = "Button96"
        Me.Button96.Size = New System.Drawing.Size(31, 32)
        Me.Button96.TabIndex = 85
        Me.Button96.Text = "D"
        Me.Button96.UseVisualStyleBackColor = False
        '
        'Button97
        '
        Me.Button97.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button97.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button97.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button97.ForeColor = System.Drawing.Color.White
        Me.Button97.Location = New System.Drawing.Point(219, 119)
        Me.Button97.Name = "Button97"
        Me.Button97.Size = New System.Drawing.Size(31, 32)
        Me.Button97.TabIndex = 84
        Me.Button97.Text = "K"
        Me.Button97.UseVisualStyleBackColor = False
        '
        'Button98
        '
        Me.Button98.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button98.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button98.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button98.ForeColor = System.Drawing.Color.White
        Me.Button98.Location = New System.Drawing.Point(191, 119)
        Me.Button98.Name = "Button98"
        Me.Button98.Size = New System.Drawing.Size(31, 32)
        Me.Button98.TabIndex = 83
        Me.Button98.Text = "I"
        Me.Button98.UseVisualStyleBackColor = False
        '
        'Button99
        '
        Me.Button99.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button99.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button99.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button99.ForeColor = System.Drawing.Color.White
        Me.Button99.Location = New System.Drawing.Point(163, 119)
        Me.Button99.Name = "Button99"
        Me.Button99.Size = New System.Drawing.Size(31, 32)
        Me.Button99.TabIndex = 82
        Me.Button99.Text = "Q"
        Me.Button99.UseVisualStyleBackColor = False
        '
        'Button100
        '
        Me.Button100.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button100.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button100.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button100.ForeColor = System.Drawing.Color.White
        Me.Button100.Location = New System.Drawing.Point(137, 119)
        Me.Button100.Name = "Button100"
        Me.Button100.Size = New System.Drawing.Size(31, 32)
        Me.Button100.TabIndex = 81
        Me.Button100.Text = "T"
        Me.Button100.UseVisualStyleBackColor = False
        '
        'Button101
        '
        Me.Button101.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button101.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button101.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button101.ForeColor = System.Drawing.Color.White
        Me.Button101.Location = New System.Drawing.Point(660, 148)
        Me.Button101.Name = "Button101"
        Me.Button101.Size = New System.Drawing.Size(31, 32)
        Me.Button101.TabIndex = 120
        Me.Button101.Text = "A"
        Me.Button101.UseVisualStyleBackColor = False
        '
        'Button102
        '
        Me.Button102.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button102.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button102.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button102.ForeColor = System.Drawing.Color.White
        Me.Button102.Location = New System.Drawing.Point(632, 148)
        Me.Button102.Name = "Button102"
        Me.Button102.Size = New System.Drawing.Size(31, 32)
        Me.Button102.TabIndex = 119
        Me.Button102.Text = "L"
        Me.Button102.UseVisualStyleBackColor = False
        '
        'Button103
        '
        Me.Button103.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button103.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button103.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button103.ForeColor = System.Drawing.Color.White
        Me.Button103.Location = New System.Drawing.Point(604, 148)
        Me.Button103.Name = "Button103"
        Me.Button103.Size = New System.Drawing.Size(31, 32)
        Me.Button103.TabIndex = 118
        Me.Button103.Text = "I"
        Me.Button103.UseVisualStyleBackColor = False
        '
        'Button104
        '
        Me.Button104.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button104.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button104.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button104.ForeColor = System.Drawing.Color.White
        Me.Button104.Location = New System.Drawing.Point(578, 148)
        Me.Button104.Name = "Button104"
        Me.Button104.Size = New System.Drawing.Size(31, 32)
        Me.Button104.TabIndex = 117
        Me.Button104.Text = "E"
        Me.Button104.UseVisualStyleBackColor = False
        '
        'Button105
        '
        Me.Button105.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button105.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button105.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button105.ForeColor = System.Drawing.Color.White
        Me.Button105.Location = New System.Drawing.Point(549, 148)
        Me.Button105.Name = "Button105"
        Me.Button105.Size = New System.Drawing.Size(31, 32)
        Me.Button105.TabIndex = 116
        Me.Button105.Text = "Z"
        Me.Button105.UseVisualStyleBackColor = False
        '
        'Button106
        '
        Me.Button106.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button106.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button106.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button106.ForeColor = System.Drawing.Color.White
        Me.Button106.Location = New System.Drawing.Point(521, 148)
        Me.Button106.Name = "Button106"
        Me.Button106.Size = New System.Drawing.Size(31, 32)
        Me.Button106.TabIndex = 115
        Me.Button106.Text = "A"
        Me.Button106.UseVisualStyleBackColor = False
        '
        'Button107
        '
        Me.Button107.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button107.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button107.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button107.ForeColor = System.Drawing.Color.White
        Me.Button107.Location = New System.Drawing.Point(493, 148)
        Me.Button107.Name = "Button107"
        Me.Button107.Size = New System.Drawing.Size(31, 32)
        Me.Button107.TabIndex = 114
        Me.Button107.Text = "O"
        Me.Button107.UseVisualStyleBackColor = False
        '
        'Button108
        '
        Me.Button108.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button108.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button108.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button108.ForeColor = System.Drawing.Color.White
        Me.Button108.Location = New System.Drawing.Point(467, 148)
        Me.Button108.Name = "Button108"
        Me.Button108.Size = New System.Drawing.Size(31, 32)
        Me.Button108.TabIndex = 113
        Me.Button108.Text = "P"
        Me.Button108.UseVisualStyleBackColor = False
        '
        'Button109
        '
        Me.Button109.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button109.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button109.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button109.ForeColor = System.Drawing.Color.White
        Me.Button109.Location = New System.Drawing.Point(441, 148)
        Me.Button109.Name = "Button109"
        Me.Button109.Size = New System.Drawing.Size(31, 32)
        Me.Button109.TabIndex = 112
        Me.Button109.Text = "N"
        Me.Button109.UseVisualStyleBackColor = False
        '
        'Button110
        '
        Me.Button110.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button110.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button110.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button110.ForeColor = System.Drawing.Color.White
        Me.Button110.Location = New System.Drawing.Point(413, 148)
        Me.Button110.Name = "Button110"
        Me.Button110.Size = New System.Drawing.Size(31, 32)
        Me.Button110.TabIndex = 111
        Me.Button110.Text = "R"
        Me.Button110.UseVisualStyleBackColor = False
        '
        'Button111
        '
        Me.Button111.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button111.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button111.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button111.ForeColor = System.Drawing.Color.White
        Me.Button111.Location = New System.Drawing.Point(385, 148)
        Me.Button111.Name = "Button111"
        Me.Button111.Size = New System.Drawing.Size(31, 32)
        Me.Button111.TabIndex = 110
        Me.Button111.Text = "A"
        Me.Button111.UseVisualStyleBackColor = False
        '
        'Button112
        '
        Me.Button112.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button112.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button112.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button112.ForeColor = System.Drawing.Color.White
        Me.Button112.Location = New System.Drawing.Point(359, 148)
        Me.Button112.Name = "Button112"
        Me.Button112.Size = New System.Drawing.Size(31, 32)
        Me.Button112.TabIndex = 109
        Me.Button112.Text = "L"
        Me.Button112.UseVisualStyleBackColor = False
        '
        'Button113
        '
        Me.Button113.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button113.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button113.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button113.ForeColor = System.Drawing.Color.White
        Me.Button113.Location = New System.Drawing.Point(330, 148)
        Me.Button113.Name = "Button113"
        Me.Button113.Size = New System.Drawing.Size(31, 32)
        Me.Button113.TabIndex = 108
        Me.Button113.Text = "I"
        Me.Button113.UseVisualStyleBackColor = False
        '
        'Button114
        '
        Me.Button114.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button114.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button114.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button114.ForeColor = System.Drawing.Color.White
        Me.Button114.Location = New System.Drawing.Point(302, 148)
        Me.Button114.Name = "Button114"
        Me.Button114.Size = New System.Drawing.Size(31, 32)
        Me.Button114.TabIndex = 107
        Me.Button114.Text = "J"
        Me.Button114.UseVisualStyleBackColor = False
        '
        'Button115
        '
        Me.Button115.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button115.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button115.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button115.ForeColor = System.Drawing.Color.White
        Me.Button115.Location = New System.Drawing.Point(274, 148)
        Me.Button115.Name = "Button115"
        Me.Button115.Size = New System.Drawing.Size(31, 32)
        Me.Button115.TabIndex = 106
        Me.Button115.Text = "Q"
        Me.Button115.UseVisualStyleBackColor = False
        '
        'Button116
        '
        Me.Button116.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button116.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button116.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button116.ForeColor = System.Drawing.Color.White
        Me.Button116.Location = New System.Drawing.Point(248, 148)
        Me.Button116.Name = "Button116"
        Me.Button116.Size = New System.Drawing.Size(31, 32)
        Me.Button116.TabIndex = 105
        Me.Button116.Text = "H"
        Me.Button116.UseVisualStyleBackColor = False
        '
        'Button117
        '
        Me.Button117.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button117.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button117.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button117.ForeColor = System.Drawing.Color.White
        Me.Button117.Location = New System.Drawing.Point(219, 148)
        Me.Button117.Name = "Button117"
        Me.Button117.Size = New System.Drawing.Size(31, 32)
        Me.Button117.TabIndex = 104
        Me.Button117.Text = "Y"
        Me.Button117.UseVisualStyleBackColor = False
        '
        'Button118
        '
        Me.Button118.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button118.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button118.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button118.ForeColor = System.Drawing.Color.White
        Me.Button118.Location = New System.Drawing.Point(191, 148)
        Me.Button118.Name = "Button118"
        Me.Button118.Size = New System.Drawing.Size(31, 32)
        Me.Button118.TabIndex = 103
        Me.Button118.Text = "L"
        Me.Button118.UseVisualStyleBackColor = False
        '
        'Button119
        '
        Me.Button119.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button119.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button119.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button119.ForeColor = System.Drawing.Color.White
        Me.Button119.Location = New System.Drawing.Point(163, 148)
        Me.Button119.Name = "Button119"
        Me.Button119.Size = New System.Drawing.Size(31, 32)
        Me.Button119.TabIndex = 102
        Me.Button119.Text = "T"
        Me.Button119.UseVisualStyleBackColor = False
        '
        'Button120
        '
        Me.Button120.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button120.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button120.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button120.ForeColor = System.Drawing.Color.White
        Me.Button120.Location = New System.Drawing.Point(137, 148)
        Me.Button120.Name = "Button120"
        Me.Button120.Size = New System.Drawing.Size(31, 32)
        Me.Button120.TabIndex = 101
        Me.Button120.Text = "A"
        Me.Button120.UseVisualStyleBackColor = False
        '
        'Button121
        '
        Me.Button121.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button121.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button121.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button121.ForeColor = System.Drawing.Color.White
        Me.Button121.Location = New System.Drawing.Point(660, 174)
        Me.Button121.Name = "Button121"
        Me.Button121.Size = New System.Drawing.Size(31, 32)
        Me.Button121.TabIndex = 140
        Me.Button121.Text = "H"
        Me.Button121.UseVisualStyleBackColor = False
        '
        'Button122
        '
        Me.Button122.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button122.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button122.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button122.ForeColor = System.Drawing.Color.White
        Me.Button122.Location = New System.Drawing.Point(632, 174)
        Me.Button122.Name = "Button122"
        Me.Button122.Size = New System.Drawing.Size(31, 32)
        Me.Button122.TabIndex = 139
        Me.Button122.Text = "M"
        Me.Button122.UseVisualStyleBackColor = False
        '
        'Button123
        '
        Me.Button123.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button123.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button123.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button123.ForeColor = System.Drawing.Color.White
        Me.Button123.Location = New System.Drawing.Point(604, 174)
        Me.Button123.Name = "Button123"
        Me.Button123.Size = New System.Drawing.Size(31, 32)
        Me.Button123.TabIndex = 138
        Me.Button123.Text = "K"
        Me.Button123.UseVisualStyleBackColor = False
        '
        'Button124
        '
        Me.Button124.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button124.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button124.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button124.ForeColor = System.Drawing.Color.White
        Me.Button124.Location = New System.Drawing.Point(578, 174)
        Me.Button124.Name = "Button124"
        Me.Button124.Size = New System.Drawing.Size(31, 32)
        Me.Button124.TabIndex = 137
        Me.Button124.Text = "M"
        Me.Button124.UseVisualStyleBackColor = False
        '
        'Button125
        '
        Me.Button125.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button125.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button125.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button125.ForeColor = System.Drawing.Color.White
        Me.Button125.Location = New System.Drawing.Point(549, 174)
        Me.Button125.Name = "Button125"
        Me.Button125.Size = New System.Drawing.Size(31, 32)
        Me.Button125.TabIndex = 136
        Me.Button125.Text = "D"
        Me.Button125.UseVisualStyleBackColor = False
        '
        'Button126
        '
        Me.Button126.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button126.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button126.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button126.ForeColor = System.Drawing.Color.White
        Me.Button126.Location = New System.Drawing.Point(521, 174)
        Me.Button126.Name = "Button126"
        Me.Button126.Size = New System.Drawing.Size(31, 32)
        Me.Button126.TabIndex = 135
        Me.Button126.Text = "K"
        Me.Button126.UseVisualStyleBackColor = False
        '
        'Button127
        '
        Me.Button127.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button127.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button127.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button127.ForeColor = System.Drawing.Color.White
        Me.Button127.Location = New System.Drawing.Point(493, 174)
        Me.Button127.Name = "Button127"
        Me.Button127.Size = New System.Drawing.Size(31, 32)
        Me.Button127.TabIndex = 134
        Me.Button127.Text = "N"
        Me.Button127.UseVisualStyleBackColor = False
        '
        'Button128
        '
        Me.Button128.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button128.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button128.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button128.ForeColor = System.Drawing.Color.White
        Me.Button128.Location = New System.Drawing.Point(467, 174)
        Me.Button128.Name = "Button128"
        Me.Button128.Size = New System.Drawing.Size(31, 32)
        Me.Button128.TabIndex = 133
        Me.Button128.Text = "Q"
        Me.Button128.UseVisualStyleBackColor = False
        '
        'Button129
        '
        Me.Button129.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button129.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button129.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button129.ForeColor = System.Drawing.Color.White
        Me.Button129.Location = New System.Drawing.Point(441, 174)
        Me.Button129.Name = "Button129"
        Me.Button129.Size = New System.Drawing.Size(31, 32)
        Me.Button129.TabIndex = 132
        Me.Button129.Text = "M"
        Me.Button129.UseVisualStyleBackColor = False
        '
        'Button130
        '
        Me.Button130.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button130.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button130.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button130.ForeColor = System.Drawing.Color.White
        Me.Button130.Location = New System.Drawing.Point(413, 174)
        Me.Button130.Name = "Button130"
        Me.Button130.Size = New System.Drawing.Size(31, 32)
        Me.Button130.TabIndex = 131
        Me.Button130.Text = "P"
        Me.Button130.UseVisualStyleBackColor = False
        '
        'Button131
        '
        Me.Button131.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button131.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button131.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button131.ForeColor = System.Drawing.Color.White
        Me.Button131.Location = New System.Drawing.Point(385, 174)
        Me.Button131.Name = "Button131"
        Me.Button131.Size = New System.Drawing.Size(31, 32)
        Me.Button131.TabIndex = 130
        Me.Button131.Text = "E"
        Me.Button131.UseVisualStyleBackColor = False
        '
        'Button132
        '
        Me.Button132.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button132.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button132.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button132.ForeColor = System.Drawing.Color.White
        Me.Button132.Location = New System.Drawing.Point(359, 174)
        Me.Button132.Name = "Button132"
        Me.Button132.Size = New System.Drawing.Size(31, 32)
        Me.Button132.TabIndex = 129
        Me.Button132.Text = "L"
        Me.Button132.UseVisualStyleBackColor = False
        '
        'Button133
        '
        Me.Button133.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button133.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button133.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button133.ForeColor = System.Drawing.Color.White
        Me.Button133.Location = New System.Drawing.Point(330, 174)
        Me.Button133.Name = "Button133"
        Me.Button133.Size = New System.Drawing.Size(31, 32)
        Me.Button133.TabIndex = 128
        Me.Button133.Text = "A"
        Me.Button133.UseVisualStyleBackColor = False
        '
        'Button134
        '
        Me.Button134.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button134.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button134.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button134.ForeColor = System.Drawing.Color.White
        Me.Button134.Location = New System.Drawing.Point(302, 174)
        Me.Button134.Name = "Button134"
        Me.Button134.Size = New System.Drawing.Size(31, 32)
        Me.Button134.TabIndex = 127
        Me.Button134.Text = "H"
        Me.Button134.UseVisualStyleBackColor = False
        '
        'Button135
        '
        Me.Button135.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button135.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button135.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button135.ForeColor = System.Drawing.Color.White
        Me.Button135.Location = New System.Drawing.Point(274, 174)
        Me.Button135.Name = "Button135"
        Me.Button135.Size = New System.Drawing.Size(31, 32)
        Me.Button135.TabIndex = 126
        Me.Button135.Text = "A"
        Me.Button135.UseVisualStyleBackColor = False
        '
        'Button136
        '
        Me.Button136.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button136.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button136.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button136.ForeColor = System.Drawing.Color.White
        Me.Button136.Location = New System.Drawing.Point(248, 174)
        Me.Button136.Name = "Button136"
        Me.Button136.Size = New System.Drawing.Size(31, 32)
        Me.Button136.TabIndex = 125
        Me.Button136.Text = "M"
        Me.Button136.UseVisualStyleBackColor = False
        '
        'Button137
        '
        Me.Button137.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button137.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button137.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button137.ForeColor = System.Drawing.Color.White
        Me.Button137.Location = New System.Drawing.Point(219, 174)
        Me.Button137.Name = "Button137"
        Me.Button137.Size = New System.Drawing.Size(31, 32)
        Me.Button137.TabIndex = 124
        Me.Button137.Text = "J"
        Me.Button137.UseVisualStyleBackColor = False
        '
        'Button138
        '
        Me.Button138.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button138.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button138.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button138.ForeColor = System.Drawing.Color.White
        Me.Button138.Location = New System.Drawing.Point(191, 174)
        Me.Button138.Name = "Button138"
        Me.Button138.Size = New System.Drawing.Size(31, 32)
        Me.Button138.TabIndex = 123
        Me.Button138.Text = "A"
        Me.Button138.UseVisualStyleBackColor = False
        '
        'Button139
        '
        Me.Button139.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button139.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button139.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button139.ForeColor = System.Drawing.Color.White
        Me.Button139.Location = New System.Drawing.Point(163, 174)
        Me.Button139.Name = "Button139"
        Me.Button139.Size = New System.Drawing.Size(31, 32)
        Me.Button139.TabIndex = 122
        Me.Button139.Text = "L"
        Me.Button139.UseVisualStyleBackColor = False
        '
        'Button140
        '
        Me.Button140.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button140.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button140.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button140.ForeColor = System.Drawing.Color.White
        Me.Button140.Location = New System.Drawing.Point(137, 174)
        Me.Button140.Name = "Button140"
        Me.Button140.Size = New System.Drawing.Size(31, 32)
        Me.Button140.TabIndex = 121
        Me.Button140.Text = "A"
        Me.Button140.UseVisualStyleBackColor = False
        '
        'Button141
        '
        Me.Button141.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button141.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button141.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button141.ForeColor = System.Drawing.Color.White
        Me.Button141.Location = New System.Drawing.Point(660, 200)
        Me.Button141.Name = "Button141"
        Me.Button141.Size = New System.Drawing.Size(31, 32)
        Me.Button141.TabIndex = 160
        Me.Button141.Text = "B"
        Me.Button141.UseVisualStyleBackColor = False
        '
        'Button142
        '
        Me.Button142.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button142.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button142.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button142.ForeColor = System.Drawing.Color.White
        Me.Button142.Location = New System.Drawing.Point(632, 200)
        Me.Button142.Name = "Button142"
        Me.Button142.Size = New System.Drawing.Size(31, 32)
        Me.Button142.TabIndex = 159
        Me.Button142.Text = "M"
        Me.Button142.UseVisualStyleBackColor = False
        '
        'Button143
        '
        Me.Button143.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button143.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button143.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button143.ForeColor = System.Drawing.Color.White
        Me.Button143.Location = New System.Drawing.Point(604, 200)
        Me.Button143.Name = "Button143"
        Me.Button143.Size = New System.Drawing.Size(31, 32)
        Me.Button143.TabIndex = 158
        Me.Button143.Text = "I"
        Me.Button143.UseVisualStyleBackColor = False
        '
        'Button144
        '
        Me.Button144.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button144.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button144.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button144.ForeColor = System.Drawing.Color.White
        Me.Button144.Location = New System.Drawing.Point(578, 200)
        Me.Button144.Name = "Button144"
        Me.Button144.Size = New System.Drawing.Size(31, 32)
        Me.Button144.TabIndex = 157
        Me.Button144.Text = "Q"
        Me.Button144.UseVisualStyleBackColor = False
        '
        'Button145
        '
        Me.Button145.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button145.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button145.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button145.ForeColor = System.Drawing.Color.White
        Me.Button145.Location = New System.Drawing.Point(549, 200)
        Me.Button145.Name = "Button145"
        Me.Button145.Size = New System.Drawing.Size(31, 32)
        Me.Button145.TabIndex = 156
        Me.Button145.Text = "K"
        Me.Button145.UseVisualStyleBackColor = False
        '
        'Button146
        '
        Me.Button146.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button146.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button146.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button146.ForeColor = System.Drawing.Color.White
        Me.Button146.Location = New System.Drawing.Point(521, 200)
        Me.Button146.Name = "Button146"
        Me.Button146.Size = New System.Drawing.Size(31, 32)
        Me.Button146.TabIndex = 155
        Me.Button146.Text = "I"
        Me.Button146.UseVisualStyleBackColor = False
        '
        'Button147
        '
        Me.Button147.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button147.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button147.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button147.ForeColor = System.Drawing.Color.White
        Me.Button147.Location = New System.Drawing.Point(493, 200)
        Me.Button147.Name = "Button147"
        Me.Button147.Size = New System.Drawing.Size(31, 32)
        Me.Button147.TabIndex = 154
        Me.Button147.Text = "W"
        Me.Button147.UseVisualStyleBackColor = False
        '
        'Button148
        '
        Me.Button148.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button148.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button148.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button148.ForeColor = System.Drawing.Color.White
        Me.Button148.Location = New System.Drawing.Point(467, 200)
        Me.Button148.Name = "Button148"
        Me.Button148.Size = New System.Drawing.Size(31, 32)
        Me.Button148.TabIndex = 153
        Me.Button148.Text = "K"
        Me.Button148.UseVisualStyleBackColor = False
        '
        'Button149
        '
        Me.Button149.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button149.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button149.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button149.ForeColor = System.Drawing.Color.White
        Me.Button149.Location = New System.Drawing.Point(441, 200)
        Me.Button149.Name = "Button149"
        Me.Button149.Size = New System.Drawing.Size(31, 32)
        Me.Button149.TabIndex = 152
        Me.Button149.Text = "S"
        Me.Button149.UseVisualStyleBackColor = False
        '
        'Button150
        '
        Me.Button150.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button150.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button150.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button150.ForeColor = System.Drawing.Color.White
        Me.Button150.Location = New System.Drawing.Point(413, 200)
        Me.Button150.Name = "Button150"
        Me.Button150.Size = New System.Drawing.Size(31, 32)
        Me.Button150.TabIndex = 151
        Me.Button150.Text = "F"
        Me.Button150.UseVisualStyleBackColor = False
        '
        'Button151
        '
        Me.Button151.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button151.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button151.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button151.ForeColor = System.Drawing.Color.White
        Me.Button151.Location = New System.Drawing.Point(385, 200)
        Me.Button151.Name = "Button151"
        Me.Button151.Size = New System.Drawing.Size(31, 32)
        Me.Button151.TabIndex = 150
        Me.Button151.Text = "I"
        Me.Button151.UseVisualStyleBackColor = False
        '
        'Button152
        '
        Me.Button152.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button152.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button152.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button152.ForeColor = System.Drawing.Color.White
        Me.Button152.Location = New System.Drawing.Point(359, 200)
        Me.Button152.Name = "Button152"
        Me.Button152.Size = New System.Drawing.Size(31, 32)
        Me.Button152.TabIndex = 149
        Me.Button152.Text = "P"
        Me.Button152.UseVisualStyleBackColor = False
        '
        'Button153
        '
        Me.Button153.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button153.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button153.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button153.ForeColor = System.Drawing.Color.White
        Me.Button153.Location = New System.Drawing.Point(330, 200)
        Me.Button153.Name = "Button153"
        Me.Button153.Size = New System.Drawing.Size(31, 32)
        Me.Button153.TabIndex = 148
        Me.Button153.Text = "I"
        Me.Button153.UseVisualStyleBackColor = False
        '
        'Button154
        '
        Me.Button154.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button154.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button154.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button154.ForeColor = System.Drawing.Color.White
        Me.Button154.Location = New System.Drawing.Point(302, 200)
        Me.Button154.Name = "Button154"
        Me.Button154.Size = New System.Drawing.Size(31, 32)
        Me.Button154.TabIndex = 147
        Me.Button154.Text = "K"
        Me.Button154.UseVisualStyleBackColor = False
        '
        'Button155
        '
        Me.Button155.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button155.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button155.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button155.ForeColor = System.Drawing.Color.White
        Me.Button155.Location = New System.Drawing.Point(274, 200)
        Me.Button155.Name = "Button155"
        Me.Button155.Size = New System.Drawing.Size(31, 32)
        Me.Button155.TabIndex = 146
        Me.Button155.Text = "D"
        Me.Button155.UseVisualStyleBackColor = False
        '
        'Button156
        '
        Me.Button156.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button156.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button156.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button156.ForeColor = System.Drawing.Color.White
        Me.Button156.Location = New System.Drawing.Point(248, 200)
        Me.Button156.Name = "Button156"
        Me.Button156.Size = New System.Drawing.Size(31, 32)
        Me.Button156.TabIndex = 145
        Me.Button156.Text = "T"
        Me.Button156.UseVisualStyleBackColor = False
        '
        'Button157
        '
        Me.Button157.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button157.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button157.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button157.ForeColor = System.Drawing.Color.White
        Me.Button157.Location = New System.Drawing.Point(219, 200)
        Me.Button157.Name = "Button157"
        Me.Button157.Size = New System.Drawing.Size(31, 32)
        Me.Button157.TabIndex = 144
        Me.Button157.Text = "M"
        Me.Button157.UseVisualStyleBackColor = False
        '
        'Button158
        '
        Me.Button158.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button158.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button158.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button158.ForeColor = System.Drawing.Color.White
        Me.Button158.Location = New System.Drawing.Point(191, 200)
        Me.Button158.Name = "Button158"
        Me.Button158.Size = New System.Drawing.Size(31, 32)
        Me.Button158.TabIndex = 143
        Me.Button158.Text = "B"
        Me.Button158.UseVisualStyleBackColor = False
        '
        'Button159
        '
        Me.Button159.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button159.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button159.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button159.ForeColor = System.Drawing.Color.White
        Me.Button159.Location = New System.Drawing.Point(163, 200)
        Me.Button159.Name = "Button159"
        Me.Button159.Size = New System.Drawing.Size(31, 32)
        Me.Button159.TabIndex = 142
        Me.Button159.Text = "I"
        Me.Button159.UseVisualStyleBackColor = False
        '
        'Button160
        '
        Me.Button160.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button160.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button160.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button160.ForeColor = System.Drawing.Color.White
        Me.Button160.Location = New System.Drawing.Point(137, 200)
        Me.Button160.Name = "Button160"
        Me.Button160.Size = New System.Drawing.Size(31, 32)
        Me.Button160.TabIndex = 141
        Me.Button160.Text = "P"
        Me.Button160.UseVisualStyleBackColor = False
        '
        'Button161
        '
        Me.Button161.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button161.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button161.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button161.ForeColor = System.Drawing.Color.White
        Me.Button161.Location = New System.Drawing.Point(660, 227)
        Me.Button161.Name = "Button161"
        Me.Button161.Size = New System.Drawing.Size(31, 32)
        Me.Button161.TabIndex = 180
        Me.Button161.Text = "P"
        Me.Button161.UseVisualStyleBackColor = False
        '
        'Button162
        '
        Me.Button162.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button162.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button162.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button162.ForeColor = System.Drawing.Color.White
        Me.Button162.Location = New System.Drawing.Point(632, 227)
        Me.Button162.Name = "Button162"
        Me.Button162.Size = New System.Drawing.Size(31, 32)
        Me.Button162.TabIndex = 179
        Me.Button162.Text = "O"
        Me.Button162.UseVisualStyleBackColor = False
        '
        'Button163
        '
        Me.Button163.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button163.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button163.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button163.ForeColor = System.Drawing.Color.White
        Me.Button163.Location = New System.Drawing.Point(604, 227)
        Me.Button163.Name = "Button163"
        Me.Button163.Size = New System.Drawing.Size(31, 32)
        Me.Button163.TabIndex = 178
        Me.Button163.Text = "T"
        Me.Button163.UseVisualStyleBackColor = False
        '
        'Button164
        '
        Me.Button164.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button164.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button164.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button164.ForeColor = System.Drawing.Color.White
        Me.Button164.Location = New System.Drawing.Point(578, 227)
        Me.Button164.Name = "Button164"
        Me.Button164.Size = New System.Drawing.Size(31, 32)
        Me.Button164.TabIndex = 177
        Me.Button164.Text = "H"
        Me.Button164.UseVisualStyleBackColor = False
        '
        'Button165
        '
        Me.Button165.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button165.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button165.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button165.ForeColor = System.Drawing.Color.White
        Me.Button165.Location = New System.Drawing.Point(549, 227)
        Me.Button165.Name = "Button165"
        Me.Button165.Size = New System.Drawing.Size(31, 32)
        Me.Button165.TabIndex = 176
        Me.Button165.Text = "A"
        Me.Button165.UseVisualStyleBackColor = False
        '
        'Button166
        '
        Me.Button166.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button166.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button166.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button166.ForeColor = System.Drawing.Color.White
        Me.Button166.Location = New System.Drawing.Point(521, 227)
        Me.Button166.Name = "Button166"
        Me.Button166.Size = New System.Drawing.Size(31, 32)
        Me.Button166.TabIndex = 175
        Me.Button166.Text = "A"
        Me.Button166.UseVisualStyleBackColor = False
        '
        'Button167
        '
        Me.Button167.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button167.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button167.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button167.ForeColor = System.Drawing.Color.White
        Me.Button167.Location = New System.Drawing.Point(493, 227)
        Me.Button167.Name = "Button167"
        Me.Button167.Size = New System.Drawing.Size(31, 32)
        Me.Button167.TabIndex = 174
        Me.Button167.Text = "L"
        Me.Button167.UseVisualStyleBackColor = False
        '
        'Button168
        '
        Me.Button168.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button168.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button168.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button168.ForeColor = System.Drawing.Color.White
        Me.Button168.Location = New System.Drawing.Point(467, 227)
        Me.Button168.Name = "Button168"
        Me.Button168.Size = New System.Drawing.Size(31, 32)
        Me.Button168.TabIndex = 173
        Me.Button168.Text = "M"
        Me.Button168.UseVisualStyleBackColor = False
        '
        'Button169
        '
        Me.Button169.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button169.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button169.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button169.ForeColor = System.Drawing.Color.White
        Me.Button169.Location = New System.Drawing.Point(441, 227)
        Me.Button169.Name = "Button169"
        Me.Button169.Size = New System.Drawing.Size(31, 32)
        Me.Button169.TabIndex = 172
        Me.Button169.Text = "S"
        Me.Button169.UseVisualStyleBackColor = False
        '
        'Button170
        '
        Me.Button170.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button170.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button170.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button170.ForeColor = System.Drawing.Color.White
        Me.Button170.Location = New System.Drawing.Point(413, 227)
        Me.Button170.Name = "Button170"
        Me.Button170.Size = New System.Drawing.Size(31, 32)
        Me.Button170.TabIndex = 171
        Me.Button170.Text = "D"
        Me.Button170.UseVisualStyleBackColor = False
        '
        'Button171
        '
        Me.Button171.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button171.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button171.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button171.ForeColor = System.Drawing.Color.White
        Me.Button171.Location = New System.Drawing.Point(385, 227)
        Me.Button171.Name = "Button171"
        Me.Button171.Size = New System.Drawing.Size(31, 32)
        Me.Button171.TabIndex = 170
        Me.Button171.Text = "R"
        Me.Button171.UseVisualStyleBackColor = False
        '
        'Button172
        '
        Me.Button172.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button172.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button172.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button172.ForeColor = System.Drawing.Color.White
        Me.Button172.Location = New System.Drawing.Point(359, 227)
        Me.Button172.Name = "Button172"
        Me.Button172.Size = New System.Drawing.Size(31, 32)
        Me.Button172.TabIndex = 169
        Me.Button172.Text = "I"
        Me.Button172.UseVisualStyleBackColor = False
        '
        'Button173
        '
        Me.Button173.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button173.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button173.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button173.ForeColor = System.Drawing.Color.White
        Me.Button173.Location = New System.Drawing.Point(330, 227)
        Me.Button173.Name = "Button173"
        Me.Button173.Size = New System.Drawing.Size(31, 32)
        Me.Button173.TabIndex = 168
        Me.Button173.Text = "M"
        Me.Button173.UseVisualStyleBackColor = False
        '
        'Button174
        '
        Me.Button174.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button174.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button174.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button174.ForeColor = System.Drawing.Color.White
        Me.Button174.Location = New System.Drawing.Point(302, 227)
        Me.Button174.Name = "Button174"
        Me.Button174.Size = New System.Drawing.Size(31, 32)
        Me.Button174.TabIndex = 167
        Me.Button174.Text = "N"
        Me.Button174.UseVisualStyleBackColor = False
        '
        'Button175
        '
        Me.Button175.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button175.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button175.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button175.ForeColor = System.Drawing.Color.White
        Me.Button175.Location = New System.Drawing.Point(274, 227)
        Me.Button175.Name = "Button175"
        Me.Button175.Size = New System.Drawing.Size(31, 32)
        Me.Button175.TabIndex = 166
        Me.Button175.Text = "G"
        Me.Button175.UseVisualStyleBackColor = False
        '
        'Button176
        '
        Me.Button176.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button176.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button176.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button176.ForeColor = System.Drawing.Color.White
        Me.Button176.Location = New System.Drawing.Point(248, 227)
        Me.Button176.Name = "Button176"
        Me.Button176.Size = New System.Drawing.Size(31, 32)
        Me.Button176.TabIndex = 165
        Me.Button176.Text = "T"
        Me.Button176.UseVisualStyleBackColor = False
        '
        'Button177
        '
        Me.Button177.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button177.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button177.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button177.ForeColor = System.Drawing.Color.White
        Me.Button177.Location = New System.Drawing.Point(219, 227)
        Me.Button177.Name = "Button177"
        Me.Button177.Size = New System.Drawing.Size(31, 32)
        Me.Button177.TabIndex = 164
        Me.Button177.Text = "M"
        Me.Button177.UseVisualStyleBackColor = False
        '
        'Button178
        '
        Me.Button178.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button178.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button178.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button178.ForeColor = System.Drawing.Color.White
        Me.Button178.Location = New System.Drawing.Point(191, 227)
        Me.Button178.Name = "Button178"
        Me.Button178.Size = New System.Drawing.Size(31, 32)
        Me.Button178.TabIndex = 163
        Me.Button178.Text = "H"
        Me.Button178.UseVisualStyleBackColor = False
        '
        'Button179
        '
        Me.Button179.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button179.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button179.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button179.ForeColor = System.Drawing.Color.White
        Me.Button179.Location = New System.Drawing.Point(163, 227)
        Me.Button179.Name = "Button179"
        Me.Button179.Size = New System.Drawing.Size(31, 32)
        Me.Button179.TabIndex = 162
        Me.Button179.Text = "B"
        Me.Button179.UseVisualStyleBackColor = False
        '
        'Button180
        '
        Me.Button180.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button180.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button180.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button180.ForeColor = System.Drawing.Color.White
        Me.Button180.Location = New System.Drawing.Point(137, 227)
        Me.Button180.Name = "Button180"
        Me.Button180.Size = New System.Drawing.Size(31, 32)
        Me.Button180.TabIndex = 161
        Me.Button180.Text = "K"
        Me.Button180.UseVisualStyleBackColor = False
        '
        'Button181
        '
        Me.Button181.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button181.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button181.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button181.ForeColor = System.Drawing.Color.White
        Me.Button181.Location = New System.Drawing.Point(660, 255)
        Me.Button181.Name = "Button181"
        Me.Button181.Size = New System.Drawing.Size(31, 32)
        Me.Button181.TabIndex = 200
        Me.Button181.Text = "L"
        Me.Button181.UseVisualStyleBackColor = False
        '
        'Button182
        '
        Me.Button182.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button182.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button182.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button182.ForeColor = System.Drawing.Color.White
        Me.Button182.Location = New System.Drawing.Point(632, 255)
        Me.Button182.Name = "Button182"
        Me.Button182.Size = New System.Drawing.Size(31, 32)
        Me.Button182.TabIndex = 199
        Me.Button182.Text = "Y"
        Me.Button182.UseVisualStyleBackColor = False
        '
        'Button183
        '
        Me.Button183.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button183.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button183.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button183.ForeColor = System.Drawing.Color.White
        Me.Button183.Location = New System.Drawing.Point(604, 255)
        Me.Button183.Name = "Button183"
        Me.Button183.Size = New System.Drawing.Size(31, 32)
        Me.Button183.TabIndex = 198
        Me.Button183.Text = "R"
        Me.Button183.UseVisualStyleBackColor = False
        '
        'Button184
        '
        Me.Button184.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button184.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button184.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button184.ForeColor = System.Drawing.Color.White
        Me.Button184.Location = New System.Drawing.Point(578, 255)
        Me.Button184.Name = "Button184"
        Me.Button184.Size = New System.Drawing.Size(31, 32)
        Me.Button184.TabIndex = 197
        Me.Button184.Text = "A"
        Me.Button184.UseVisualStyleBackColor = False
        '
        'Button185
        '
        Me.Button185.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button185.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button185.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button185.ForeColor = System.Drawing.Color.White
        Me.Button185.Location = New System.Drawing.Point(549, 255)
        Me.Button185.Name = "Button185"
        Me.Button185.Size = New System.Drawing.Size(31, 32)
        Me.Button185.TabIndex = 196
        Me.Button185.Text = "M"
        Me.Button185.UseVisualStyleBackColor = False
        '
        'Button186
        '
        Me.Button186.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button186.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button186.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button186.ForeColor = System.Drawing.Color.White
        Me.Button186.Location = New System.Drawing.Point(521, 255)
        Me.Button186.Name = "Button186"
        Me.Button186.Size = New System.Drawing.Size(31, 32)
        Me.Button186.TabIndex = 195
        Me.Button186.Text = "M"
        Me.Button186.UseVisualStyleBackColor = False
        '
        'Button187
        '
        Me.Button187.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button187.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button187.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button187.ForeColor = System.Drawing.Color.White
        Me.Button187.Location = New System.Drawing.Point(493, 255)
        Me.Button187.Name = "Button187"
        Me.Button187.Size = New System.Drawing.Size(31, 32)
        Me.Button187.TabIndex = 194
        Me.Button187.Text = "H"
        Me.Button187.UseVisualStyleBackColor = False
        '
        'Button188
        '
        Me.Button188.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button188.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button188.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button188.ForeColor = System.Drawing.Color.White
        Me.Button188.Location = New System.Drawing.Point(467, 255)
        Me.Button188.Name = "Button188"
        Me.Button188.Size = New System.Drawing.Size(31, 32)
        Me.Button188.TabIndex = 193
        Me.Button188.Text = "A"
        Me.Button188.UseVisualStyleBackColor = False
        '
        'Button189
        '
        Me.Button189.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button189.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button189.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button189.ForeColor = System.Drawing.Color.White
        Me.Button189.Location = New System.Drawing.Point(441, 255)
        Me.Button189.Name = "Button189"
        Me.Button189.Size = New System.Drawing.Size(31, 32)
        Me.Button189.TabIndex = 192
        Me.Button189.Text = "J"
        Me.Button189.UseVisualStyleBackColor = False
        '
        'Button190
        '
        Me.Button190.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button190.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button190.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button190.ForeColor = System.Drawing.Color.White
        Me.Button190.Location = New System.Drawing.Point(413, 255)
        Me.Button190.Name = "Button190"
        Me.Button190.Size = New System.Drawing.Size(31, 32)
        Me.Button190.TabIndex = 191
        Me.Button190.Text = "A"
        Me.Button190.UseVisualStyleBackColor = False
        '
        'Button191
        '
        Me.Button191.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button191.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button191.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button191.ForeColor = System.Drawing.Color.White
        Me.Button191.Location = New System.Drawing.Point(385, 255)
        Me.Button191.Name = "Button191"
        Me.Button191.Size = New System.Drawing.Size(31, 32)
        Me.Button191.TabIndex = 190
        Me.Button191.Text = "S"
        Me.Button191.UseVisualStyleBackColor = False
        '
        'Button192
        '
        Me.Button192.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button192.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button192.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button192.ForeColor = System.Drawing.Color.White
        Me.Button192.Location = New System.Drawing.Point(359, 255)
        Me.Button192.Name = "Button192"
        Me.Button192.Size = New System.Drawing.Size(31, 32)
        Me.Button192.TabIndex = 189
        Me.Button192.Text = "I"
        Me.Button192.UseVisualStyleBackColor = False
        '
        'Button193
        '
        Me.Button193.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button193.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button193.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button193.ForeColor = System.Drawing.Color.White
        Me.Button193.Location = New System.Drawing.Point(330, 255)
        Me.Button193.Name = "Button193"
        Me.Button193.Size = New System.Drawing.Size(31, 32)
        Me.Button193.TabIndex = 188
        Me.Button193.Text = "R"
        Me.Button193.UseVisualStyleBackColor = False
        '
        'Button194
        '
        Me.Button194.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button194.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button194.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button194.ForeColor = System.Drawing.Color.White
        Me.Button194.Location = New System.Drawing.Point(302, 255)
        Me.Button194.Name = "Button194"
        Me.Button194.Size = New System.Drawing.Size(31, 32)
        Me.Button194.TabIndex = 187
        Me.Button194.Text = "A"
        Me.Button194.UseVisualStyleBackColor = False
        '
        'Button195
        '
        Me.Button195.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button195.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button195.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button195.ForeColor = System.Drawing.Color.White
        Me.Button195.Location = New System.Drawing.Point(274, 255)
        Me.Button195.Name = "Button195"
        Me.Button195.Size = New System.Drawing.Size(31, 32)
        Me.Button195.TabIndex = 186
        Me.Button195.Text = "I"
        Me.Button195.UseVisualStyleBackColor = False
        '
        'Button196
        '
        Me.Button196.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button196.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button196.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button196.ForeColor = System.Drawing.Color.White
        Me.Button196.Location = New System.Drawing.Point(248, 255)
        Me.Button196.Name = "Button196"
        Me.Button196.Size = New System.Drawing.Size(31, 32)
        Me.Button196.TabIndex = 185
        Me.Button196.Text = "A"
        Me.Button196.UseVisualStyleBackColor = False
        '
        'Button197
        '
        Me.Button197.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button197.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button197.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button197.ForeColor = System.Drawing.Color.White
        Me.Button197.Location = New System.Drawing.Point(219, 255)
        Me.Button197.Name = "Button197"
        Me.Button197.Size = New System.Drawing.Size(31, 32)
        Me.Button197.TabIndex = 184
        Me.Button197.Text = "O"
        Me.Button197.UseVisualStyleBackColor = False
        '
        'Button198
        '
        Me.Button198.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button198.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button198.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button198.ForeColor = System.Drawing.Color.White
        Me.Button198.Location = New System.Drawing.Point(191, 255)
        Me.Button198.Name = "Button198"
        Me.Button198.Size = New System.Drawing.Size(31, 32)
        Me.Button198.TabIndex = 183
        Me.Button198.Text = "K"
        Me.Button198.UseVisualStyleBackColor = False
        '
        'Button199
        '
        Me.Button199.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button199.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button199.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button199.ForeColor = System.Drawing.Color.White
        Me.Button199.Location = New System.Drawing.Point(163, 255)
        Me.Button199.Name = "Button199"
        Me.Button199.Size = New System.Drawing.Size(31, 32)
        Me.Button199.TabIndex = 182
        Me.Button199.Text = "I"
        Me.Button199.UseVisualStyleBackColor = False
        '
        'Button200
        '
        Me.Button200.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button200.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button200.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button200.ForeColor = System.Drawing.Color.White
        Me.Button200.Location = New System.Drawing.Point(137, 255)
        Me.Button200.Name = "Button200"
        Me.Button200.Size = New System.Drawing.Size(31, 32)
        Me.Button200.TabIndex = 181
        Me.Button200.Text = "K"
        Me.Button200.UseVisualStyleBackColor = False
        '
        'Button201
        '
        Me.Button201.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button201.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button201.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button201.ForeColor = System.Drawing.Color.White
        Me.Button201.Location = New System.Drawing.Point(660, 284)
        Me.Button201.Name = "Button201"
        Me.Button201.Size = New System.Drawing.Size(31, 32)
        Me.Button201.TabIndex = 220
        Me.Button201.Text = "E"
        Me.Button201.UseVisualStyleBackColor = False
        '
        'Button202
        '
        Me.Button202.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button202.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button202.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button202.ForeColor = System.Drawing.Color.White
        Me.Button202.Location = New System.Drawing.Point(632, 284)
        Me.Button202.Name = "Button202"
        Me.Button202.Size = New System.Drawing.Size(31, 32)
        Me.Button202.TabIndex = 219
        Me.Button202.Text = "I"
        Me.Button202.UseVisualStyleBackColor = False
        '
        'Button203
        '
        Me.Button203.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button203.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button203.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button203.ForeColor = System.Drawing.Color.White
        Me.Button203.Location = New System.Drawing.Point(604, 284)
        Me.Button203.Name = "Button203"
        Me.Button203.Size = New System.Drawing.Size(31, 32)
        Me.Button203.TabIndex = 218
        Me.Button203.Text = "R"
        Me.Button203.UseVisualStyleBackColor = False
        '
        'Button204
        '
        Me.Button204.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button204.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button204.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button204.ForeColor = System.Drawing.Color.White
        Me.Button204.Location = New System.Drawing.Point(578, 284)
        Me.Button204.Name = "Button204"
        Me.Button204.Size = New System.Drawing.Size(31, 32)
        Me.Button204.TabIndex = 217
        Me.Button204.Text = "Z"
        Me.Button204.UseVisualStyleBackColor = False
        '
        'Button205
        '
        Me.Button205.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button205.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button205.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button205.ForeColor = System.Drawing.Color.White
        Me.Button205.Location = New System.Drawing.Point(549, 284)
        Me.Button205.Name = "Button205"
        Me.Button205.Size = New System.Drawing.Size(31, 32)
        Me.Button205.TabIndex = 216
        Me.Button205.Text = "E"
        Me.Button205.UseVisualStyleBackColor = False
        '
        'Button206
        '
        Me.Button206.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button206.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button206.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button206.ForeColor = System.Drawing.Color.White
        Me.Button206.Location = New System.Drawing.Point(521, 284)
        Me.Button206.Name = "Button206"
        Me.Button206.Size = New System.Drawing.Size(31, 32)
        Me.Button206.TabIndex = 215
        Me.Button206.Text = "J"
        Me.Button206.UseVisualStyleBackColor = False
        '
        'Button207
        '
        Me.Button207.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button207.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button207.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button207.ForeColor = System.Drawing.Color.White
        Me.Button207.Location = New System.Drawing.Point(493, 284)
        Me.Button207.Name = "Button207"
        Me.Button207.Size = New System.Drawing.Size(31, 32)
        Me.Button207.TabIndex = 214
        Me.Button207.Text = "U"
        Me.Button207.UseVisualStyleBackColor = False
        '
        'Button208
        '
        Me.Button208.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button208.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button208.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button208.ForeColor = System.Drawing.Color.White
        Me.Button208.Location = New System.Drawing.Point(467, 284)
        Me.Button208.Name = "Button208"
        Me.Button208.Size = New System.Drawing.Size(31, 32)
        Me.Button208.TabIndex = 213
        Me.Button208.Text = "A"
        Me.Button208.UseVisualStyleBackColor = False
        '
        'Button209
        '
        Me.Button209.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button209.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button209.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button209.ForeColor = System.Drawing.Color.White
        Me.Button209.Location = New System.Drawing.Point(441, 284)
        Me.Button209.Name = "Button209"
        Me.Button209.Size = New System.Drawing.Size(31, 32)
        Me.Button209.TabIndex = 212
        Me.Button209.Text = "M"
        Me.Button209.UseVisualStyleBackColor = False
        '
        'Button210
        '
        Me.Button210.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button210.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button210.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button210.ForeColor = System.Drawing.Color.White
        Me.Button210.Location = New System.Drawing.Point(413, 284)
        Me.Button210.Name = "Button210"
        Me.Button210.Size = New System.Drawing.Size(31, 32)
        Me.Button210.TabIndex = 211
        Me.Button210.Text = "A"
        Me.Button210.UseVisualStyleBackColor = False
        '
        'Button211
        '
        Me.Button211.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button211.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button211.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button211.ForeColor = System.Drawing.Color.White
        Me.Button211.Location = New System.Drawing.Point(385, 284)
        Me.Button211.Name = "Button211"
        Me.Button211.Size = New System.Drawing.Size(31, 32)
        Me.Button211.TabIndex = 210
        Me.Button211.Text = "R"
        Me.Button211.UseVisualStyleBackColor = False
        '
        'Button212
        '
        Me.Button212.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button212.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button212.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button212.ForeColor = System.Drawing.Color.White
        Me.Button212.Location = New System.Drawing.Point(359, 284)
        Me.Button212.Name = "Button212"
        Me.Button212.Size = New System.Drawing.Size(31, 32)
        Me.Button212.TabIndex = 209
        Me.Button212.Text = "J"
        Me.Button212.UseVisualStyleBackColor = False
        '
        'Button213
        '
        Me.Button213.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button213.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button213.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button213.ForeColor = System.Drawing.Color.White
        Me.Button213.Location = New System.Drawing.Point(330, 284)
        Me.Button213.Name = "Button213"
        Me.Button213.Size = New System.Drawing.Size(31, 32)
        Me.Button213.TabIndex = 208
        Me.Button213.Text = "T"
        Me.Button213.UseVisualStyleBackColor = False
        '
        'Button214
        '
        Me.Button214.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button214.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button214.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button214.ForeColor = System.Drawing.Color.White
        Me.Button214.Location = New System.Drawing.Point(302, 284)
        Me.Button214.Name = "Button214"
        Me.Button214.Size = New System.Drawing.Size(31, 32)
        Me.Button214.TabIndex = 207
        Me.Button214.Text = "A"
        Me.Button214.UseVisualStyleBackColor = False
        '
        'Button215
        '
        Me.Button215.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button215.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button215.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button215.ForeColor = System.Drawing.Color.White
        Me.Button215.Location = New System.Drawing.Point(274, 284)
        Me.Button215.Name = "Button215"
        Me.Button215.Size = New System.Drawing.Size(31, 32)
        Me.Button215.TabIndex = 206
        Me.Button215.Text = "F"
        Me.Button215.UseVisualStyleBackColor = False
        '
        'Button216
        '
        Me.Button216.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button216.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button216.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button216.ForeColor = System.Drawing.Color.White
        Me.Button216.Location = New System.Drawing.Point(248, 284)
        Me.Button216.Name = "Button216"
        Me.Button216.Size = New System.Drawing.Size(31, 32)
        Me.Button216.TabIndex = 205
        Me.Button216.Text = "B"
        Me.Button216.UseVisualStyleBackColor = False
        '
        'Button217
        '
        Me.Button217.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button217.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button217.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button217.ForeColor = System.Drawing.Color.White
        Me.Button217.Location = New System.Drawing.Point(219, 284)
        Me.Button217.Name = "Button217"
        Me.Button217.Size = New System.Drawing.Size(31, 32)
        Me.Button217.TabIndex = 204
        Me.Button217.Text = "A"
        Me.Button217.UseVisualStyleBackColor = False
        '
        'Button218
        '
        Me.Button218.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button218.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button218.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button218.ForeColor = System.Drawing.Color.White
        Me.Button218.Location = New System.Drawing.Point(191, 284)
        Me.Button218.Name = "Button218"
        Me.Button218.Size = New System.Drawing.Size(31, 32)
        Me.Button218.TabIndex = 203
        Me.Button218.Text = "Y"
        Me.Button218.UseVisualStyleBackColor = False
        '
        'Button219
        '
        Me.Button219.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button219.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button219.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button219.ForeColor = System.Drawing.Color.White
        Me.Button219.Location = New System.Drawing.Point(163, 284)
        Me.Button219.Name = "Button219"
        Me.Button219.Size = New System.Drawing.Size(31, 32)
        Me.Button219.TabIndex = 202
        Me.Button219.Text = "H"
        Me.Button219.UseVisualStyleBackColor = False
        '
        'Button220
        '
        Me.Button220.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button220.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button220.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button220.ForeColor = System.Drawing.Color.White
        Me.Button220.Location = New System.Drawing.Point(137, 284)
        Me.Button220.Name = "Button220"
        Me.Button220.Size = New System.Drawing.Size(31, 32)
        Me.Button220.TabIndex = 201
        Me.Button220.Text = "A"
        Me.Button220.UseVisualStyleBackColor = False
        '
        'Button221
        '
        Me.Button221.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button221.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button221.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button221.ForeColor = System.Drawing.Color.White
        Me.Button221.Location = New System.Drawing.Point(660, 311)
        Me.Button221.Name = "Button221"
        Me.Button221.Size = New System.Drawing.Size(31, 32)
        Me.Button221.TabIndex = 240
        Me.Button221.Text = "N"
        Me.Button221.UseVisualStyleBackColor = False
        '
        'Button222
        '
        Me.Button222.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button222.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button222.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button222.ForeColor = System.Drawing.Color.White
        Me.Button222.Location = New System.Drawing.Point(632, 311)
        Me.Button222.Name = "Button222"
        Me.Button222.Size = New System.Drawing.Size(31, 32)
        Me.Button222.TabIndex = 239
        Me.Button222.Text = "A"
        Me.Button222.UseVisualStyleBackColor = False
        '
        'Button223
        '
        Me.Button223.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button223.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button223.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button223.ForeColor = System.Drawing.Color.White
        Me.Button223.Location = New System.Drawing.Point(604, 311)
        Me.Button223.Name = "Button223"
        Me.Button223.Size = New System.Drawing.Size(31, 32)
        Me.Button223.TabIndex = 238
        Me.Button223.Text = "K"
        Me.Button223.UseVisualStyleBackColor = False
        '
        'Button224
        '
        Me.Button224.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button224.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button224.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button224.ForeColor = System.Drawing.Color.White
        Me.Button224.Location = New System.Drawing.Point(578, 311)
        Me.Button224.Name = "Button224"
        Me.Button224.Size = New System.Drawing.Size(31, 32)
        Me.Button224.TabIndex = 237
        Me.Button224.Text = "D"
        Me.Button224.UseVisualStyleBackColor = False
        '
        'Button225
        '
        Me.Button225.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button225.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button225.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button225.ForeColor = System.Drawing.Color.White
        Me.Button225.Location = New System.Drawing.Point(549, 311)
        Me.Button225.Name = "Button225"
        Me.Button225.Size = New System.Drawing.Size(31, 32)
        Me.Button225.TabIndex = 236
        Me.Button225.Text = "M"
        Me.Button225.UseVisualStyleBackColor = False
        '
        'Button226
        '
        Me.Button226.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button226.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button226.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button226.ForeColor = System.Drawing.Color.White
        Me.Button226.Location = New System.Drawing.Point(521, 311)
        Me.Button226.Name = "Button226"
        Me.Button226.Size = New System.Drawing.Size(31, 32)
        Me.Button226.TabIndex = 235
        Me.Button226.Text = "G"
        Me.Button226.UseVisualStyleBackColor = False
        '
        'Button227
        '
        Me.Button227.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button227.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button227.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button227.ForeColor = System.Drawing.Color.White
        Me.Button227.Location = New System.Drawing.Point(493, 311)
        Me.Button227.Name = "Button227"
        Me.Button227.Size = New System.Drawing.Size(31, 32)
        Me.Button227.TabIndex = 234
        Me.Button227.Text = "K"
        Me.Button227.UseVisualStyleBackColor = False
        '
        'Button228
        '
        Me.Button228.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button228.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button228.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button228.ForeColor = System.Drawing.Color.White
        Me.Button228.Location = New System.Drawing.Point(467, 311)
        Me.Button228.Name = "Button228"
        Me.Button228.Size = New System.Drawing.Size(31, 32)
        Me.Button228.TabIndex = 233
        Me.Button228.Text = "S"
        Me.Button228.UseVisualStyleBackColor = False
        '
        'Button229
        '
        Me.Button229.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button229.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button229.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button229.ForeColor = System.Drawing.Color.White
        Me.Button229.Location = New System.Drawing.Point(441, 311)
        Me.Button229.Name = "Button229"
        Me.Button229.Size = New System.Drawing.Size(31, 32)
        Me.Button229.TabIndex = 232
        Me.Button229.Text = "A"
        Me.Button229.UseVisualStyleBackColor = False
        '
        'Button230
        '
        Me.Button230.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button230.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button230.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button230.ForeColor = System.Drawing.Color.White
        Me.Button230.Location = New System.Drawing.Point(413, 311)
        Me.Button230.Name = "Button230"
        Me.Button230.Size = New System.Drawing.Size(31, 32)
        Me.Button230.TabIndex = 231
        Me.Button230.Text = "I"
        Me.Button230.UseVisualStyleBackColor = False
        '
        'Button231
        '
        Me.Button231.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button231.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button231.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button231.ForeColor = System.Drawing.Color.White
        Me.Button231.Location = New System.Drawing.Point(385, 311)
        Me.Button231.Name = "Button231"
        Me.Button231.Size = New System.Drawing.Size(31, 32)
        Me.Button231.TabIndex = 230
        Me.Button231.Text = "A"
        Me.Button231.UseVisualStyleBackColor = False
        '
        'Button232
        '
        Me.Button232.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button232.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button232.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button232.ForeColor = System.Drawing.Color.White
        Me.Button232.Location = New System.Drawing.Point(359, 311)
        Me.Button232.Name = "Button232"
        Me.Button232.Size = New System.Drawing.Size(31, 32)
        Me.Button232.TabIndex = 229
        Me.Button232.Text = "N"
        Me.Button232.UseVisualStyleBackColor = False
        '
        'Button233
        '
        Me.Button233.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button233.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button233.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button233.ForeColor = System.Drawing.Color.White
        Me.Button233.Location = New System.Drawing.Point(330, 311)
        Me.Button233.Name = "Button233"
        Me.Button233.Size = New System.Drawing.Size(31, 32)
        Me.Button233.TabIndex = 228
        Me.Button233.Text = "Q"
        Me.Button233.UseVisualStyleBackColor = False
        '
        'Button234
        '
        Me.Button234.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button234.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button234.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button234.ForeColor = System.Drawing.Color.White
        Me.Button234.Location = New System.Drawing.Point(302, 311)
        Me.Button234.Name = "Button234"
        Me.Button234.Size = New System.Drawing.Size(31, 32)
        Me.Button234.TabIndex = 227
        Me.Button234.Text = "K"
        Me.Button234.UseVisualStyleBackColor = False
        '
        'Button235
        '
        Me.Button235.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button235.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button235.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button235.ForeColor = System.Drawing.Color.White
        Me.Button235.Location = New System.Drawing.Point(274, 311)
        Me.Button235.Name = "Button235"
        Me.Button235.Size = New System.Drawing.Size(31, 32)
        Me.Button235.TabIndex = 226
        Me.Button235.Text = "W"
        Me.Button235.UseVisualStyleBackColor = False
        '
        'Button236
        '
        Me.Button236.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button236.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button236.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button236.ForeColor = System.Drawing.Color.White
        Me.Button236.Location = New System.Drawing.Point(248, 311)
        Me.Button236.Name = "Button236"
        Me.Button236.Size = New System.Drawing.Size(31, 32)
        Me.Button236.TabIndex = 225
        Me.Button236.Text = "K"
        Me.Button236.UseVisualStyleBackColor = False
        '
        'Button237
        '
        Me.Button237.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button237.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button237.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button237.ForeColor = System.Drawing.Color.White
        Me.Button237.Location = New System.Drawing.Point(219, 311)
        Me.Button237.Name = "Button237"
        Me.Button237.Size = New System.Drawing.Size(31, 32)
        Me.Button237.TabIndex = 224
        Me.Button237.Text = "I"
        Me.Button237.UseVisualStyleBackColor = False
        '
        'Button238
        '
        Me.Button238.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button238.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button238.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button238.ForeColor = System.Drawing.Color.White
        Me.Button238.Location = New System.Drawing.Point(191, 311)
        Me.Button238.Name = "Button238"
        Me.Button238.Size = New System.Drawing.Size(31, 32)
        Me.Button238.TabIndex = 223
        Me.Button238.Text = "K"
        Me.Button238.UseVisualStyleBackColor = False
        '
        'Button239
        '
        Me.Button239.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button239.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button239.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button239.ForeColor = System.Drawing.Color.White
        Me.Button239.Location = New System.Drawing.Point(163, 311)
        Me.Button239.Name = "Button239"
        Me.Button239.Size = New System.Drawing.Size(31, 32)
        Me.Button239.TabIndex = 222
        Me.Button239.Text = "A"
        Me.Button239.UseVisualStyleBackColor = False
        '
        'Button240
        '
        Me.Button240.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button240.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button240.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button240.ForeColor = System.Drawing.Color.White
        Me.Button240.Location = New System.Drawing.Point(137, 311)
        Me.Button240.Name = "Button240"
        Me.Button240.Size = New System.Drawing.Size(31, 32)
        Me.Button240.TabIndex = 221
        Me.Button240.Text = "J"
        Me.Button240.UseVisualStyleBackColor = False
        '
        'Button241
        '
        Me.Button241.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button241.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button241.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button241.ForeColor = System.Drawing.Color.White
        Me.Button241.Location = New System.Drawing.Point(660, 338)
        Me.Button241.Name = "Button241"
        Me.Button241.Size = New System.Drawing.Size(31, 32)
        Me.Button241.TabIndex = 260
        Me.Button241.Text = "I"
        Me.Button241.UseVisualStyleBackColor = False
        '
        'Button242
        '
        Me.Button242.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button242.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button242.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button242.ForeColor = System.Drawing.Color.White
        Me.Button242.Location = New System.Drawing.Point(632, 338)
        Me.Button242.Name = "Button242"
        Me.Button242.Size = New System.Drawing.Size(31, 32)
        Me.Button242.TabIndex = 259
        Me.Button242.Text = "A"
        Me.Button242.UseVisualStyleBackColor = False
        '
        'Button243
        '
        Me.Button243.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button243.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button243.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button243.ForeColor = System.Drawing.Color.White
        Me.Button243.Location = New System.Drawing.Point(604, 338)
        Me.Button243.Name = "Button243"
        Me.Button243.Size = New System.Drawing.Size(31, 32)
        Me.Button243.TabIndex = 258
        Me.Button243.Text = "A"
        Me.Button243.UseVisualStyleBackColor = False
        '
        'Button244
        '
        Me.Button244.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button244.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button244.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button244.ForeColor = System.Drawing.Color.White
        Me.Button244.Location = New System.Drawing.Point(578, 338)
        Me.Button244.Name = "Button244"
        Me.Button244.Size = New System.Drawing.Size(31, 32)
        Me.Button244.TabIndex = 257
        Me.Button244.Text = "A"
        Me.Button244.UseVisualStyleBackColor = False
        '
        'Button245
        '
        Me.Button245.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button245.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button245.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button245.ForeColor = System.Drawing.Color.White
        Me.Button245.Location = New System.Drawing.Point(549, 338)
        Me.Button245.Name = "Button245"
        Me.Button245.Size = New System.Drawing.Size(31, 32)
        Me.Button245.TabIndex = 256
        Me.Button245.Text = "J"
        Me.Button245.UseVisualStyleBackColor = False
        '
        'Button246
        '
        Me.Button246.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button246.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button246.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button246.ForeColor = System.Drawing.Color.White
        Me.Button246.Location = New System.Drawing.Point(521, 338)
        Me.Button246.Name = "Button246"
        Me.Button246.Size = New System.Drawing.Size(31, 32)
        Me.Button246.TabIndex = 255
        Me.Button246.Text = "F"
        Me.Button246.UseVisualStyleBackColor = False
        '
        'Button247
        '
        Me.Button247.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button247.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button247.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button247.ForeColor = System.Drawing.Color.White
        Me.Button247.Location = New System.Drawing.Point(493, 338)
        Me.Button247.Name = "Button247"
        Me.Button247.Size = New System.Drawing.Size(31, 32)
        Me.Button247.TabIndex = 254
        Me.Button247.Text = "A"
        Me.Button247.UseVisualStyleBackColor = False
        '
        'Button248
        '
        Me.Button248.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button248.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button248.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button248.ForeColor = System.Drawing.Color.White
        Me.Button248.Location = New System.Drawing.Point(467, 338)
        Me.Button248.Name = "Button248"
        Me.Button248.Size = New System.Drawing.Size(31, 32)
        Me.Button248.TabIndex = 253
        Me.Button248.Text = "O"
        Me.Button248.UseVisualStyleBackColor = False
        '
        'Button249
        '
        Me.Button249.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button249.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button249.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button249.ForeColor = System.Drawing.Color.White
        Me.Button249.Location = New System.Drawing.Point(441, 338)
        Me.Button249.Name = "Button249"
        Me.Button249.Size = New System.Drawing.Size(31, 32)
        Me.Button249.TabIndex = 252
        Me.Button249.Text = "I"
        Me.Button249.UseVisualStyleBackColor = False
        '
        'Button250
        '
        Me.Button250.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button250.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button250.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button250.ForeColor = System.Drawing.Color.White
        Me.Button250.Location = New System.Drawing.Point(413, 338)
        Me.Button250.Name = "Button250"
        Me.Button250.Size = New System.Drawing.Size(31, 32)
        Me.Button250.TabIndex = 251
        Me.Button250.Text = "O"
        Me.Button250.UseVisualStyleBackColor = False
        '
        'Button251
        '
        Me.Button251.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button251.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button251.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button251.ForeColor = System.Drawing.Color.White
        Me.Button251.Location = New System.Drawing.Point(385, 338)
        Me.Button251.Name = "Button251"
        Me.Button251.Size = New System.Drawing.Size(31, 32)
        Me.Button251.TabIndex = 250
        Me.Button251.Text = "A"
        Me.Button251.UseVisualStyleBackColor = False
        '
        'Button252
        '
        Me.Button252.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button252.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button252.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button252.ForeColor = System.Drawing.Color.White
        Me.Button252.Location = New System.Drawing.Point(359, 338)
        Me.Button252.Name = "Button252"
        Me.Button252.Size = New System.Drawing.Size(31, 32)
        Me.Button252.TabIndex = 249
        Me.Button252.Text = "B"
        Me.Button252.UseVisualStyleBackColor = False
        '
        'Button253
        '
        Me.Button253.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button253.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button253.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button253.ForeColor = System.Drawing.Color.White
        Me.Button253.Location = New System.Drawing.Point(330, 338)
        Me.Button253.Name = "Button253"
        Me.Button253.Size = New System.Drawing.Size(31, 32)
        Me.Button253.TabIndex = 248
        Me.Button253.Text = "K"
        Me.Button253.UseVisualStyleBackColor = False
        '
        'Button254
        '
        Me.Button254.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button254.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button254.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button254.ForeColor = System.Drawing.Color.White
        Me.Button254.Location = New System.Drawing.Point(302, 338)
        Me.Button254.Name = "Button254"
        Me.Button254.Size = New System.Drawing.Size(31, 32)
        Me.Button254.TabIndex = 247
        Me.Button254.Text = "A"
        Me.Button254.UseVisualStyleBackColor = False
        '
        'Button255
        '
        Me.Button255.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button255.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button255.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button255.ForeColor = System.Drawing.Color.White
        Me.Button255.Location = New System.Drawing.Point(274, 338)
        Me.Button255.Name = "Button255"
        Me.Button255.Size = New System.Drawing.Size(31, 32)
        Me.Button255.TabIndex = 246
        Me.Button255.Text = "M"
        Me.Button255.UseVisualStyleBackColor = False
        '
        'Button256
        '
        Me.Button256.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button256.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button256.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button256.ForeColor = System.Drawing.Color.White
        Me.Button256.Location = New System.Drawing.Point(248, 338)
        Me.Button256.Name = "Button256"
        Me.Button256.Size = New System.Drawing.Size(31, 32)
        Me.Button256.TabIndex = 245
        Me.Button256.Text = "A"
        Me.Button256.UseVisualStyleBackColor = False
        '
        'Button257
        '
        Me.Button257.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button257.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button257.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button257.ForeColor = System.Drawing.Color.White
        Me.Button257.Location = New System.Drawing.Point(219, 338)
        Me.Button257.Name = "Button257"
        Me.Button257.Size = New System.Drawing.Size(31, 32)
        Me.Button257.TabIndex = 244
        Me.Button257.Text = "M"
        Me.Button257.UseVisualStyleBackColor = False
        '
        'Button258
        '
        Me.Button258.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button258.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button258.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button258.ForeColor = System.Drawing.Color.White
        Me.Button258.Location = New System.Drawing.Point(191, 338)
        Me.Button258.Name = "Button258"
        Me.Button258.Size = New System.Drawing.Size(31, 32)
        Me.Button258.TabIndex = 243
        Me.Button258.Text = "N"
        Me.Button258.UseVisualStyleBackColor = False
        '
        'Button259
        '
        Me.Button259.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button259.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button259.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button259.ForeColor = System.Drawing.Color.White
        Me.Button259.Location = New System.Drawing.Point(163, 338)
        Me.Button259.Name = "Button259"
        Me.Button259.Size = New System.Drawing.Size(31, 32)
        Me.Button259.TabIndex = 242
        Me.Button259.Text = "A"
        Me.Button259.UseVisualStyleBackColor = False
        '
        'Button260
        '
        Me.Button260.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button260.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button260.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button260.ForeColor = System.Drawing.Color.White
        Me.Button260.Location = New System.Drawing.Point(137, 338)
        Me.Button260.Name = "Button260"
        Me.Button260.Size = New System.Drawing.Size(31, 32)
        Me.Button260.TabIndex = 241
        Me.Button260.Text = "A"
        Me.Button260.UseVisualStyleBackColor = False
        '
        'Button261
        '
        Me.Button261.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button261.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button261.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button261.ForeColor = System.Drawing.Color.White
        Me.Button261.Location = New System.Drawing.Point(660, 366)
        Me.Button261.Name = "Button261"
        Me.Button261.Size = New System.Drawing.Size(31, 32)
        Me.Button261.TabIndex = 280
        Me.Button261.Text = "M"
        Me.Button261.UseVisualStyleBackColor = False
        '
        'Button262
        '
        Me.Button262.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button262.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button262.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button262.ForeColor = System.Drawing.Color.White
        Me.Button262.Location = New System.Drawing.Point(632, 366)
        Me.Button262.Name = "Button262"
        Me.Button262.Size = New System.Drawing.Size(31, 32)
        Me.Button262.TabIndex = 279
        Me.Button262.Text = "A"
        Me.Button262.UseVisualStyleBackColor = False
        '
        'Button263
        '
        Me.Button263.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button263.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button263.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button263.ForeColor = System.Drawing.Color.White
        Me.Button263.Location = New System.Drawing.Point(604, 366)
        Me.Button263.Name = "Button263"
        Me.Button263.Size = New System.Drawing.Size(31, 32)
        Me.Button263.TabIndex = 278
        Me.Button263.Text = "L"
        Me.Button263.UseVisualStyleBackColor = False
        '
        'Button264
        '
        Me.Button264.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button264.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button264.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button264.ForeColor = System.Drawing.Color.White
        Me.Button264.Location = New System.Drawing.Point(578, 366)
        Me.Button264.Name = "Button264"
        Me.Button264.Size = New System.Drawing.Size(31, 32)
        Me.Button264.TabIndex = 277
        Me.Button264.Text = "A"
        Me.Button264.UseVisualStyleBackColor = False
        '
        'Button265
        '
        Me.Button265.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button265.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button265.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button265.ForeColor = System.Drawing.Color.White
        Me.Button265.Location = New System.Drawing.Point(549, 366)
        Me.Button265.Name = "Button265"
        Me.Button265.Size = New System.Drawing.Size(31, 32)
        Me.Button265.TabIndex = 276
        Me.Button265.Text = "A"
        Me.Button265.UseVisualStyleBackColor = False
        '
        'Button266
        '
        Me.Button266.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button266.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button266.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button266.ForeColor = System.Drawing.Color.White
        Me.Button266.Location = New System.Drawing.Point(521, 366)
        Me.Button266.Name = "Button266"
        Me.Button266.Size = New System.Drawing.Size(31, 32)
        Me.Button266.TabIndex = 275
        Me.Button266.Text = "D"
        Me.Button266.UseVisualStyleBackColor = False
        '
        'Button267
        '
        Me.Button267.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button267.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button267.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button267.ForeColor = System.Drawing.Color.White
        Me.Button267.Location = New System.Drawing.Point(493, 366)
        Me.Button267.Name = "Button267"
        Me.Button267.Size = New System.Drawing.Size(31, 32)
        Me.Button267.TabIndex = 274
        Me.Button267.Text = "N"
        Me.Button267.UseVisualStyleBackColor = False
        '
        'Button268
        '
        Me.Button268.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button268.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button268.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button268.ForeColor = System.Drawing.Color.White
        Me.Button268.Location = New System.Drawing.Point(467, 366)
        Me.Button268.Name = "Button268"
        Me.Button268.Size = New System.Drawing.Size(31, 32)
        Me.Button268.TabIndex = 273
        Me.Button268.Text = "A"
        Me.Button268.UseVisualStyleBackColor = False
        '
        'Button269
        '
        Me.Button269.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button269.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button269.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button269.ForeColor = System.Drawing.Color.White
        Me.Button269.Location = New System.Drawing.Point(441, 366)
        Me.Button269.Name = "Button269"
        Me.Button269.Size = New System.Drawing.Size(31, 32)
        Me.Button269.TabIndex = 272
        Me.Button269.Text = "M"
        Me.Button269.UseVisualStyleBackColor = False
        '
        'Button270
        '
        Me.Button270.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button270.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button270.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button270.ForeColor = System.Drawing.Color.White
        Me.Button270.Location = New System.Drawing.Point(413, 366)
        Me.Button270.Name = "Button270"
        Me.Button270.Size = New System.Drawing.Size(31, 32)
        Me.Button270.TabIndex = 271
        Me.Button270.Text = "K"
        Me.Button270.UseVisualStyleBackColor = False
        '
        'Button271
        '
        Me.Button271.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button271.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button271.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button271.ForeColor = System.Drawing.Color.White
        Me.Button271.Location = New System.Drawing.Point(385, 366)
        Me.Button271.Name = "Button271"
        Me.Button271.Size = New System.Drawing.Size(31, 32)
        Me.Button271.TabIndex = 270
        Me.Button271.Text = "A"
        Me.Button271.UseVisualStyleBackColor = False
        '
        'Button272
        '
        Me.Button272.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button272.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button272.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button272.ForeColor = System.Drawing.Color.White
        Me.Button272.Location = New System.Drawing.Point(359, 366)
        Me.Button272.Name = "Button272"
        Me.Button272.Size = New System.Drawing.Size(31, 32)
        Me.Button272.TabIndex = 269
        Me.Button272.Text = "H"
        Me.Button272.UseVisualStyleBackColor = False
        '
        'Button273
        '
        Me.Button273.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button273.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button273.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button273.ForeColor = System.Drawing.Color.White
        Me.Button273.Location = New System.Drawing.Point(330, 366)
        Me.Button273.Name = "Button273"
        Me.Button273.Size = New System.Drawing.Size(31, 32)
        Me.Button273.TabIndex = 268
        Me.Button273.Text = "I"
        Me.Button273.UseVisualStyleBackColor = False
        '
        'Button274
        '
        Me.Button274.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button274.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button274.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button274.ForeColor = System.Drawing.Color.White
        Me.Button274.Location = New System.Drawing.Point(302, 366)
        Me.Button274.Name = "Button274"
        Me.Button274.Size = New System.Drawing.Size(31, 32)
        Me.Button274.TabIndex = 267
        Me.Button274.Text = "W"
        Me.Button274.UseVisualStyleBackColor = False
        '
        'Button275
        '
        Me.Button275.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button275.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button275.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button275.ForeColor = System.Drawing.Color.White
        Me.Button275.Location = New System.Drawing.Point(274, 366)
        Me.Button275.Name = "Button275"
        Me.Button275.Size = New System.Drawing.Size(31, 32)
        Me.Button275.TabIndex = 266
        Me.Button275.Text = "G"
        Me.Button275.UseVisualStyleBackColor = False
        '
        'Button276
        '
        Me.Button276.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button276.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button276.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button276.ForeColor = System.Drawing.Color.White
        Me.Button276.Location = New System.Drawing.Point(248, 366)
        Me.Button276.Name = "Button276"
        Me.Button276.Size = New System.Drawing.Size(31, 32)
        Me.Button276.TabIndex = 265
        Me.Button276.Text = "W"
        Me.Button276.UseVisualStyleBackColor = False
        '
        'Button277
        '
        Me.Button277.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button277.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button277.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button277.ForeColor = System.Drawing.Color.White
        Me.Button277.Location = New System.Drawing.Point(219, 366)
        Me.Button277.Name = "Button277"
        Me.Button277.Size = New System.Drawing.Size(31, 32)
        Me.Button277.TabIndex = 264
        Me.Button277.Text = "G"
        Me.Button277.UseVisualStyleBackColor = False
        '
        'Button278
        '
        Me.Button278.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button278.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button278.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button278.ForeColor = System.Drawing.Color.White
        Me.Button278.Location = New System.Drawing.Point(191, 366)
        Me.Button278.Name = "Button278"
        Me.Button278.Size = New System.Drawing.Size(31, 32)
        Me.Button278.TabIndex = 263
        Me.Button278.Text = "B"
        Me.Button278.UseVisualStyleBackColor = False
        '
        'Button279
        '
        Me.Button279.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button279.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button279.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button279.ForeColor = System.Drawing.Color.White
        Me.Button279.Location = New System.Drawing.Point(163, 366)
        Me.Button279.Name = "Button279"
        Me.Button279.Size = New System.Drawing.Size(31, 32)
        Me.Button279.TabIndex = 262
        Me.Button279.Text = "I"
        Me.Button279.UseVisualStyleBackColor = False
        '
        'Button280
        '
        Me.Button280.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button280.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button280.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button280.ForeColor = System.Drawing.Color.White
        Me.Button280.Location = New System.Drawing.Point(137, 366)
        Me.Button280.Name = "Button280"
        Me.Button280.Size = New System.Drawing.Size(31, 32)
        Me.Button280.TabIndex = 261
        Me.Button280.Text = "A"
        Me.Button280.UseVisualStyleBackColor = False
        '
        'Button281
        '
        Me.Button281.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button281.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button281.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button281.ForeColor = System.Drawing.Color.White
        Me.Button281.Location = New System.Drawing.Point(660, 394)
        Me.Button281.Name = "Button281"
        Me.Button281.Size = New System.Drawing.Size(31, 32)
        Me.Button281.TabIndex = 300
        Me.Button281.Text = "A"
        Me.Button281.UseVisualStyleBackColor = False
        '
        'Button282
        '
        Me.Button282.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button282.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button282.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button282.ForeColor = System.Drawing.Color.White
        Me.Button282.Location = New System.Drawing.Point(632, 394)
        Me.Button282.Name = "Button282"
        Me.Button282.Size = New System.Drawing.Size(31, 32)
        Me.Button282.TabIndex = 299
        Me.Button282.Text = "G"
        Me.Button282.UseVisualStyleBackColor = False
        '
        'Button283
        '
        Me.Button283.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button283.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button283.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button283.ForeColor = System.Drawing.Color.White
        Me.Button283.Location = New System.Drawing.Point(604, 394)
        Me.Button283.Name = "Button283"
        Me.Button283.Size = New System.Drawing.Size(31, 32)
        Me.Button283.TabIndex = 298
        Me.Button283.Text = "A"
        Me.Button283.UseVisualStyleBackColor = False
        '
        'Button284
        '
        Me.Button284.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button284.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button284.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button284.ForeColor = System.Drawing.Color.White
        Me.Button284.Location = New System.Drawing.Point(578, 394)
        Me.Button284.Name = "Button284"
        Me.Button284.Size = New System.Drawing.Size(31, 32)
        Me.Button284.TabIndex = 297
        Me.Button284.Text = "W"
        Me.Button284.UseVisualStyleBackColor = False
        '
        'Button285
        '
        Me.Button285.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button285.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button285.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button285.ForeColor = System.Drawing.Color.White
        Me.Button285.Location = New System.Drawing.Point(549, 394)
        Me.Button285.Name = "Button285"
        Me.Button285.Size = New System.Drawing.Size(31, 32)
        Me.Button285.TabIndex = 296
        Me.Button285.Text = "I"
        Me.Button285.UseVisualStyleBackColor = False
        '
        'Button286
        '
        Me.Button286.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button286.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button286.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button286.ForeColor = System.Drawing.Color.White
        Me.Button286.Location = New System.Drawing.Point(521, 394)
        Me.Button286.Name = "Button286"
        Me.Button286.Size = New System.Drawing.Size(31, 32)
        Me.Button286.TabIndex = 295
        Me.Button286.Text = "H"
        Me.Button286.UseVisualStyleBackColor = False
        '
        'Button287
        '
        Me.Button287.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button287.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button287.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button287.ForeColor = System.Drawing.Color.White
        Me.Button287.Location = New System.Drawing.Point(493, 394)
        Me.Button287.Name = "Button287"
        Me.Button287.Size = New System.Drawing.Size(31, 32)
        Me.Button287.TabIndex = 294
        Me.Button287.Text = "A"
        Me.Button287.UseVisualStyleBackColor = False
        '
        'Button288
        '
        Me.Button288.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button288.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button288.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button288.ForeColor = System.Drawing.Color.White
        Me.Button288.Location = New System.Drawing.Point(467, 394)
        Me.Button288.Name = "Button288"
        Me.Button288.Size = New System.Drawing.Size(31, 32)
        Me.Button288.TabIndex = 293
        Me.Button288.Text = "A"
        Me.Button288.UseVisualStyleBackColor = False
        '
        'Button289
        '
        Me.Button289.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button289.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button289.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button289.ForeColor = System.Drawing.Color.White
        Me.Button289.Location = New System.Drawing.Point(441, 394)
        Me.Button289.Name = "Button289"
        Me.Button289.Size = New System.Drawing.Size(31, 32)
        Me.Button289.TabIndex = 292
        Me.Button289.Text = "A"
        Me.Button289.UseVisualStyleBackColor = False
        '
        'Button290
        '
        Me.Button290.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button290.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button290.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button290.ForeColor = System.Drawing.Color.White
        Me.Button290.Location = New System.Drawing.Point(413, 394)
        Me.Button290.Name = "Button290"
        Me.Button290.Size = New System.Drawing.Size(31, 32)
        Me.Button290.TabIndex = 291
        Me.Button290.Text = "A"
        Me.Button290.UseVisualStyleBackColor = False
        '
        'Button291
        '
        Me.Button291.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button291.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button291.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button291.ForeColor = System.Drawing.Color.White
        Me.Button291.Location = New System.Drawing.Point(385, 394)
        Me.Button291.Name = "Button291"
        Me.Button291.Size = New System.Drawing.Size(31, 32)
        Me.Button291.TabIndex = 290
        Me.Button291.Text = "A"
        Me.Button291.UseVisualStyleBackColor = False
        '
        'Button292
        '
        Me.Button292.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button292.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button292.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button292.ForeColor = System.Drawing.Color.White
        Me.Button292.Location = New System.Drawing.Point(359, 394)
        Me.Button292.Name = "Button292"
        Me.Button292.Size = New System.Drawing.Size(31, 32)
        Me.Button292.TabIndex = 289
        Me.Button292.Text = "T"
        Me.Button292.UseVisualStyleBackColor = False
        '
        'Button293
        '
        Me.Button293.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button293.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button293.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button293.ForeColor = System.Drawing.Color.White
        Me.Button293.Location = New System.Drawing.Point(330, 394)
        Me.Button293.Name = "Button293"
        Me.Button293.Size = New System.Drawing.Size(31, 32)
        Me.Button293.TabIndex = 288
        Me.Button293.Text = "L"
        Me.Button293.UseVisualStyleBackColor = False
        '
        'Button294
        '
        Me.Button294.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button294.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button294.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button294.ForeColor = System.Drawing.Color.White
        Me.Button294.Location = New System.Drawing.Point(302, 394)
        Me.Button294.Name = "Button294"
        Me.Button294.Size = New System.Drawing.Size(31, 32)
        Me.Button294.TabIndex = 287
        Me.Button294.Text = "K"
        Me.Button294.UseVisualStyleBackColor = False
        '
        'Button295
        '
        Me.Button295.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button295.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button295.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button295.ForeColor = System.Drawing.Color.White
        Me.Button295.Location = New System.Drawing.Point(274, 394)
        Me.Button295.Name = "Button295"
        Me.Button295.Size = New System.Drawing.Size(31, 32)
        Me.Button295.TabIndex = 286
        Me.Button295.Text = "M"
        Me.Button295.UseVisualStyleBackColor = False
        '
        'Button296
        '
        Me.Button296.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button296.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button296.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button296.ForeColor = System.Drawing.Color.White
        Me.Button296.Location = New System.Drawing.Point(248, 394)
        Me.Button296.Name = "Button296"
        Me.Button296.Size = New System.Drawing.Size(31, 32)
        Me.Button296.TabIndex = 285
        Me.Button296.Text = "J"
        Me.Button296.UseVisualStyleBackColor = False
        '
        'Button297
        '
        Me.Button297.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button297.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button297.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button297.ForeColor = System.Drawing.Color.White
        Me.Button297.Location = New System.Drawing.Point(219, 394)
        Me.Button297.Name = "Button297"
        Me.Button297.Size = New System.Drawing.Size(31, 32)
        Me.Button297.TabIndex = 284
        Me.Button297.Text = "U"
        Me.Button297.UseVisualStyleBackColor = False
        '
        'Button298
        '
        Me.Button298.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button298.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button298.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button298.ForeColor = System.Drawing.Color.White
        Me.Button298.Location = New System.Drawing.Point(191, 394)
        Me.Button298.Name = "Button298"
        Me.Button298.Size = New System.Drawing.Size(31, 32)
        Me.Button298.TabIndex = 283
        Me.Button298.Text = "H"
        Me.Button298.UseVisualStyleBackColor = False
        '
        'Button299
        '
        Me.Button299.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button299.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button299.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button299.ForeColor = System.Drawing.Color.White
        Me.Button299.Location = New System.Drawing.Point(163, 394)
        Me.Button299.Name = "Button299"
        Me.Button299.Size = New System.Drawing.Size(31, 32)
        Me.Button299.TabIndex = 282
        Me.Button299.Text = "R"
        Me.Button299.UseVisualStyleBackColor = False
        '
        'Button300
        '
        Me.Button300.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button300.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Button300.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button300.ForeColor = System.Drawing.Color.White
        Me.Button300.Location = New System.Drawing.Point(137, 394)
        Me.Button300.Name = "Button300"
        Me.Button300.Size = New System.Drawing.Size(31, 32)
        Me.Button300.TabIndex = 281
        Me.Button300.Text = "B"
        Me.Button300.UseVisualStyleBackColor = False
        '
        'TextBox5
        '
        Me.TextBox5.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox5.Location = New System.Drawing.Point(7, 269)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(36, 26)
        Me.TextBox5.TabIndex = 311
        '
        'TextBox4
        '
        Me.TextBox4.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox4.Location = New System.Drawing.Point(7, 216)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(36, 26)
        Me.TextBox4.TabIndex = 310
        '
        'TextBox3
        '
        Me.TextBox3.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(7, 159)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(36, 26)
        Me.TextBox3.TabIndex = 309
        '
        'TextBox2
        '
        Me.TextBox2.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(7, 110)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(36, 26)
        Me.TextBox2.TabIndex = 308
        '
        'TextBox1
        '
        Me.TextBox1.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(7, 62)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(36, 26)
        Me.TextBox1.TabIndex = 307
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label6.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label6.Location = New System.Drawing.Point(10, 243)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(128, 25)
        Me.Label6.TabIndex = 306
        Me.Label6.Text = "BINIBINI"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label5.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label5.Location = New System.Drawing.Point(23, 188)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(112, 25)
        Me.Label5.TabIndex = 305
        Me.Label5.Text = "LALAKI"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label4.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label4.Location = New System.Drawing.Point(29, 135)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(102, 25)
        Me.Label4.TabIndex = 304
        Me.Label4.Text = "BABAE"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label3.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label3.Location = New System.Drawing.Point(39, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(92, 25)
        Me.Label3.TabIndex = 303
        Me.Label3.Text = "LIBRO"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label2.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label2.Location = New System.Drawing.Point(39, 37)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(83, 25)
        Me.Label2.TabIndex = 302
        Me.Label2.Text = "SILID"
        '
        'TextBox6
        '
        Me.TextBox6.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox6.Location = New System.Drawing.Point(706, 255)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(36, 26)
        Me.TextBox6.TabIndex = 321
        '
        'TextBox7
        '
        Me.TextBox7.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox7.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox7.Location = New System.Drawing.Point(706, 203)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(36, 26)
        Me.TextBox7.TabIndex = 320
        '
        'TextBox8
        '
        Me.TextBox8.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox8.Location = New System.Drawing.Point(706, 154)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(36, 26)
        Me.TextBox8.TabIndex = 319
        '
        'TextBox9
        '
        Me.TextBox9.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox9.Location = New System.Drawing.Point(706, 110)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(36, 26)
        Me.TextBox9.TabIndex = 318
        '
        'TextBox10
        '
        Me.TextBox10.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox10.Location = New System.Drawing.Point(706, 62)
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(36, 26)
        Me.TextBox10.TabIndex = 317
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label7.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label7.Location = New System.Drawing.Point(737, 227)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(117, 25)
        Me.Label7.TabIndex = 316
        Me.Label7.Text = "DIWATA"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label8.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(734, 181)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(121, 25)
        Me.Label8.TabIndex = 315
        Me.Label8.Text = "HIWAGA"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.Transparent
        Me.Label9.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label9.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label9.Location = New System.Drawing.Point(741, 133)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(113, 25)
        Me.Label9.TabIndex = 314
        Me.Label9.Text = "DAKILA"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.BackColor = System.Drawing.Color.Transparent
        Me.Label10.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label10.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label10.Location = New System.Drawing.Point(740, 84)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(114, 25)
        Me.Label10.TabIndex = 313
        Me.Label10.Text = "MUSIKA"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label11.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label11.Location = New System.Drawing.Point(727, 34)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(127, 25)
        Me.Label11.TabIndex = 312
        Me.Label11.Text = "MARIKIT"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Transparent
        Me.Label12.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label12.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label12.Location = New System.Drawing.Point(692, 291)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(163, 25)
        Me.Label12.TabIndex = 322
        Me.Label12.Text = "Words remain"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.White
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(767, 322)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(91, 55)
        Me.Label13.TabIndex = 324
        Me.Label13.Text = "/10"
        '
        'TextBox11
        '
        Me.TextBox11.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox11.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox11.Location = New System.Drawing.Point(697, 319)
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(163, 62)
        Me.TextBox11.TabIndex = 323
        Me.TextBox11.Text = " "
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.BackColor = System.Drawing.Color.Transparent
        Me.Label14.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.Label14.Font = New System.Drawing.Font("Modern No. 20", 18.0!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label14.Location = New System.Drawing.Point(29, 298)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(77, 25)
        Me.Label14.TabIndex = 325
        Me.Label14.Text = "Moves"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.BackColor = System.Drawing.Color.White
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(64, 326)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(64, 55)
        Me.Label15.TabIndex = 327
        Me.Label15.Text = "/5"
        '
        'TextBox12
        '
        Me.TextBox12.Cursor = System.Windows.Forms.Cursors.PanNW
        Me.TextBox12.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox12.Location = New System.Drawing.Point(5, 324)
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(126, 62)
        Me.TextBox12.TabIndex = 326
        Me.TextBox12.Text = " "
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(708, 427)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(149, 15)
        Me.ProgressBar1.TabIndex = 328
        '
        'Timer1
        '
        '
        'Form31
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightPink
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(867, 455)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.TextBox12)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.TextBox11)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.TextBox6)
        Me.Controls.Add(Me.TextBox7)
        Me.Controls.Add(Me.TextBox8)
        Me.Controls.Add(Me.TextBox9)
        Me.Controls.Add(Me.TextBox10)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.TextBox5)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Button281)
        Me.Controls.Add(Me.Button282)
        Me.Controls.Add(Me.Button283)
        Me.Controls.Add(Me.Button284)
        Me.Controls.Add(Me.Button285)
        Me.Controls.Add(Me.Button286)
        Me.Controls.Add(Me.Button287)
        Me.Controls.Add(Me.Button288)
        Me.Controls.Add(Me.Button289)
        Me.Controls.Add(Me.Button290)
        Me.Controls.Add(Me.Button291)
        Me.Controls.Add(Me.Button292)
        Me.Controls.Add(Me.Button293)
        Me.Controls.Add(Me.Button294)
        Me.Controls.Add(Me.Button295)
        Me.Controls.Add(Me.Button296)
        Me.Controls.Add(Me.Button297)
        Me.Controls.Add(Me.Button298)
        Me.Controls.Add(Me.Button299)
        Me.Controls.Add(Me.Button300)
        Me.Controls.Add(Me.Button261)
        Me.Controls.Add(Me.Button262)
        Me.Controls.Add(Me.Button263)
        Me.Controls.Add(Me.Button264)
        Me.Controls.Add(Me.Button265)
        Me.Controls.Add(Me.Button266)
        Me.Controls.Add(Me.Button267)
        Me.Controls.Add(Me.Button268)
        Me.Controls.Add(Me.Button269)
        Me.Controls.Add(Me.Button270)
        Me.Controls.Add(Me.Button271)
        Me.Controls.Add(Me.Button272)
        Me.Controls.Add(Me.Button273)
        Me.Controls.Add(Me.Button274)
        Me.Controls.Add(Me.Button275)
        Me.Controls.Add(Me.Button276)
        Me.Controls.Add(Me.Button277)
        Me.Controls.Add(Me.Button278)
        Me.Controls.Add(Me.Button279)
        Me.Controls.Add(Me.Button280)
        Me.Controls.Add(Me.Button241)
        Me.Controls.Add(Me.Button242)
        Me.Controls.Add(Me.Button243)
        Me.Controls.Add(Me.Button244)
        Me.Controls.Add(Me.Button245)
        Me.Controls.Add(Me.Button246)
        Me.Controls.Add(Me.Button247)
        Me.Controls.Add(Me.Button248)
        Me.Controls.Add(Me.Button249)
        Me.Controls.Add(Me.Button250)
        Me.Controls.Add(Me.Button251)
        Me.Controls.Add(Me.Button252)
        Me.Controls.Add(Me.Button253)
        Me.Controls.Add(Me.Button254)
        Me.Controls.Add(Me.Button255)
        Me.Controls.Add(Me.Button256)
        Me.Controls.Add(Me.Button257)
        Me.Controls.Add(Me.Button258)
        Me.Controls.Add(Me.Button259)
        Me.Controls.Add(Me.Button260)
        Me.Controls.Add(Me.Button221)
        Me.Controls.Add(Me.Button222)
        Me.Controls.Add(Me.Button223)
        Me.Controls.Add(Me.Button224)
        Me.Controls.Add(Me.Button225)
        Me.Controls.Add(Me.Button226)
        Me.Controls.Add(Me.Button227)
        Me.Controls.Add(Me.Button228)
        Me.Controls.Add(Me.Button229)
        Me.Controls.Add(Me.Button230)
        Me.Controls.Add(Me.Button231)
        Me.Controls.Add(Me.Button232)
        Me.Controls.Add(Me.Button233)
        Me.Controls.Add(Me.Button234)
        Me.Controls.Add(Me.Button235)
        Me.Controls.Add(Me.Button236)
        Me.Controls.Add(Me.Button237)
        Me.Controls.Add(Me.Button238)
        Me.Controls.Add(Me.Button239)
        Me.Controls.Add(Me.Button240)
        Me.Controls.Add(Me.Button201)
        Me.Controls.Add(Me.Button202)
        Me.Controls.Add(Me.Button203)
        Me.Controls.Add(Me.Button204)
        Me.Controls.Add(Me.Button205)
        Me.Controls.Add(Me.Button206)
        Me.Controls.Add(Me.Button207)
        Me.Controls.Add(Me.Button208)
        Me.Controls.Add(Me.Button209)
        Me.Controls.Add(Me.Button210)
        Me.Controls.Add(Me.Button211)
        Me.Controls.Add(Me.Button212)
        Me.Controls.Add(Me.Button213)
        Me.Controls.Add(Me.Button214)
        Me.Controls.Add(Me.Button215)
        Me.Controls.Add(Me.Button216)
        Me.Controls.Add(Me.Button217)
        Me.Controls.Add(Me.Button218)
        Me.Controls.Add(Me.Button219)
        Me.Controls.Add(Me.Button220)
        Me.Controls.Add(Me.Button181)
        Me.Controls.Add(Me.Button182)
        Me.Controls.Add(Me.Button183)
        Me.Controls.Add(Me.Button184)
        Me.Controls.Add(Me.Button185)
        Me.Controls.Add(Me.Button186)
        Me.Controls.Add(Me.Button187)
        Me.Controls.Add(Me.Button188)
        Me.Controls.Add(Me.Button189)
        Me.Controls.Add(Me.Button190)
        Me.Controls.Add(Me.Button191)
        Me.Controls.Add(Me.Button192)
        Me.Controls.Add(Me.Button193)
        Me.Controls.Add(Me.Button194)
        Me.Controls.Add(Me.Button195)
        Me.Controls.Add(Me.Button196)
        Me.Controls.Add(Me.Button197)
        Me.Controls.Add(Me.Button198)
        Me.Controls.Add(Me.Button199)
        Me.Controls.Add(Me.Button200)
        Me.Controls.Add(Me.Button161)
        Me.Controls.Add(Me.Button162)
        Me.Controls.Add(Me.Button163)
        Me.Controls.Add(Me.Button164)
        Me.Controls.Add(Me.Button165)
        Me.Controls.Add(Me.Button166)
        Me.Controls.Add(Me.Button167)
        Me.Controls.Add(Me.Button168)
        Me.Controls.Add(Me.Button169)
        Me.Controls.Add(Me.Button170)
        Me.Controls.Add(Me.Button171)
        Me.Controls.Add(Me.Button172)
        Me.Controls.Add(Me.Button173)
        Me.Controls.Add(Me.Button174)
        Me.Controls.Add(Me.Button175)
        Me.Controls.Add(Me.Button176)
        Me.Controls.Add(Me.Button177)
        Me.Controls.Add(Me.Button178)
        Me.Controls.Add(Me.Button179)
        Me.Controls.Add(Me.Button180)
        Me.Controls.Add(Me.Button141)
        Me.Controls.Add(Me.Button142)
        Me.Controls.Add(Me.Button143)
        Me.Controls.Add(Me.Button144)
        Me.Controls.Add(Me.Button145)
        Me.Controls.Add(Me.Button146)
        Me.Controls.Add(Me.Button147)
        Me.Controls.Add(Me.Button148)
        Me.Controls.Add(Me.Button149)
        Me.Controls.Add(Me.Button150)
        Me.Controls.Add(Me.Button151)
        Me.Controls.Add(Me.Button152)
        Me.Controls.Add(Me.Button153)
        Me.Controls.Add(Me.Button154)
        Me.Controls.Add(Me.Button155)
        Me.Controls.Add(Me.Button156)
        Me.Controls.Add(Me.Button157)
        Me.Controls.Add(Me.Button158)
        Me.Controls.Add(Me.Button159)
        Me.Controls.Add(Me.Button160)
        Me.Controls.Add(Me.Button121)
        Me.Controls.Add(Me.Button122)
        Me.Controls.Add(Me.Button123)
        Me.Controls.Add(Me.Button124)
        Me.Controls.Add(Me.Button125)
        Me.Controls.Add(Me.Button126)
        Me.Controls.Add(Me.Button127)
        Me.Controls.Add(Me.Button128)
        Me.Controls.Add(Me.Button129)
        Me.Controls.Add(Me.Button130)
        Me.Controls.Add(Me.Button131)
        Me.Controls.Add(Me.Button132)
        Me.Controls.Add(Me.Button133)
        Me.Controls.Add(Me.Button134)
        Me.Controls.Add(Me.Button135)
        Me.Controls.Add(Me.Button136)
        Me.Controls.Add(Me.Button137)
        Me.Controls.Add(Me.Button138)
        Me.Controls.Add(Me.Button139)
        Me.Controls.Add(Me.Button140)
        Me.Controls.Add(Me.Button101)
        Me.Controls.Add(Me.Button102)
        Me.Controls.Add(Me.Button103)
        Me.Controls.Add(Me.Button104)
        Me.Controls.Add(Me.Button105)
        Me.Controls.Add(Me.Button106)
        Me.Controls.Add(Me.Button107)
        Me.Controls.Add(Me.Button108)
        Me.Controls.Add(Me.Button109)
        Me.Controls.Add(Me.Button110)
        Me.Controls.Add(Me.Button111)
        Me.Controls.Add(Me.Button112)
        Me.Controls.Add(Me.Button113)
        Me.Controls.Add(Me.Button114)
        Me.Controls.Add(Me.Button115)
        Me.Controls.Add(Me.Button116)
        Me.Controls.Add(Me.Button117)
        Me.Controls.Add(Me.Button118)
        Me.Controls.Add(Me.Button119)
        Me.Controls.Add(Me.Button120)
        Me.Controls.Add(Me.Button81)
        Me.Controls.Add(Me.Button82)
        Me.Controls.Add(Me.Button83)
        Me.Controls.Add(Me.Button84)
        Me.Controls.Add(Me.Button85)
        Me.Controls.Add(Me.Button86)
        Me.Controls.Add(Me.Button87)
        Me.Controls.Add(Me.Button88)
        Me.Controls.Add(Me.Button89)
        Me.Controls.Add(Me.Button90)
        Me.Controls.Add(Me.Button91)
        Me.Controls.Add(Me.Button92)
        Me.Controls.Add(Me.Button93)
        Me.Controls.Add(Me.Button94)
        Me.Controls.Add(Me.Button95)
        Me.Controls.Add(Me.Button96)
        Me.Controls.Add(Me.Button97)
        Me.Controls.Add(Me.Button98)
        Me.Controls.Add(Me.Button99)
        Me.Controls.Add(Me.Button100)
        Me.Controls.Add(Me.Button61)
        Me.Controls.Add(Me.Button62)
        Me.Controls.Add(Me.Button63)
        Me.Controls.Add(Me.Button64)
        Me.Controls.Add(Me.Button65)
        Me.Controls.Add(Me.Button66)
        Me.Controls.Add(Me.Button67)
        Me.Controls.Add(Me.Button68)
        Me.Controls.Add(Me.Button69)
        Me.Controls.Add(Me.Button70)
        Me.Controls.Add(Me.Button71)
        Me.Controls.Add(Me.Button72)
        Me.Controls.Add(Me.Button73)
        Me.Controls.Add(Me.Button74)
        Me.Controls.Add(Me.Button75)
        Me.Controls.Add(Me.Button76)
        Me.Controls.Add(Me.Button77)
        Me.Controls.Add(Me.Button78)
        Me.Controls.Add(Me.Button79)
        Me.Controls.Add(Me.Button80)
        Me.Controls.Add(Me.Button41)
        Me.Controls.Add(Me.Button42)
        Me.Controls.Add(Me.Button43)
        Me.Controls.Add(Me.Button44)
        Me.Controls.Add(Me.Button45)
        Me.Controls.Add(Me.Button46)
        Me.Controls.Add(Me.Button47)
        Me.Controls.Add(Me.Button48)
        Me.Controls.Add(Me.Button49)
        Me.Controls.Add(Me.Button50)
        Me.Controls.Add(Me.Button51)
        Me.Controls.Add(Me.Button52)
        Me.Controls.Add(Me.Button53)
        Me.Controls.Add(Me.Button54)
        Me.Controls.Add(Me.Button55)
        Me.Controls.Add(Me.Button56)
        Me.Controls.Add(Me.Button57)
        Me.Controls.Add(Me.Button58)
        Me.Controls.Add(Me.Button59)
        Me.Controls.Add(Me.Button60)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button35)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button38)
        Me.Controls.Add(Me.Button39)
        Me.Controls.Add(Me.Button40)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form31"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form31"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Button46 As System.Windows.Forms.Button
    Friend WithEvents Button47 As System.Windows.Forms.Button
    Friend WithEvents Button48 As System.Windows.Forms.Button
    Friend WithEvents Button49 As System.Windows.Forms.Button
    Friend WithEvents Button50 As System.Windows.Forms.Button
    Friend WithEvents Button51 As System.Windows.Forms.Button
    Friend WithEvents Button52 As System.Windows.Forms.Button
    Friend WithEvents Button53 As System.Windows.Forms.Button
    Friend WithEvents Button54 As System.Windows.Forms.Button
    Friend WithEvents Button55 As System.Windows.Forms.Button
    Friend WithEvents Button56 As System.Windows.Forms.Button
    Friend WithEvents Button57 As System.Windows.Forms.Button
    Friend WithEvents Button58 As System.Windows.Forms.Button
    Friend WithEvents Button59 As System.Windows.Forms.Button
    Friend WithEvents Button60 As System.Windows.Forms.Button
    Friend WithEvents Button61 As System.Windows.Forms.Button
    Friend WithEvents Button62 As System.Windows.Forms.Button
    Friend WithEvents Button63 As System.Windows.Forms.Button
    Friend WithEvents Button64 As System.Windows.Forms.Button
    Friend WithEvents Button65 As System.Windows.Forms.Button
    Friend WithEvents Button66 As System.Windows.Forms.Button
    Friend WithEvents Button67 As System.Windows.Forms.Button
    Friend WithEvents Button68 As System.Windows.Forms.Button
    Friend WithEvents Button69 As System.Windows.Forms.Button
    Friend WithEvents Button70 As System.Windows.Forms.Button
    Friend WithEvents Button71 As System.Windows.Forms.Button
    Friend WithEvents Button72 As System.Windows.Forms.Button
    Friend WithEvents Button73 As System.Windows.Forms.Button
    Friend WithEvents Button74 As System.Windows.Forms.Button
    Friend WithEvents Button75 As System.Windows.Forms.Button
    Friend WithEvents Button76 As System.Windows.Forms.Button
    Friend WithEvents Button77 As System.Windows.Forms.Button
    Friend WithEvents Button78 As System.Windows.Forms.Button
    Friend WithEvents Button79 As System.Windows.Forms.Button
    Friend WithEvents Button80 As System.Windows.Forms.Button
    Friend WithEvents Button81 As System.Windows.Forms.Button
    Friend WithEvents Button82 As System.Windows.Forms.Button
    Friend WithEvents Button83 As System.Windows.Forms.Button
    Friend WithEvents Button84 As System.Windows.Forms.Button
    Friend WithEvents Button85 As System.Windows.Forms.Button
    Friend WithEvents Button86 As System.Windows.Forms.Button
    Friend WithEvents Button87 As System.Windows.Forms.Button
    Friend WithEvents Button88 As System.Windows.Forms.Button
    Friend WithEvents Button89 As System.Windows.Forms.Button
    Friend WithEvents Button90 As System.Windows.Forms.Button
    Friend WithEvents Button91 As System.Windows.Forms.Button
    Friend WithEvents Button92 As System.Windows.Forms.Button
    Friend WithEvents Button93 As System.Windows.Forms.Button
    Friend WithEvents Button94 As System.Windows.Forms.Button
    Friend WithEvents Button95 As System.Windows.Forms.Button
    Friend WithEvents Button96 As System.Windows.Forms.Button
    Friend WithEvents Button97 As System.Windows.Forms.Button
    Friend WithEvents Button98 As System.Windows.Forms.Button
    Friend WithEvents Button99 As System.Windows.Forms.Button
    Friend WithEvents Button100 As System.Windows.Forms.Button
    Friend WithEvents Button101 As System.Windows.Forms.Button
    Friend WithEvents Button102 As System.Windows.Forms.Button
    Friend WithEvents Button103 As System.Windows.Forms.Button
    Friend WithEvents Button104 As System.Windows.Forms.Button
    Friend WithEvents Button105 As System.Windows.Forms.Button
    Friend WithEvents Button106 As System.Windows.Forms.Button
    Friend WithEvents Button107 As System.Windows.Forms.Button
    Friend WithEvents Button108 As System.Windows.Forms.Button
    Friend WithEvents Button109 As System.Windows.Forms.Button
    Friend WithEvents Button110 As System.Windows.Forms.Button
    Friend WithEvents Button111 As System.Windows.Forms.Button
    Friend WithEvents Button112 As System.Windows.Forms.Button
    Friend WithEvents Button113 As System.Windows.Forms.Button
    Friend WithEvents Button114 As System.Windows.Forms.Button
    Friend WithEvents Button115 As System.Windows.Forms.Button
    Friend WithEvents Button116 As System.Windows.Forms.Button
    Friend WithEvents Button117 As System.Windows.Forms.Button
    Friend WithEvents Button118 As System.Windows.Forms.Button
    Friend WithEvents Button119 As System.Windows.Forms.Button
    Friend WithEvents Button120 As System.Windows.Forms.Button
    Friend WithEvents Button121 As System.Windows.Forms.Button
    Friend WithEvents Button122 As System.Windows.Forms.Button
    Friend WithEvents Button123 As System.Windows.Forms.Button
    Friend WithEvents Button124 As System.Windows.Forms.Button
    Friend WithEvents Button125 As System.Windows.Forms.Button
    Friend WithEvents Button126 As System.Windows.Forms.Button
    Friend WithEvents Button127 As System.Windows.Forms.Button
    Friend WithEvents Button128 As System.Windows.Forms.Button
    Friend WithEvents Button129 As System.Windows.Forms.Button
    Friend WithEvents Button130 As System.Windows.Forms.Button
    Friend WithEvents Button131 As System.Windows.Forms.Button
    Friend WithEvents Button132 As System.Windows.Forms.Button
    Friend WithEvents Button133 As System.Windows.Forms.Button
    Friend WithEvents Button134 As System.Windows.Forms.Button
    Friend WithEvents Button135 As System.Windows.Forms.Button
    Friend WithEvents Button136 As System.Windows.Forms.Button
    Friend WithEvents Button137 As System.Windows.Forms.Button
    Friend WithEvents Button138 As System.Windows.Forms.Button
    Friend WithEvents Button139 As System.Windows.Forms.Button
    Friend WithEvents Button140 As System.Windows.Forms.Button
    Friend WithEvents Button141 As System.Windows.Forms.Button
    Friend WithEvents Button142 As System.Windows.Forms.Button
    Friend WithEvents Button143 As System.Windows.Forms.Button
    Friend WithEvents Button144 As System.Windows.Forms.Button
    Friend WithEvents Button145 As System.Windows.Forms.Button
    Friend WithEvents Button146 As System.Windows.Forms.Button
    Friend WithEvents Button147 As System.Windows.Forms.Button
    Friend WithEvents Button148 As System.Windows.Forms.Button
    Friend WithEvents Button149 As System.Windows.Forms.Button
    Friend WithEvents Button150 As System.Windows.Forms.Button
    Friend WithEvents Button151 As System.Windows.Forms.Button
    Friend WithEvents Button152 As System.Windows.Forms.Button
    Friend WithEvents Button153 As System.Windows.Forms.Button
    Friend WithEvents Button154 As System.Windows.Forms.Button
    Friend WithEvents Button155 As System.Windows.Forms.Button
    Friend WithEvents Button156 As System.Windows.Forms.Button
    Friend WithEvents Button157 As System.Windows.Forms.Button
    Friend WithEvents Button158 As System.Windows.Forms.Button
    Friend WithEvents Button159 As System.Windows.Forms.Button
    Friend WithEvents Button160 As System.Windows.Forms.Button
    Friend WithEvents Button161 As System.Windows.Forms.Button
    Friend WithEvents Button162 As System.Windows.Forms.Button
    Friend WithEvents Button163 As System.Windows.Forms.Button
    Friend WithEvents Button164 As System.Windows.Forms.Button
    Friend WithEvents Button165 As System.Windows.Forms.Button
    Friend WithEvents Button166 As System.Windows.Forms.Button
    Friend WithEvents Button167 As System.Windows.Forms.Button
    Friend WithEvents Button168 As System.Windows.Forms.Button
    Friend WithEvents Button169 As System.Windows.Forms.Button
    Friend WithEvents Button170 As System.Windows.Forms.Button
    Friend WithEvents Button171 As System.Windows.Forms.Button
    Friend WithEvents Button172 As System.Windows.Forms.Button
    Friend WithEvents Button173 As System.Windows.Forms.Button
    Friend WithEvents Button174 As System.Windows.Forms.Button
    Friend WithEvents Button175 As System.Windows.Forms.Button
    Friend WithEvents Button176 As System.Windows.Forms.Button
    Friend WithEvents Button177 As System.Windows.Forms.Button
    Friend WithEvents Button178 As System.Windows.Forms.Button
    Friend WithEvents Button179 As System.Windows.Forms.Button
    Friend WithEvents Button180 As System.Windows.Forms.Button
    Friend WithEvents Button181 As System.Windows.Forms.Button
    Friend WithEvents Button182 As System.Windows.Forms.Button
    Friend WithEvents Button183 As System.Windows.Forms.Button
    Friend WithEvents Button184 As System.Windows.Forms.Button
    Friend WithEvents Button185 As System.Windows.Forms.Button
    Friend WithEvents Button186 As System.Windows.Forms.Button
    Friend WithEvents Button187 As System.Windows.Forms.Button
    Friend WithEvents Button188 As System.Windows.Forms.Button
    Friend WithEvents Button189 As System.Windows.Forms.Button
    Friend WithEvents Button190 As System.Windows.Forms.Button
    Friend WithEvents Button191 As System.Windows.Forms.Button
    Friend WithEvents Button192 As System.Windows.Forms.Button
    Friend WithEvents Button193 As System.Windows.Forms.Button
    Friend WithEvents Button194 As System.Windows.Forms.Button
    Friend WithEvents Button195 As System.Windows.Forms.Button
    Friend WithEvents Button196 As System.Windows.Forms.Button
    Friend WithEvents Button197 As System.Windows.Forms.Button
    Friend WithEvents Button198 As System.Windows.Forms.Button
    Friend WithEvents Button199 As System.Windows.Forms.Button
    Friend WithEvents Button200 As System.Windows.Forms.Button
    Friend WithEvents Button201 As System.Windows.Forms.Button
    Friend WithEvents Button202 As System.Windows.Forms.Button
    Friend WithEvents Button203 As System.Windows.Forms.Button
    Friend WithEvents Button204 As System.Windows.Forms.Button
    Friend WithEvents Button205 As System.Windows.Forms.Button
    Friend WithEvents Button206 As System.Windows.Forms.Button
    Friend WithEvents Button207 As System.Windows.Forms.Button
    Friend WithEvents Button208 As System.Windows.Forms.Button
    Friend WithEvents Button209 As System.Windows.Forms.Button
    Friend WithEvents Button210 As System.Windows.Forms.Button
    Friend WithEvents Button211 As System.Windows.Forms.Button
    Friend WithEvents Button212 As System.Windows.Forms.Button
    Friend WithEvents Button213 As System.Windows.Forms.Button
    Friend WithEvents Button214 As System.Windows.Forms.Button
    Friend WithEvents Button215 As System.Windows.Forms.Button
    Friend WithEvents Button216 As System.Windows.Forms.Button
    Friend WithEvents Button217 As System.Windows.Forms.Button
    Friend WithEvents Button218 As System.Windows.Forms.Button
    Friend WithEvents Button219 As System.Windows.Forms.Button
    Friend WithEvents Button220 As System.Windows.Forms.Button
    Friend WithEvents Button221 As System.Windows.Forms.Button
    Friend WithEvents Button222 As System.Windows.Forms.Button
    Friend WithEvents Button223 As System.Windows.Forms.Button
    Friend WithEvents Button224 As System.Windows.Forms.Button
    Friend WithEvents Button225 As System.Windows.Forms.Button
    Friend WithEvents Button226 As System.Windows.Forms.Button
    Friend WithEvents Button227 As System.Windows.Forms.Button
    Friend WithEvents Button228 As System.Windows.Forms.Button
    Friend WithEvents Button229 As System.Windows.Forms.Button
    Friend WithEvents Button230 As System.Windows.Forms.Button
    Friend WithEvents Button231 As System.Windows.Forms.Button
    Friend WithEvents Button232 As System.Windows.Forms.Button
    Friend WithEvents Button233 As System.Windows.Forms.Button
    Friend WithEvents Button234 As System.Windows.Forms.Button
    Friend WithEvents Button235 As System.Windows.Forms.Button
    Friend WithEvents Button236 As System.Windows.Forms.Button
    Friend WithEvents Button237 As System.Windows.Forms.Button
    Friend WithEvents Button238 As System.Windows.Forms.Button
    Friend WithEvents Button239 As System.Windows.Forms.Button
    Friend WithEvents Button240 As System.Windows.Forms.Button
    Friend WithEvents Button241 As System.Windows.Forms.Button
    Friend WithEvents Button242 As System.Windows.Forms.Button
    Friend WithEvents Button243 As System.Windows.Forms.Button
    Friend WithEvents Button244 As System.Windows.Forms.Button
    Friend WithEvents Button245 As System.Windows.Forms.Button
    Friend WithEvents Button246 As System.Windows.Forms.Button
    Friend WithEvents Button247 As System.Windows.Forms.Button
    Friend WithEvents Button248 As System.Windows.Forms.Button
    Friend WithEvents Button249 As System.Windows.Forms.Button
    Friend WithEvents Button250 As System.Windows.Forms.Button
    Friend WithEvents Button251 As System.Windows.Forms.Button
    Friend WithEvents Button252 As System.Windows.Forms.Button
    Friend WithEvents Button253 As System.Windows.Forms.Button
    Friend WithEvents Button254 As System.Windows.Forms.Button
    Friend WithEvents Button255 As System.Windows.Forms.Button
    Friend WithEvents Button256 As System.Windows.Forms.Button
    Friend WithEvents Button257 As System.Windows.Forms.Button
    Friend WithEvents Button258 As System.Windows.Forms.Button
    Friend WithEvents Button259 As System.Windows.Forms.Button
    Friend WithEvents Button260 As System.Windows.Forms.Button
    Friend WithEvents Button261 As System.Windows.Forms.Button
    Friend WithEvents Button262 As System.Windows.Forms.Button
    Friend WithEvents Button263 As System.Windows.Forms.Button
    Friend WithEvents Button264 As System.Windows.Forms.Button
    Friend WithEvents Button265 As System.Windows.Forms.Button
    Friend WithEvents Button266 As System.Windows.Forms.Button
    Friend WithEvents Button267 As System.Windows.Forms.Button
    Friend WithEvents Button268 As System.Windows.Forms.Button
    Friend WithEvents Button269 As System.Windows.Forms.Button
    Friend WithEvents Button270 As System.Windows.Forms.Button
    Friend WithEvents Button271 As System.Windows.Forms.Button
    Friend WithEvents Button272 As System.Windows.Forms.Button
    Friend WithEvents Button273 As System.Windows.Forms.Button
    Friend WithEvents Button274 As System.Windows.Forms.Button
    Friend WithEvents Button275 As System.Windows.Forms.Button
    Friend WithEvents Button276 As System.Windows.Forms.Button
    Friend WithEvents Button277 As System.Windows.Forms.Button
    Friend WithEvents Button278 As System.Windows.Forms.Button
    Friend WithEvents Button279 As System.Windows.Forms.Button
    Friend WithEvents Button280 As System.Windows.Forms.Button
    Friend WithEvents Button281 As System.Windows.Forms.Button
    Friend WithEvents Button282 As System.Windows.Forms.Button
    Friend WithEvents Button283 As System.Windows.Forms.Button
    Friend WithEvents Button284 As System.Windows.Forms.Button
    Friend WithEvents Button285 As System.Windows.Forms.Button
    Friend WithEvents Button286 As System.Windows.Forms.Button
    Friend WithEvents Button287 As System.Windows.Forms.Button
    Friend WithEvents Button288 As System.Windows.Forms.Button
    Friend WithEvents Button289 As System.Windows.Forms.Button
    Friend WithEvents Button290 As System.Windows.Forms.Button
    Friend WithEvents Button291 As System.Windows.Forms.Button
    Friend WithEvents Button292 As System.Windows.Forms.Button
    Friend WithEvents Button293 As System.Windows.Forms.Button
    Friend WithEvents Button294 As System.Windows.Forms.Button
    Friend WithEvents Button295 As System.Windows.Forms.Button
    Friend WithEvents Button296 As System.Windows.Forms.Button
    Friend WithEvents Button297 As System.Windows.Forms.Button
    Friend WithEvents Button298 As System.Windows.Forms.Button
    Friend WithEvents Button299 As System.Windows.Forms.Button
    Friend WithEvents Button300 As System.Windows.Forms.Button
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox10 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents TextBox11 As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TextBox12 As System.Windows.Forms.TextBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
