﻿
Public Class BackgroundLoop

    Sub BackgroundLoop()
        Throw New NotImplementedException
    End Sub

End Class
