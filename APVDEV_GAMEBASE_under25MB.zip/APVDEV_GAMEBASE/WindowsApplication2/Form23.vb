﻿Public Class Form23
    Property score As Integer
   
    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Application.Restart()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If Form2.score = "10" Then
            Label1.Text = "Congratulation!! Your score is " & Form2.score & "out of 10"
        Else
            Label1.Text = "Your score is"
            Label2.Text = Form13.score + Form14.score + Form15.score + Form16.score + Form17.score + Form18.score + Form19.score + Form20.score + Form21.score + Form22.score
        End If
    End Sub

    Private Sub Form23_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        My.Computer.Audio.Play("C:\Users\Sheryl\Documents\Visual Studio 2010\Projects\WindowsApplication2\Music\Final_Fantasy_Victory_Fanfare_Sound_Effect_HQ_.wav")
    End Sub
End Class